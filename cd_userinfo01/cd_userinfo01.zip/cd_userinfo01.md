```python
# user_id:用户ID，order_dt:购买日期，order_products:购买产品数量,order_amount:购买金额
# 数据时间：1997年1月~1998年6月用户行为数据，约6万条
```


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime #导入日期库
%matplotlib inline #显示图像
plt.style.use('ggplot')  #更改绘图风格，R语言绘图库的风格
plt.rcParams['font.sans-serif'] = ['SimHei']
```


```python
# 导入数据
columns = ['user_id','order_dt','order_products','order_amount']#因为数据没有列头，所以在这里增加列头
df = pd.read_table(r'D:\data analysis\CDNOW_master.txt',names=columns,sep='\s+')  #用参数names增加列名，sep:'\s+':匹配任意个空格（\s代表空格，\s+代表多个空格），空格为空隔符
df.head()
#1.日期格式需要转换
#2.存在同一个用户一天内购买多次行为
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>order_dt</th>
      <th>order_products</th>
      <th>order_amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>19970101</td>
      <td>1</td>
      <td>11.77</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>19970112</td>
      <td>1</td>
      <td>12.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>19970112</td>
      <td>5</td>
      <td>77.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>19970102</td>
      <td>2</td>
      <td>20.76</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>19970330</td>
      <td>2</td>
      <td>20.76</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe()
#1.用户平均每笔订单购买2.4个商品，标准差2.3，稍微有点波动，属于正常。
#然而75%分位数的时候，说明绝大多数订单的购买量都不多，围绕在2~3个产品左右；
#2.购买金额，反映出大部分订单消费金额集中在中小额，30~45左右
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>order_dt</th>
      <th>order_products</th>
      <th>order_amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>69659.000000</td>
      <td>6.965900e+04</td>
      <td>69659.000000</td>
      <td>69659.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>11470.854592</td>
      <td>1.997228e+07</td>
      <td>2.410040</td>
      <td>35.893648</td>
    </tr>
    <tr>
      <th>std</th>
      <td>6819.904848</td>
      <td>3.837735e+03</td>
      <td>2.333924</td>
      <td>36.281942</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.997010e+07</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5506.000000</td>
      <td>1.997022e+07</td>
      <td>1.000000</td>
      <td>14.490000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>11410.000000</td>
      <td>1.997042e+07</td>
      <td>2.000000</td>
      <td>25.980000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>17273.000000</td>
      <td>1.997111e+07</td>
      <td>3.000000</td>
      <td>43.700000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>23570.000000</td>
      <td>1.998063e+07</td>
      <td>99.000000</td>
      <td>1286.010000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 69659 entries, 0 to 69658
    Data columns (total 4 columns):
    user_id           69659 non-null int64
    order_dt          69659 non-null int64
    order_products    69659 non-null int64
    order_amount      69659 non-null float64
    dtypes: float64(1), int64(3)
    memory usage: 2.1 MB
    

# 数据预处理


```python
df['order_date'] = pd.to_datetime(df['order_dt'],format='%Y%m%d')#转换数据列为日期格式，再存到这列中。格式为：年月日
#format参数：按照指定的格式去匹配要转换的数据列。（这时order_date有一个-分隔符）
#%Y:四位的年份1994   %m:两位月份05  %d:两位月份31  
#%y：两位年份94  %h:两位小时09  %M：两位分钟15    %s:两位秒 
#将order_date转化成精度为月份的数据列（提取月份)
df['month'] = df['order_date'].astype('datetime64[M]')  #[M] :控制转换后的精度
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>order_dt</th>
      <th>order_products</th>
      <th>order_amount</th>
      <th>order_date</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>19970101</td>
      <td>1</td>
      <td>11.77</td>
      <td>1997-01-01</td>
      <td>1997-01-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>19970112</td>
      <td>1</td>
      <td>12.00</td>
      <td>1997-01-12</td>
      <td>1997-01-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>19970112</td>
      <td>5</td>
      <td>77.00</td>
      <td>1997-01-12</td>
      <td>1997-01-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>19970102</td>
      <td>2</td>
      <td>20.76</td>
      <td>1997-01-02</td>
      <td>1997-01-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3</td>
      <td>19970330</td>
      <td>2</td>
      <td>20.76</td>
      <td>1997-03-30</td>
      <td>1997-03-01</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 69659 entries, 0 to 69658
    Data columns (total 6 columns):
    user_id           69659 non-null int64
    order_dt          69659 non-null int64
    order_products    69659 non-null int64
    order_amount      69659 non-null float64
    order_date        69659 non-null datetime64[ns]
    month             69659 non-null datetime64[ns]
    dtypes: datetime64[ns](2), float64(1), int64(3)
    memory usage: 3.2 MB
    

## 用户整体消费趋势分析（按月份）


```python
# 按月份统计产品购买数量，消费金额，消费次数，消费人数
plt.figure(figsize=(20,15)) #单位英是寸，图的大小
# 每月的产品购买数量（按月份分组，取出购买数量，然后统计总计）
plt.subplot(221)  #两行两列，占据第一个位置
df.groupby(by='month')['order_products'].sum().plot()  #默认折线图
plt.title('每月的产品购买数量')
# 每月的消费金额（按月份分组，取出消费金额，然后统计总计）
plt.subplot(222)  #两行两列
df.groupby(by='month')['order_amount'].sum().plot()  #默认折线图
plt.title('每月的消费金额')
# 每月的消费次数（按月份分组，取出客户ID，然后统计个数）
plt.subplot(223)  #两行两列
df.groupby(by='month')['user_id'].count().plot()  #默认折线图
plt.title('每月的消费次数')
# 每月的消费人数（根据user_id进行去重统计，再计算个数(len）
plt.subplot(224)  #两行两列
df.groupby(by='month')['user_id'].apply(lambda x:len(x.drop_duplicates())).plot()  #默认折线图
plt.title('每月的消费人数')
#分析结果：
# 图一可以看出，前三个月销量非常高，而以后销量较为稳定，并且稍微呈现下降趋势
# 图二可以看出,依然前三个月消费金额较高，与消费数量成正比例关系，三月份过后下降严重，并呈现下降趋势，思考原因？1：跟月份有关，
# 在我国来1，2，3月份处于春节前后。2.公司在1，2，3，月份的时候是否加大了促销力度
# 图三可以看出，前三个月订单数在10000左右，后续月份的平均消费单数在2500左右
# 图四可以看出，前三个月消费人数在8000~10000左右，后续平均消费人数在2000不到的样子
# 总结：所有数据显示，97年前三月消费事态异常，后续趋于常态化
```

    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:307: MatplotlibDeprecationWarning: 
    The rowNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().rowspan.start instead.
      layout[ax.rowNum, ax.colNum] = ax.get_visible()
    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:307: MatplotlibDeprecationWarning: 
    The colNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().colspan.start instead.
      layout[ax.rowNum, ax.colNum] = ax.get_visible()
    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:313: MatplotlibDeprecationWarning: 
    The rowNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().rowspan.start instead.
      if not layout[ax.rowNum + 1, ax.colNum]:
    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:313: MatplotlibDeprecationWarning: 
    The colNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().colspan.start instead.
      if not layout[ax.rowNum + 1, ax.colNum]:
    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:307: MatplotlibDeprecationWarning: 
    The rowNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().rowspan.start instead.
      layout[ax.rowNum, ax.colNum] = ax.get_visible()
    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:307: MatplotlibDeprecationWarning: 
    The colNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().colspan.start instead.
      layout[ax.rowNum, ax.colNum] = ax.get_visible()
    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:313: MatplotlibDeprecationWarning: 
    The rowNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().rowspan.start instead.
      if not layout[ax.rowNum + 1, ax.colNum]:
    d:\Users\ME\anaconda3\lib\site-packages\pandas\plotting\_matplotlib\tools.py:313: MatplotlibDeprecationWarning: 
    The colNum attribute was deprecated in Matplotlib 3.2 and will be removed two minor releases later. Use ax.get_subplotspec().colspan.start instead.
      if not layout[ax.rowNum + 1, ax.colNum]:
    




    Text(0.5, 1.0, '每月的消费人数')




![png](output_9_2.png)


# 用户个体消费分析

## 用户消费金额，消费次数(产品数量)描述统计


```python
user_grouped = df.groupby(by='user_id').sum()
user_grouped
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_dt</th>
      <th>order_products</th>
      <th>order_amount</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>19970101</td>
      <td>1</td>
      <td>11.77</td>
    </tr>
    <tr>
      <th>2</th>
      <td>39940224</td>
      <td>6</td>
      <td>89.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>119833602</td>
      <td>16</td>
      <td>156.46</td>
    </tr>
    <tr>
      <th>4</th>
      <td>79882233</td>
      <td>7</td>
      <td>100.50</td>
    </tr>
    <tr>
      <th>5</th>
      <td>219686137</td>
      <td>29</td>
      <td>385.61</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>23566</th>
      <td>19970325</td>
      <td>2</td>
      <td>36.00</td>
    </tr>
    <tr>
      <th>23567</th>
      <td>19970325</td>
      <td>1</td>
      <td>20.97</td>
    </tr>
    <tr>
      <th>23568</th>
      <td>59911152</td>
      <td>6</td>
      <td>121.70</td>
    </tr>
    <tr>
      <th>23569</th>
      <td>19970325</td>
      <td>2</td>
      <td>25.74</td>
    </tr>
    <tr>
      <th>23570</th>
      <td>39940651</td>
      <td>5</td>
      <td>94.08</td>
    </tr>
  </tbody>
</table>
<p>23570 rows × 3 columns</p>
</div>




```python
print(user_grouped.describe())
print('用户数量:',len(user_grouped))# 逗号是一行输入的意思
# 从用户的角度：用户数量23570个，每个用户平均购买7个CD，但是中位数只有3，
#  并且最大购买量为1033，平均值大于中位数，属于典型的右偏分布(替购买量<7的用户背锅)
# 从消费金额角度：平均用户消费106，中位数43，并且存在土豪用户13990，结合分位数和最大值来看，平均数与75%分位数几乎相等，
# 属于典型的右偏分布，说明存在小部分用户（后面的25%）高额消费（这些用户需要给消费金额<106的用户背锅，只有这样才能使平均数维持在106）
```

               order_dt  order_products  order_amount
    count  2.357000e+04    23570.000000  23570.000000
    mean   5.902627e+07        7.122656    106.080426
    std    9.460684e+07       16.983531    240.925195
    min    1.997010e+07        1.000000      0.000000
    25%    1.997021e+07        1.000000     19.970000
    50%    1.997032e+07        3.000000     43.395000
    75%    5.992125e+07        7.000000    106.475000
    max    4.334408e+09     1033.000000  13990.930000
    用户数量: 23570
    


```python
# 如
print('hwljwl:',425)
```

    hwljwl: 425
    


```python
#绘制每个用户的产品的购买量与消费金额散点图(因为前面已经对user_id分组了，这时分析每个用户的消费金额和每个用户的购买量之间的关系）)
df.plot(kind='scatter',x='order_products',y='order_amount')
# 从图中可知，用户的消费金额与购买量呈现线性趋势，每个商品均价15左右（坡度就是单价）
# 订单的极值点比较少（消费金额>1000，或者购买量大于60）,对于样本来说影响不大，可以忽略不记。
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26eee52e610>




![png](output_15_1.png)


## 用户消费分布图


```python
plt.figure(figsize=(12,4)) 
plt.subplot(121) #一行两列占据第一个位置
plt.xlabel('每个订单的消费金额')
df['order_amount'].plot(kind='hist',bins=50)  #bins:区间份数，影响柱子的宽度，值越大柱子越细。宽度=（列最大值-最小值）/bins
#消费金额在100以内的订单占据了绝大多数

plt.subplot(122)#一行两列占据第二个位置
plt.xlabel('每个user_id购买的数量')
df.groupby(by='user_id')['order_products'].sum().plot(kind='hist',bins=50)
#图二可知，每个用户购买数量非常小，集中在50以内
# 两幅图得知，我们的用户主要是消费金额低，并且购买小于50的用户人数占据大多数（在电商领域是非常正常的现象）

```




    <matplotlib.axes._subplots.AxesSubplot at 0x26eee7fc190>




![png](output_17_1.png)


## 用户累计消费金额占比分析（用户的贡献度）


```python
#进行用户分组，取出消费金额，进行求和，排序，重置索引
user_cumsum = df.groupby(by='user_id')['order_amount'].sum().sort_values().reset_index()
user_cumsum
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>order_amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10175</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4559</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1948</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>925</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10798</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>23565</th>
      <td>7931</td>
      <td>6497.18</td>
    </tr>
    <tr>
      <th>23566</th>
      <td>19339</td>
      <td>6552.70</td>
    </tr>
    <tr>
      <th>23567</th>
      <td>7983</td>
      <td>6973.07</td>
    </tr>
    <tr>
      <th>23568</th>
      <td>14048</td>
      <td>8976.33</td>
    </tr>
    <tr>
      <th>23569</th>
      <td>7592</td>
      <td>13990.93</td>
    </tr>
  </tbody>
</table>
<p>23570 rows × 2 columns</p>
</div>




```python
#每个用户消费金额累加
# 累加器举例：
a = [1,2,3,4,5,6,7]
print(np.cumsum(a))
```

    [ 1  3  6 10 15 21 28]
    


```python
# 增加一个累加列，累加参数:cumsum
user_cumsum['amount_cumsum'] = user_cumsum['order_amount'].cumsum()
user_cumsum.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>order_amount</th>
      <th>amount_cumsum</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23565</th>
      <td>7931</td>
      <td>6497.18</td>
      <td>2463822.60</td>
    </tr>
    <tr>
      <th>23566</th>
      <td>19339</td>
      <td>6552.70</td>
      <td>2470375.30</td>
    </tr>
    <tr>
      <th>23567</th>
      <td>7983</td>
      <td>6973.07</td>
      <td>2477348.37</td>
    </tr>
    <tr>
      <th>23568</th>
      <td>14048</td>
      <td>8976.33</td>
      <td>2486324.70</td>
    </tr>
    <tr>
      <th>23569</th>
      <td>7592</td>
      <td>13990.93</td>
      <td>2500315.63</td>
    </tr>
  </tbody>
</table>
</div>




```python
amount_total = user_cumsum['amount_cumsum'].max() #消费金额总值(取这列的最大值)
#贡献度占比（如：2463822/2500315=这个用户以前的贡献度占比）
user_cumsum['prop'] = user_cumsum.apply(lambda x:x['amount_cumsum']/amount_total,axis=1)  #沿列的方向操作，前xx名用户的总贡献率
user_cumsum.tail()
#相当 于是23566（索引是23565，所以有23566个用户，贡献率是0.985405）
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>order_amount</th>
      <th>amount_cumsum</th>
      <th>prop</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23565</th>
      <td>7931</td>
      <td>6497.18</td>
      <td>2463822.60</td>
      <td>0.985405</td>
    </tr>
    <tr>
      <th>23566</th>
      <td>19339</td>
      <td>6552.70</td>
      <td>2470375.30</td>
      <td>0.988025</td>
    </tr>
    <tr>
      <th>23567</th>
      <td>7983</td>
      <td>6973.07</td>
      <td>2477348.37</td>
      <td>0.990814</td>
    </tr>
    <tr>
      <th>23568</th>
      <td>14048</td>
      <td>8976.33</td>
      <td>2486324.70</td>
      <td>0.994404</td>
    </tr>
    <tr>
      <th>23569</th>
      <td>7592</td>
      <td>13990.93</td>
      <td>2500315.63</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
user_cumsum['prop'].plot()
# 由图分析可知，前20000名用户贡献总金额的40%，剩余3500名用户贡献了60%。（2/8原则）
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26eee9727c0>




![png](output_23_1.png)


# 用户消费行为

## 首购时间


```python
#用户分组，取最小值，即为首购时间，
# A  1997-1-1  
# B  1997-1-1  
# 1997-1-1   ?（2个）
# 首购时间值的个数
df.groupby(by='user_id')['order_date'].min().value_counts().plot()
# 由图可知，首次购买的用户量在1月1号~2月10号呈明显上升趋势，后续开始逐步下降，猜测：有可能是公司产品的推广力度或者价格调整所致
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26eee996460>




![png](output_26_1.png)


## 最后一次购买时间


```python
df.groupby(by='user_id')['order_date'].max().value_counts().plot()
# 大多数用户最后一次购买时间集中在前3个月，说明缺少忠诚用户。
#  随着时间的推移，最后一次购买商品的用户量呈现上升趋势，猜测：这份数据选择是的前三个月消费的用户在后面18个月的跟踪记录
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26eee9a4430>




![png](output_28_1.png)


# 用户分层

## 构建RFM模型


```python
# R:Recency最近一次消费（值越小越好）order_date.max
# F:Frequency消费频率（值越大越好）  order_products
# M：Monetary消费金额（值越大越好）   order_amount

#透视表的使用（index:相当于groupby,values:取出的数据列，aggfunc:key值必须存在于values列中，并且必须跟随有效的聚合函数）
rfm = df.pivot_table(index='user_id',
                    values=['order_products','order_amount','order_date'],
                    aggfunc={
                        'order_date':'max',# 最后一次购买
                        'order_products':'sum',# 购买产品的总数量
                        'order_amount':'sum'  #消费总金额
                        })
rfm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_amount</th>
      <th>order_date</th>
      <th>order_products</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>11.77</td>
      <td>1997-01-01</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>89.00</td>
      <td>1997-01-12</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>156.46</td>
      <td>1998-05-28</td>
      <td>16</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100.50</td>
      <td>1997-12-12</td>
      <td>7</td>
    </tr>
    <tr>
      <th>5</th>
      <td>385.61</td>
      <td>1998-01-03</td>
      <td>29</td>
    </tr>
  </tbody>
</table>
</div>




```python
rfm['order_date'].max() #日期列中的最大值
```




    Timestamp('1998-06-30 00:00:00')




```python
rfm['order_date'] # 每个用户的最后一次购买时间
```




    user_id
    1       1997-01-01
    2       1997-01-12
    3       1998-05-28
    4       1997-12-12
    5       1998-01-03
               ...    
    23566   1997-03-25
    23567   1997-03-25
    23568   1997-04-22
    23569   1997-03-25
    23570   1997-03-26
    Name: order_date, Length: 23570, dtype: datetime64[ns]




```python
# 用每个用户的最后一次购买时间-日期列中的最大值，最后再转换成天数，小数保留一位
rfm['R'] = -(rfm['order_date']-rfm['order_date'].max())/np.timedelta64(1,'D')  #取相差的天数，保留一位小数
rfm.rename(columns={'order_products':'F','order_amount':'M'},inplace=True)
rfm.head()
#user_id为1的用户已经有545天没有消费了，为2的用户已经有534天没有消费了
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>M</th>
      <th>order_date</th>
      <th>F</th>
      <th>R</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>11.77</td>
      <td>1997-01-01</td>
      <td>1</td>
      <td>545.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>89.00</td>
      <td>1997-01-12</td>
      <td>6</td>
      <td>534.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>156.46</td>
      <td>1998-05-28</td>
      <td>16</td>
      <td>33.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100.50</td>
      <td>1997-12-12</td>
      <td>7</td>
      <td>200.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>385.61</td>
      <td>1998-01-03</td>
      <td>29</td>
      <td>178.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#RFM计算方式：以M列为例：每一列数据减去数据所在列的平均值（# rfm['R']-rfm['R'].mean()），有正有负，根据结果值与1做比较，如果>=1,设置为1，否则0
def rfm_func(x):  #x:分别代表每一列数据
    level = x.apply(lambda x:'1' if x>=1 else '0') 
    label = level['R'] + level['F'] + level['M']  #举例：100    001  111重要价值客户
    d = {
        '111':'重要价值客户',
        '011':'重要保持客户',
        '101':'重要发展客户',
        '001':'重要挽留客户',
        '110':'一般价值客户',
        '010':'一般保持客户',
        '100':'一般发展客户',
        '000':'一般挽留客户'
        
    }
    result = d[label] #字典的取值
    return result
# rfm['R']-rfm['R'].mean()，想同时求出三列，用以下方法
# x代表先代表M列，再代表F列，再代表R列，用每列的每个值-每列的平均值。再根据结果值与1比较，用上面的自定义函数解决（以列的方向）
rfm['label'] = rfm[['R','F','M']].apply(lambda x:x-x.mean()).apply(rfm_func,axis =1)
rfm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>M</th>
      <th>order_date</th>
      <th>F</th>
      <th>R</th>
      <th>label</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>11.77</td>
      <td>1997-01-01</td>
      <td>1</td>
      <td>545.0</td>
      <td>一般发展客户</td>
    </tr>
    <tr>
      <th>2</th>
      <td>89.00</td>
      <td>1997-01-12</td>
      <td>6</td>
      <td>534.0</td>
      <td>一般发展客户</td>
    </tr>
    <tr>
      <th>3</th>
      <td>156.46</td>
      <td>1998-05-28</td>
      <td>16</td>
      <td>33.0</td>
      <td>重要保持客户</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100.50</td>
      <td>1997-12-12</td>
      <td>7</td>
      <td>200.0</td>
      <td>一般挽留客户</td>
    </tr>
    <tr>
      <th>5</th>
      <td>385.61</td>
      <td>1998-01-03</td>
      <td>29</td>
      <td>178.0</td>
      <td>重要保持客户</td>
    </tr>
  </tbody>
</table>
</div>




```python
#客户分层可视化（按label进行分组，遍历循环看一下有多少重要保持客户，有多少一般挽留客户.....)
for label,grouped in rfm.groupby(by='label'):
    x = grouped['F']  # 单个用户的购买数量
    y = grouped['R']  #最近一次购买时间与98年7月的相差天数
    plt.scatter(x,y,label=label)
plt.legend()  #显示图例
plt.xlabel('F')
plt.ylabel('R') 
# RFM（011）重要保持客户最多，还是不错的
```




    Text(0, 0.5, 'R')




![png](output_36_1.png)


# 新老，活跃，回流用户分析


```python
# 新用户的定义：是第一次消费。
# 活跃用户即：老客，在某一个时间窗口内有过消费。
# 不活跃用户则是：时间窗口内没有消费过的老客。
# 回流用户：相当于回头客的意思。
# 用户回流的动作可以分为自主回流与人工回流，自主回流指玩家自己回流了，而人工回流则是人为参与导致的。
```


```python
pivoted_counts = df.pivot_table(
                index='user_id',
                columns ='month',
                values = 'order_dt',
                aggfunc = 'count' #根据用户名分组后，消费时间的计数（根据values)
).fillna(0)
pivoted_counts.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>1997-01-01</th>
      <th>1997-02-01</th>
      <th>1997-03-01</th>
      <th>1997-04-01</th>
      <th>1997-05-01</th>
      <th>1997-06-01</th>
      <th>1997-07-01</th>
      <th>1997-08-01</th>
      <th>1997-09-01</th>
      <th>1997-10-01</th>
      <th>1997-11-01</th>
      <th>1997-12-01</th>
      <th>1998-01-01</th>
      <th>1998-02-01</th>
      <th>1998-03-01</th>
      <th>1998-04-01</th>
      <th>1998-05-01</th>
      <th>1998-06-01</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 由于浮点数不直观，并且需要转成是否消费过即可，用0、1表示
df_purchase = pivoted_counts.applymap(lambda x:1 if x>0 else 0)
# apply:作用与dataframe数据中的一行或者一列数据
# applymap:作用与dataframe数据中的每一个元素
# map:本身是一个series的函数，在df结构中无法使用map函数，map函数作用于series中每一个元素的
df_purchase.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>1997-01-01</th>
      <th>1997-02-01</th>
      <th>1997-03-01</th>
      <th>1997-04-01</th>
      <th>1997-05-01</th>
      <th>1997-06-01</th>
      <th>1997-07-01</th>
      <th>1997-08-01</th>
      <th>1997-09-01</th>
      <th>1997-10-01</th>
      <th>1997-11-01</th>
      <th>1997-12-01</th>
      <th>1998-01-01</th>
      <th>1998-02-01</th>
      <th>1998-03-01</th>
      <th>1998-04-01</th>
      <th>1998-05-01</th>
      <th>1998-06-01</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 判断是否是新用户，活跃用户，不活跃用户，回流用户


def active_status(data): #data：整行数据（共18列，即18个月）
    status = [] #存储用户18个月的状态，变量（unreg|new|active|unactive|return）
    for i in range(18):
        #判断本月没有消费==0
        if data[i] ==0:
            if len(status)==0: #前几个月没有任何记录（也就是97年1月==0）
                status.append('unreg')  
            else:# 开始判断上一个月状态
                if status[i-1] =='unreg':#一直没有消费过
                    status.append('unreg')
                else:#上个月的状态可能是：new|active|unative|reuturn
                    status.append('unactive') #不管上个月是否消费过，本月都是不活跃用户
        else:#本月有消费==1
            if len(status)==0:
                status.append('new') #第一次消费
            else:#之前的月份有记录（判断上一个月状态）
                if status[i-1]=='unactive': #假如上个月是不活跃的状态
                    status.append('return') #本月消费了，上个月没消费，即回流用户
                elif  status[i-1]=='unreg': #假如上个月是未注册
                    status.append('new') #本月消费了，上个月未注册，即新用户
                else:#new|active|return=1（因为已经排除两种情况了）
                    status.append('active') #上个月都是这三种情况，即1，而本月又消费了，则本月是活跃状态
     #因为是一行行返回，是series形式       
    return pd.Series(status,df_purchase.columns) #值：status,列名：18个月份

purchase_states = df_purchase.apply(active_status,axis=1) #得到用户分层结果，方向朝右边，就是往列的方向
purchase_states.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>1997-01-01</th>
      <th>1997-02-01</th>
      <th>1997-03-01</th>
      <th>1997-04-01</th>
      <th>1997-05-01</th>
      <th>1997-06-01</th>
      <th>1997-07-01</th>
      <th>1997-08-01</th>
      <th>1997-09-01</th>
      <th>1997-10-01</th>
      <th>1997-11-01</th>
      <th>1997-12-01</th>
      <th>1998-01-01</th>
      <th>1998-02-01</th>
      <th>1998-03-01</th>
      <th>1998-04-01</th>
      <th>1998-05-01</th>
      <th>1998-06-01</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>2</th>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>3</th>
      <td>new</td>
      <td>unactive</td>
      <td>return</td>
      <td>active</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>return</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>return</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>4</th>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>return</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>return</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>5</th>
      <td>new</td>
      <td>active</td>
      <td>unactive</td>
      <td>return</td>
      <td>active</td>
      <td>active</td>
      <td>active</td>
      <td>unactive</td>
      <td>return</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>return</td>
      <td>active</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
  </tbody>
</table>
</div>




```python
#把unreg状态用nan替换（不分析unreg这个状态）、x代表整列，求整列每种状态的个数（以axis=0这个方向，默认）
purchase_states_ct = purchase_states.replace('unreg',np.NaN).apply(lambda x:pd.value_counts(x))
purchase_states_ct.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>1997-01-01</th>
      <th>1997-02-01</th>
      <th>1997-03-01</th>
      <th>1997-04-01</th>
      <th>1997-05-01</th>
      <th>1997-06-01</th>
      <th>1997-07-01</th>
      <th>1997-08-01</th>
      <th>1997-09-01</th>
      <th>1997-10-01</th>
      <th>1997-11-01</th>
      <th>1997-12-01</th>
      <th>1998-01-01</th>
      <th>1998-02-01</th>
      <th>1998-03-01</th>
      <th>1998-04-01</th>
      <th>1998-05-01</th>
      <th>1998-06-01</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>active</th>
      <td>NaN</td>
      <td>1157.0</td>
      <td>1681</td>
      <td>1773.0</td>
      <td>852.0</td>
      <td>747.0</td>
      <td>746.0</td>
      <td>604.0</td>
      <td>528.0</td>
      <td>532.0</td>
      <td>624.0</td>
      <td>632.0</td>
      <td>512.0</td>
      <td>472.0</td>
      <td>571.0</td>
      <td>518.0</td>
      <td>459.0</td>
      <td>446.0</td>
    </tr>
    <tr>
      <th>new</th>
      <td>7846.0</td>
      <td>8476.0</td>
      <td>7248</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>return</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>595</td>
      <td>1049.0</td>
      <td>1362.0</td>
      <td>1592.0</td>
      <td>1434.0</td>
      <td>1168.0</td>
      <td>1211.0</td>
      <td>1307.0</td>
      <td>1404.0</td>
      <td>1232.0</td>
      <td>1025.0</td>
      <td>1079.0</td>
      <td>1489.0</td>
      <td>919.0</td>
      <td>1029.0</td>
      <td>1060.0</td>
    </tr>
    <tr>
      <th>unactive</th>
      <td>NaN</td>
      <td>6689.0</td>
      <td>14046</td>
      <td>20748.0</td>
      <td>21356.0</td>
      <td>21231.0</td>
      <td>21390.0</td>
      <td>21798.0</td>
      <td>21831.0</td>
      <td>21731.0</td>
      <td>21542.0</td>
      <td>21706.0</td>
      <td>22033.0</td>
      <td>22019.0</td>
      <td>21510.0</td>
      <td>22133.0</td>
      <td>22082.0</td>
      <td>22064.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#数据可视化，面积图（先把NaN替换成0，再转置）
purchase_states_ct.fillna(0).T.plot.area(figsize=(12,6))  #填充nan之后，进行行列变换
# 前三个月可知，红色活跃用户和蓝色新用户，占比较大
# 四月份过后，新用户和活跃用户，开始下降，并且呈现稳定趋势
# 回流用户主要产生在4月过后，呈现稳定趋势，是网站的重要客户
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26ef02e01c0>




![png](output_43_1.png)



```python
#每月中回流用户占比情况（占所有用户的比例）
plt.figure(figsize=(12,6))
rate = purchase_states_ct.fillna(0).T.apply(lambda x:x/x.sum(),axis=1)#取出每行数据，如active（列方向）/每行之和(active+new+return+unactive)
plt.plot(rate['return'],label='return')
plt.plot(rate['active'],label='active')
plt.legend()
# 回流用户：回流用户：前5个月，回流用户上涨，过后吴旦下降趋势，平均维持在5%比例
# 活跃用户：前3个月活跃用户大量增长，猜测由于活动新引来很多新用户所导致5月份过后开始下降，平均维持在2.5%左右
# 网站运营稳定后，回流用户占比大于活跃用户
```




    <matplotlib.legend.Legend at 0x26ef02c93a0>




![png](output_44_1.png)


# 用户的购买周期


```python
#shift函数：将数据移动到一定的位置
data1 = pd.DataFrame({
    'a':[0,1,2,3,4,5],
    'b':[5,4,3,2,1,0]
})
data1.shift(axis=0) #整体向下移动一个位置（默认值：axis=0）
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>a</th>
      <th>b</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>4.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data1.shift(axis=1) #把a列的值 移到b列（整体向右移动一个位置）
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>a</th>
      <th>b</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>NaN</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#计算购买周期（购买日期的时间差值）、取出每一个用户的购买时间记录，减去时间记录的向下偏移量（X代表分组之后每一个用户的列的数据）
order_diff = df.groupby(by='user_id').apply(lambda x:x['order_date']-x['order_date'].shift()) #当前订单日期-上一次订单日期
order_diff.head()
```




    user_id   
    1        0       NaT
    2        1       NaT
             2    0 days
    3        3       NaT
             4   87 days
    Name: order_date, dtype: timedelta64[ns]




```python
order_diff.describe() #大部分顾客的购买周期是在100天以内的
```




    count                      46089
    mean     68 days 23:22:13.567662
    std      91 days 00:47:33.924168
    min              0 days 00:00:00
    25%             10 days 00:00:00
    50%             31 days 00:00:00
    75%             89 days 00:00:00
    max            533 days 00:00:00
    Name: order_date, dtype: object




```python
# order_diff是日期作差，是时间格式，要转换为时间格式且保留1位小数，精确到天
(order_diff/np.timedelta64(1,'D')).hist(bins = 20) #影响柱子的宽度，  每个柱子的宽度=（最大值-最小值）/bins
# 将其转换为具有一天精度的timedelta：days/np.timedelta64(1,'D')  23,两个date或datetime对象相减时可以返回一个timedelta对象。
# 得知：平均消费周期为68天
# 大多数用户消费周期低于100天
# 呈现典型的长尾分布，只有小部分用户消费周期在200天以上（不积极消费的用户），可以在这批用户消费后3天左右进行电话回访后者短信
# 赠送优惠券等活动，增大消费频率
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26ef27b1190>




![png](output_50_1.png)


# 用户生命周期


```python
#计算方式：用户最后一次购买日期(max)-第一次购买的日期(min)。如果差值==0，说明用户仅仅购买了一次
user_life = df.groupby('user_id')['order_date'].agg(['min','max']) #agg:可以同时求order_date里最大值和最小值
user_life.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>min</th>
      <th>max</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1997-01-01</td>
      <td>1997-01-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1997-01-12</td>
      <td>1997-01-12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1997-01-02</td>
      <td>1998-05-28</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1997-01-01</td>
      <td>1997-12-12</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1997-01-01</td>
      <td>1998-01-03</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 如果两个值相等，代表仅消费1次
(user_life['max']==user_life['min']).value_counts().plot.pie(autopct='%1.1f%%') #格式化成1为小数
plt.legend(['仅消费一次','多次消费'])
#一半以上的用户仅仅消费了一次，说明运营不利，留存率不好
```




    <matplotlib.legend.Legend at 0x26ef2979c40>




![png](output_53_1.png)



```python
(user_life['max']-user_life['min']).describe()  #生命周期分析
#用户平均生命周期为134天，但是中位数==0，再次验证大多数用户消费了一次，低质量用户。
# 75%分位数以后的用户，生命周期>294天，属于核心用户，需要着重维持。
# 前三个月的新用户数据，所以分析的是这些用户的生命周期
```




    count                       23570
    mean     134 days 20:55:36.987696
    std      180 days 13:46:43.039788
    min               0 days 00:00:00
    25%               0 days 00:00:00
    50%               0 days 00:00:00
    75%             294 days 00:00:00
    max             544 days 00:00:00
    dtype: object



## 绘制所有用户生命周期直方图+多次消费


```python
plt.figure(figsize=(12,6))
plt.subplot(121)#1行2列第一个位置
((user_life['max']-user_life['min'])/np.timedelta64(1,'D')).hist(bins=15)# 生命周期/np.timedelta64(1,'D')，即日期转成数值，精确到天
plt.title('所有用户生命周期直方图')
plt.xlabel('生命周期天数')
plt.ylabel('用户人数')

plt.subplot(122)
u_1 = (user_life['max']-user_life['min']).reset_index()[0]/np.timedelta64(1,'D') #请看部分解析
u_1[u_1>0].hist(bins=15) #过滤出生命周期大于0的
plt.title('多次消费的用户生命周期直方图')
plt.xlabel('生命周期天数')
plt.ylabel('用户人数')
# 对比可知，第二幅图过滤掉了生命周期==0的用户，呈现双峰结构
# 虽然二图中还有一部分用户的生命周期趋于0天，但是比第一幅图好了很多，虽然进行了多次消费，但是不能长期消费
# 来消费，属于普通用户，可针对性进行营销推广活动
# 少部分用户生命周期集中在300~500天，属于我们的忠诚客户，需要大力度维护此类客户
```




    Text(0, 0.5, '用户人数')




![png](output_56_1.png)



```python
# 部分解析
user_life['max']-user_life['min']
```




    user_id
    1         0 days
    2         0 days
    3       511 days
    4       345 days
    5       367 days
              ...   
    23566     0 days
    23567     0 days
    23568    28 days
    23569     0 days
    23570     1 days
    Length: 23570, dtype: timedelta64[ns]




```python
(user_life['max']-user_life['min']).reset_index()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>user_id</th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>511 days</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>345 days</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>367 days</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>23565</th>
      <td>23566</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>23566</th>
      <td>23567</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>23567</th>
      <td>23568</td>
      <td>28 days</td>
    </tr>
    <tr>
      <th>23568</th>
      <td>23569</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>23569</th>
      <td>23570</td>
      <td>1 days</td>
    </tr>
  </tbody>
</table>
<p>23570 rows × 2 columns</p>
</div>




```python
(user_life['max']-user_life['min']).reset_index()[0] #取出列名
```




    0         0 days
    1         0 days
    2       511 days
    3       345 days
    4       367 days
              ...   
    23565     0 days
    23566     0 days
    23567    28 days
    23568     0 days
    23569     1 days
    Name: 0, Length: 23570, dtype: timedelta64[ns]




```python
# 日期相关的天数 转成数值类型
(user_life['max']-user_life['min']).reset_index()[0]/np.timedelta64(1,'D')
```




    0          0.0
    1          0.0
    2        511.0
    3        345.0
    4        367.0
             ...  
    23565      0.0
    23566      0.0
    23567     28.0
    23568      0.0
    23569      1.0
    Name: 0, Length: 23570, dtype: float64



# 复购率和回购率分析

## 复购率分析


```python
#计算方式：在自然月内，购买多次的用户在总消费人数中的占比（若客户在同一天消费了多次，也称之复购用户）
#消费者有三种：消费记录>=2次的；消费总人数；本月无消费用户；
#复购用户:1    非复购的消费用户：0   自然月没有消费记录的用户：NAN(不参与count计数)
purchase_r = pivoted_counts.applymap(lambda x: 1 if x>1 else np.NaN  if x==0 else 0)
purchase_r.head()
#purchase_r.sum() :求出复购用户
#purchase_r.count():求出所有参与购物的用户（NAN不参与计数）
(purchase_r.sum()/purchase_r.count()).plot(figsize=(12,6))
# 前三个月复购率开始上升，后续趋于平稳维持在20%~22%之间。
# 分析前三个月复购率低的原因，可能是因为大批新用户仅仅购买一次造成的。
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26ef29fc0a0>




![png](output_63_1.png)



```python
# 部分解析
pivoted_counts #消费一次转成0，是非复购用户（但是是消费用户） ；消费两次，是复购用户，转成1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>1997-01-01</th>
      <th>1997-02-01</th>
      <th>1997-03-01</th>
      <th>1997-04-01</th>
      <th>1997-05-01</th>
      <th>1997-06-01</th>
      <th>1997-07-01</th>
      <th>1997-08-01</th>
      <th>1997-09-01</th>
      <th>1997-10-01</th>
      <th>1997-11-01</th>
      <th>1997-12-01</th>
      <th>1998-01-01</th>
      <th>1998-02-01</th>
      <th>1998-03-01</th>
      <th>1998-04-01</th>
      <th>1998-05-01</th>
      <th>1998-06-01</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>23566</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>23567</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>23568</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>23569</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>23570</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>23570 rows × 18 columns</p>
</div>




```python
purchase_r = pivoted_counts.applymap(lambda x: 1 if x>1 else np.NaN  if x==0 else 0)
purchase_r.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>1997-01-01</th>
      <th>1997-02-01</th>
      <th>1997-03-01</th>
      <th>1997-04-01</th>
      <th>1997-05-01</th>
      <th>1997-06-01</th>
      <th>1997-07-01</th>
      <th>1997-08-01</th>
      <th>1997-09-01</th>
      <th>1997-10-01</th>
      <th>1997-11-01</th>
      <th>1997-12-01</th>
      <th>1998-01-01</th>
      <th>1998-02-01</th>
      <th>1998-03-01</th>
      <th>1998-04-01</th>
      <th>1998-05-01</th>
      <th>1998-06-01</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
purchase_r.sum()/purchase_r.count()
```




    month
    1997-01-01    0.107571
    1997-02-01    0.122288
    1997-03-01    0.155292
    1997-04-01    0.223600
    1997-05-01    0.196929
    1997-06-01    0.195810
    1997-07-01    0.215138
    1997-08-01    0.200339
    1997-09-01    0.202415
    1997-10-01    0.206634
    1997-11-01    0.202170
    1997-12-01    0.219957
    1998-01-01    0.210800
    1998-02-01    0.203095
    1998-03-01    0.229612
    1998-04-01    0.199026
    1998-05-01    0.200269
    1998-06-01    0.214475
    dtype: float64



## 回购率分析


```python
#计算方式：在一个时间窗口（一整个月）内进行了消费，在下一个窗口内又进行了消费
# 比如：1月有1000个客户，2月有400个回头客（是1000人里的400人），1月的回购率就是400/1000
def purchase_back(data):
    status = [] #存储用户回购率状态
    #1:回购用户   0：非回购用户（当前月消费了，下个未消费）   NaN:当前月份未消费
    for i in range(17): #16个月
        #当前月份消费了
        if data[i] == 1:
            if data[i+1]==1:
                status.append(1) #回购用户
            elif data[i+1] == 0: #下个月未消费
                status.append(0)
        else: #当前月份未进行消费
            status.append(np.NaN)
    status.append(np.NaN) #填充最后一列数据
    return pd.Series(status,df_purchase.columns)

purchase_b = df_purchase.apply(purchase_back,axis=1)
purchase_b.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>1997-01-01</th>
      <th>1997-02-01</th>
      <th>1997-03-01</th>
      <th>1997-04-01</th>
      <th>1997-05-01</th>
      <th>1997-06-01</th>
      <th>1997-07-01</th>
      <th>1997-08-01</th>
      <th>1997-09-01</th>
      <th>1997-10-01</th>
      <th>1997-11-01</th>
      <th>1997-12-01</th>
      <th>1998-01-01</th>
      <th>1998-02-01</th>
      <th>1998-03-01</th>
      <th>1998-04-01</th>
      <th>1998-05-01</th>
      <th>1998-06-01</th>
    </tr>
    <tr>
      <th>user_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
#回购率可视化
plt.figure(figsize=(20,4))
plt.subplot(211)
#回购率
(purchase_b.sum() / purchase_b.count()).plot(label='回购率')
#复购率
(purchase_r.sum()/purchase_r.count()).plot(label='复购率')
plt.legend()
plt.ylabel('百分比%')
plt.title('用户回购率和复购率对比图')
#回购率可知，平稳后在30%左右，波形性稍微较大
#复购率低于回购率，平稳后在20%左右，波动小较小
#前三个月不困是回购还是复购，都呈现上升趋势，说明新用户需要一定时间来变成复购或者回购用户
#结合新老用户分析，新客户忠诚度远低于老客户忠诚度。

#回购人数与购物总人数
plt.subplot(212)
plt.plot(purchase_b.sum(),label='回购人数')
plt.plot(purchase_b.count(),label='购物总人数')
plt.xlabel('month')
plt.ylabel('人数')
plt.legend()
# 前三个月购物总人数远远大于回购人数，主要是因为很多新用户在1月份进了首次购买
# 三个月后，回购人数和购物总数开始稳定，回购人数稳定在1000左右，购物总人数在2000左右。
```




    <matplotlib.legend.Legend at 0x26ef446ec70>




![png](output_69_1.png)



```python

```
