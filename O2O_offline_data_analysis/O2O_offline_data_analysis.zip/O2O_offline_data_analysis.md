```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns #绘图模块，基于matplotlib的可视化python包,不能完全替代matplotlib,只是它的升级

%matplotlib inline
plt.rcParams['font.sans-serif']=['SimHei']#用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号
# pip install seaborn
```

# 加载数据


```python
# parse_dates:将指定的列加载成日期的格式
offline=pd.read_csv(r'D:\DATA ANALYSIS\ccf_offline_stage1_train.csv',parse_dates=['Date_received','Date'])
offline.info() # 175万+条数据
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1754884 entries, 0 to 1754883
    Data columns (total 7 columns):
    User_id          int64
    Merchant_id      int64
    Coupon_id        float64
    Discount_rate    object
    Distance         float64
    Date_received    datetime64[ns]
    Date             datetime64[ns]
    dtypes: datetime64[ns](2), float64(2), int64(2), object(1)
    memory usage: 93.7+ MB
    


```python
offline.head() #NaT：时间日期格式的空值
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
      <th>Merchant_id</th>
      <th>Coupon_id</th>
      <th>Discount_rate</th>
      <th>Distance</th>
      <th>Date_received</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1439408</td>
      <td>2632</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaT</td>
      <td>2016-02-17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1439408</td>
      <td>4663</td>
      <td>11002.0</td>
      <td>150:20</td>
      <td>1.0</td>
      <td>2016-05-28</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>20:1</td>
      <td>0.0</td>
      <td>2016-02-17</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1439408</td>
      <td>2632</td>
      <td>1078.0</td>
      <td>20:1</td>
      <td>0.0</td>
      <td>2016-03-19</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>20:1</td>
      <td>0.0</td>
      <td>2016-06-13</td>
      <td>NaT</td>
    </tr>
  </tbody>
</table>
</div>



# 数据的规整


```python
#判断每一列当中有多少个空值
offline.isnull().sum()
# 优惠券id，折扣率，领券日期，三者可能存在同时==null的情况
```




    User_id               0
    Merchant_id           0
    Coupon_id        701602
    Discount_rate    701602
    Distance         106003
    Date_received    701602
    Date             977900
    dtype: int64



## 把discount_rate列中的满减政策转换成折扣率


```python
# 空值转成NULL
offline['Discount_rate']=offline['Discount_rate'].fillna('null')
offline.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
      <th>Merchant_id</th>
      <th>Coupon_id</th>
      <th>Discount_rate</th>
      <th>Distance</th>
      <th>Date_received</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1439408</td>
      <td>2632</td>
      <td>NaN</td>
      <td>null</td>
      <td>0.0</td>
      <td>NaT</td>
      <td>2016-02-17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1439408</td>
      <td>4663</td>
      <td>11002.0</td>
      <td>150:20</td>
      <td>1.0</td>
      <td>2016-05-28</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>20:1</td>
      <td>0.0</td>
      <td>2016-02-17</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1439408</td>
      <td>2632</td>
      <td>1078.0</td>
      <td>20:1</td>
      <td>0.0</td>
      <td>2016-03-19</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>20:1</td>
      <td>0.0</td>
      <td>2016-06-13</td>
      <td>NaT</td>
    </tr>
  </tbody>
</table>
</div>




```python
def discount_rate_opt(s):#s代表每一个元素
    if ':' in s: #如果传进来的数据（如：150：20）里有冒号
        split=s.split(':') #用冒号去拆分
        discount_rate=(int(split[0])-int(split[1]))/int(split[0]) #取第一个值，并从字符串转成整型,再减去第二个值(相当于（150-20）/150就是折扣率，满150减20)
        return round(discount_rate,2) #折扣率保留两位小数
    elif s=='null':
        return np.NaN
    else:
        return float(s) #如数据集里的折扣率有0.9
```


```python
offline['Discount_rate']=offline['Discount_rate'].map(discount_rate_opt)
offline.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
      <th>Merchant_id</th>
      <th>Coupon_id</th>
      <th>Discount_rate</th>
      <th>Distance</th>
      <th>Date_received</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1439408</td>
      <td>2632</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaT</td>
      <td>2016-02-17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1439408</td>
      <td>4663</td>
      <td>11002.0</td>
      <td>0.87</td>
      <td>1.0</td>
      <td>2016-05-28</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-02-17</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1439408</td>
      <td>2632</td>
      <td>1078.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-03-19</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-06-13</td>
      <td>NaT</td>
    </tr>
  </tbody>
</table>
</div>




```python
# coupon_id字段：null代表无优惠券，此时discount_rate与date_received字段无意义
# 检查coupon_id 和discount_rate与date_received判断空值和非空值是否一一对应
# np.all():判断一个课迭代数据中是否都为True，如果是返回True,否则返回False
np.all([True,False,True])
```




    False




```python
nan1=offline['Coupon_id'].isnull() #判断优惠券是否为空
nan2=offline['Date_received'].isnull() # 判断领券日期是否为空
np.all(nan1==nan2) #如果结果=true,说明之前的猜测：coupon_id and date_received空值与非空值是一一对应的
```




    True




```python
nan3=offline['Discount_rate'].isnull() # 判断折扣率是否为空
np.all(nan1==nan3)#如果结果=true,说明之前的猜测：coupon_id and Discount_rate空值与非空值是一一对应的
```




    True



## 分析四种情况
#### 如果Date=null & Coupon_id!=null,有券未消费（cpon_no_consume)
#### 如果Date=null & Coupon_id=null，无券未消费（no_cpon_no_consume)
#### 如果Date!=null & Coupon_id=null，无券消费（no_cpon_consume)
#### 如果Date!=null& Coupon_id!=null，有券消费（cpon_consume)


```python
cpon_no_consume=offline[(offline['Date'].isnull()&offline['Coupon_id'].notnull())]
no_cpon_no_consume=offline[(offline['Date'].isnull()&offline['Coupon_id'].isnull())]
no_cpon_consume=offline[(offline['Date'].notnull()&offline['Coupon_id'].isnull())]
cpon_consume=offline[(offline['Date'].notnull()&offline['Coupon_id'].notnull())]
```


```python
print('有券未消费:{}'.format(len(cpon_no_consume)))
print('无券未消费:{}'.format(len(no_cpon_no_consume))) #分析无意义不需分析
print('无券消费:{}'.format(len(no_cpon_consume)))
print('有券消费:{}'.format(len(cpon_consume)))
# 用优惠券消费的用户7万+，相比其他用户来说，占比较少
```

    有券未消费:977900
    无券未消费:0
    无券消费:701602
    有券消费:75382
    

# 数据分析


```python
# 绘制饼图占比
consume_status_dict={'cpon_no_consume':len(cpon_no_consume),'no_cpon_consume':len(no_cpon_consume),'cpon_consume':len(cpon_consume)}
consume_status_dict                                                                                                                  
```




    {'cpon_no_consume': 977900, 'no_cpon_consume': 701602, 'cpon_consume': 75382}




```python
# 把字典转成series
consume_status=pd.Series(consume_status_dict)
consume_status
```




    cpon_no_consume    977900
    no_cpon_consume    701602
    cpon_consume        75382
    dtype: int64




```python
# 消费方式构成的饼图（figure:看作是一张画布，axes:代表画面内的多个坐标系）
fig,ax=plt.subplots(1,1,figsize=(8,10))
consume_status.plot.pie(ax=ax,
                       autopct='%1.1f%%',
                        shadow=True,
                        explode=[0.02,0.05,0.02],
                        textprops={'fontsize':15,'color':'blue'},
                        wedgeprops={'linewidth':1,'edgecolor':'black'},
                        labels=['有券未消费 \n({})'.format(len(cpon_no_consume)),
                                '无券消费 \n({})'.format(len(no_cpon_consume)),
                               '有券消费 \n({})'.format(len(cpon_consume))
                               ]                    
                       )
ax.set_ylabel('') #去除ylable
ax.set_title('消费占比情况')
plt.legend(labels=['有券未消费','无券消费','用券消费'])
# 有券未消费占比55.7%最大，说明 大多数人拿完券之后，尚未使用
# 无圈消费用户占比40%，说明很多人没有使用优惠券，可能 优惠券的吸引力不大，客户没在意，可能 新客户比较多
#用券消费用户占比小4.3%，说明我们的优惠券使用率不高，可以考虑是不是加大优惠券力度
```




    <matplotlib.legend.Legend at 0x24c9b8b3640>




![png](output_19_1.png)


## 在有券消费人群中，分析距离和优惠折扣


```python
# 各商家对应的顾客到店平均距离 
#距离0-10，=0就是距离<500米
Merchant_distance=cpon_consume.groupby('Merchant_id')['Distance'].mean()
Merchant_distance[Merchant_distance==0]
# 有4076个商家，有1431个商家 的用券消费用户平均范围在500米以内
```




    Merchant_id
    3       0.0
    4       0.0
    13      0.0
    14      0.0
    18      0.0
           ... 
    8806    0.0
    8824    0.0
    8828    0.0
    8849    0.0
    8856    0.0
    Name: Distance, Length: 1431, dtype: float64




```python
# 各商家对应的顾客到店消费平均折扣力度
Merchant_discount_rate=cpon_consume.groupby('Merchant_id')['Discount_rate'].mean()
Merchant_discount_rate.sort_values() # 折扣率升序排序
Merchant_discount_rate.hist()
Merchant_discount_rate.mean() # 所有商家平均折扣的平均值：0.88
```




    0.8847410562670556




![png](output_22_1.png)


## 持券到店消费人数最多的商家 


```python
# 对商家 进行分组，取出用户id，对用户id进行去重统计数量，然后降序排序
popular_merchant=cpon_consume.groupby('Merchant_id')['User_id'].apply(lambda x:len(x.unique())).sort_values(ascending=False)
popular_merchant
```




    Merchant_id
    5341    2800
    760     2627
    3381    2248
    6485    2029
    2099    1401
            ... 
    2791       1
    2795       1
    2807       1
    2810       1
    3          1
    Name: User_id, Length: 4076, dtype: int64




```python
# 找出持券消费人数>500的商家id
popular_merchant500=popular_merchant[popular_merchant>500]
popular_merchant500.name='customer_count'#指定列名为持券消费者数量
popular_merchant500
```




    Merchant_id
    5341    2800
    760     2627
    3381    2248
    6485    2029
    2099    1401
    2934    1310
    450     1094
    3532     968
    7555     925
    1520     870
    6901     855
    3621     851
    4142     832
    1379     587
    1469     584
    1433     559
    Name: customer_count, dtype: int64




```python
len(popular_merchant500)
```




    16




```python
# 挂着消费人数最多的商家 是5341，持券消费人数在2800
# 共有16家店铺，持券消费人数在500人以上
# 这批商家对优惠券的使用方法得当，消费者喜欢用优惠券进行消费，可以适当 借鉴这批商家 的推广力度
```

## 持券消费人数在500人以上的商家，连接顾客到店平均距离和平均折扣力度


```python
merchant_pop_dis=pd.merge(left=popular_merchant500,right=Merchant_distance,on='Merchant_id',how='inner')
merchant_pop_dis
#距离*500就是实际距离
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_count</th>
      <th>Distance</th>
    </tr>
    <tr>
      <th>Merchant_id</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5341</th>
      <td>2800</td>
      <td>0.168598</td>
    </tr>
    <tr>
      <th>760</th>
      <td>2627</td>
      <td>0.349866</td>
    </tr>
    <tr>
      <th>3381</th>
      <td>2248</td>
      <td>1.652429</td>
    </tr>
    <tr>
      <th>6485</th>
      <td>2029</td>
      <td>0.368567</td>
    </tr>
    <tr>
      <th>2099</th>
      <td>1401</td>
      <td>0.968072</td>
    </tr>
    <tr>
      <th>2934</th>
      <td>1310</td>
      <td>1.114833</td>
    </tr>
    <tr>
      <th>450</th>
      <td>1094</td>
      <td>0.892164</td>
    </tr>
    <tr>
      <th>3532</th>
      <td>968</td>
      <td>0.272498</td>
    </tr>
    <tr>
      <th>7555</th>
      <td>925</td>
      <td>1.329977</td>
    </tr>
    <tr>
      <th>1520</th>
      <td>870</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6901</th>
      <td>855</td>
      <td>0.557895</td>
    </tr>
    <tr>
      <th>3621</th>
      <td>851</td>
      <td>0.472799</td>
    </tr>
    <tr>
      <th>4142</th>
      <td>832</td>
      <td>0.555882</td>
    </tr>
    <tr>
      <th>1379</th>
      <td>587</td>
      <td>0.706250</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>584</td>
      <td>2.092800</td>
    </tr>
    <tr>
      <th>1433</th>
      <td>559</td>
      <td>1.054962</td>
    </tr>
  </tbody>
</table>
</div>




```python
merchant_pop_dis_rate=pd.merge(left=merchant_pop_dis,right=Merchant_discount_rate,on='Merchant_id',how='inner')
merchant_pop_dis_rate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_count</th>
      <th>Distance</th>
      <th>Discount_rate</th>
    </tr>
    <tr>
      <th>Merchant_id</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5341</th>
      <td>2800</td>
      <td>0.168598</td>
      <td>0.826036</td>
    </tr>
    <tr>
      <th>760</th>
      <td>2627</td>
      <td>0.349866</td>
      <td>0.799873</td>
    </tr>
    <tr>
      <th>3381</th>
      <td>2248</td>
      <td>1.652429</td>
      <td>0.744150</td>
    </tr>
    <tr>
      <th>6485</th>
      <td>2029</td>
      <td>0.368567</td>
      <td>0.770439</td>
    </tr>
    <tr>
      <th>2099</th>
      <td>1401</td>
      <td>0.968072</td>
      <td>0.900000</td>
    </tr>
    <tr>
      <th>2934</th>
      <td>1310</td>
      <td>1.114833</td>
      <td>0.830000</td>
    </tr>
    <tr>
      <th>450</th>
      <td>1094</td>
      <td>0.892164</td>
      <td>0.819274</td>
    </tr>
    <tr>
      <th>3532</th>
      <td>968</td>
      <td>0.272498</td>
      <td>0.852289</td>
    </tr>
    <tr>
      <th>7555</th>
      <td>925</td>
      <td>1.329977</td>
      <td>0.828381</td>
    </tr>
    <tr>
      <th>1520</th>
      <td>870</td>
      <td>NaN</td>
      <td>0.925632</td>
    </tr>
    <tr>
      <th>6901</th>
      <td>855</td>
      <td>0.557895</td>
      <td>0.834165</td>
    </tr>
    <tr>
      <th>3621</th>
      <td>851</td>
      <td>0.472799</td>
      <td>0.747565</td>
    </tr>
    <tr>
      <th>4142</th>
      <td>832</td>
      <td>0.555882</td>
      <td>0.900000</td>
    </tr>
    <tr>
      <th>1379</th>
      <td>587</td>
      <td>0.706250</td>
      <td>0.830096</td>
    </tr>
    <tr>
      <th>1469</th>
      <td>584</td>
      <td>2.092800</td>
      <td>0.721870</td>
    </tr>
    <tr>
      <th>1433</th>
      <td>559</td>
      <td>1.054962</td>
      <td>0.825959</td>
    </tr>
  </tbody>
</table>
</div>



## 计算到店消费人数与平均距离和折扣力度的相关系数


```python
# corr(correlation:相关系数)，用来计算df数据中列与列的相关性（皮尔逊相关系数），取值范围是[-1,1]
# 1是完全正相关，-1是完全负相关
# 绝对值越大：相关性越大，反之成立
# 正相关：随着变量的增大，而增大，反之同理
# 负相关：随着变量的增大，而减小，反之同理
merchant_pop_dis_rate.corr()
# 持券消费人数，与距离和折扣率都呈现出负相关，属于生活中的正常现象
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_count</th>
      <th>Distance</th>
      <th>Discount_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>customer_count</th>
      <td>1.000000</td>
      <td>-0.306180</td>
      <td>-0.204102</td>
    </tr>
    <tr>
      <th>Distance</th>
      <td>-0.306180</td>
      <td>1.000000</td>
      <td>-0.397376</td>
    </tr>
    <tr>
      <th>Discount_rate</th>
      <td>-0.204102</td>
      <td>-0.397376</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 用热力图展示相关系数 （data:相关系数 ，annot=True显示相关系数值，cmap颜色范围，vmax:最大值，vmin:最小值）
sns.heatmap(data=merchant_pop_dis_rate.corr(),annot=True,cmap='Accent',vmax=1,vmin=-1)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x24c9cc428b0>




![png](output_33_1.png)



```python
# 由图可知：
# 1.到店消费人数的多少与顾客到店铺的距离 之间呈现负相关，相关系数0.31，在0.3-0.5之间，为低度相关
# 2. 到店消费人数的多少与优惠打折力度呈现负相关，相关系数0.2，在0-0.3之间，为相关程度极弱
# 综上所述，这些店家之所以火爆，应该是物美价廉导致，与距离 和优惠力度相关性不大
```

## 析每天中优惠券的总体发放量与使用量情况


```python
# 业务分析：日期（优惠券的发放日期Date_received，使用日期date）用作图表的X轴
# 需要统计每天优惠券发放数量和使用数量
offline
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
      <th>Merchant_id</th>
      <th>Coupon_id</th>
      <th>Discount_rate</th>
      <th>Distance</th>
      <th>Date_received</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1439408</td>
      <td>2632</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaT</td>
      <td>2016-02-17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1439408</td>
      <td>4663</td>
      <td>11002.0</td>
      <td>0.87</td>
      <td>1.0</td>
      <td>2016-05-28</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-02-17</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1439408</td>
      <td>2632</td>
      <td>1078.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-03-19</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-06-13</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1754879</th>
      <td>212662</td>
      <td>3532</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaT</td>
      <td>2016-03-22</td>
    </tr>
    <tr>
      <th>1754880</th>
      <td>212662</td>
      <td>3021</td>
      <td>3739.0</td>
      <td>0.97</td>
      <td>6.0</td>
      <td>2016-05-08</td>
      <td>2016-06-02</td>
    </tr>
    <tr>
      <th>1754881</th>
      <td>212662</td>
      <td>2934</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>NaT</td>
      <td>2016-03-21</td>
    </tr>
    <tr>
      <th>1754882</th>
      <td>752472</td>
      <td>7113</td>
      <td>1633.0</td>
      <td>0.80</td>
      <td>6.0</td>
      <td>2016-06-13</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>1754883</th>
      <td>752472</td>
      <td>3621</td>
      <td>2705.0</td>
      <td>0.75</td>
      <td>0.0</td>
      <td>2016-05-23</td>
      <td>NaT</td>
    </tr>
  </tbody>
</table>
<p>1754884 rows × 7 columns</p>
</div>




```python
offline['Date'].notnull().sum() #77.7万消费数据
```




    776984




```python
offline['Date_received'].notnull().sum() #已经发送出105万优惠券
```




    1053282




```python
# 取出存在消费日期的记录，进行升序，再去重
date_sort=offline[offline['Date_received'].notnull()]['Date'].sort_values().unique()
date_sort[:5] #取出前5条记录
```




    array(['2016-01-01T00:00:00.000000000', '2016-01-02T00:00:00.000000000',
           '2016-01-03T00:00:00.000000000', '2016-01-04T00:00:00.000000000',
           '2016-01-05T00:00:00.000000000'], dtype='datetime64[ns]')




```python
# 取出存在领券日期的记录，进行升序，再去重
date_receive_sort=offline[offline['Date_received'].notnull()]['Date_received'].sort_values().unique()
date_receive_sort[:5] #取出前5条记录
```




    array(['2016-01-01T00:00:00.000000000', '2016-01-02T00:00:00.000000000',
           '2016-01-03T00:00:00.000000000', '2016-01-04T00:00:00.000000000',
           '2016-01-05T00:00:00.000000000'], dtype='datetime64[ns]')




```python
# 每天优惠券的使用量（即持券消费人群）
cpon_consume
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
      <th>Merchant_id</th>
      <th>Coupon_id</th>
      <th>Discount_rate</th>
      <th>Distance</th>
      <th>Date_received</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-05-16</td>
      <td>2016-06-13</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1113008</td>
      <td>1361</td>
      <td>11166.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-05-15</td>
      <td>2016-05-21</td>
    </tr>
    <tr>
      <th>38</th>
      <td>2881376</td>
      <td>8390</td>
      <td>7531.0</td>
      <td>0.75</td>
      <td>0.0</td>
      <td>2016-03-21</td>
      <td>2016-03-29</td>
    </tr>
    <tr>
      <th>69</th>
      <td>114747</td>
      <td>6901</td>
      <td>2366.0</td>
      <td>0.83</td>
      <td>0.0</td>
      <td>2016-05-23</td>
      <td>2016-06-05</td>
    </tr>
    <tr>
      <th>75</th>
      <td>114747</td>
      <td>5341</td>
      <td>111.0</td>
      <td>0.83</td>
      <td>0.0</td>
      <td>2016-01-27</td>
      <td>2016-02-21</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1754833</th>
      <td>1437872</td>
      <td>7706</td>
      <td>416.0</td>
      <td>0.90</td>
      <td>4.0</td>
      <td>2016-01-29</td>
      <td>2016-02-02</td>
    </tr>
    <tr>
      <th>1754873</th>
      <td>212662</td>
      <td>2934</td>
      <td>5686.0</td>
      <td>0.83</td>
      <td>2.0</td>
      <td>2016-03-21</td>
      <td>2016-03-30</td>
    </tr>
    <tr>
      <th>1754877</th>
      <td>212662</td>
      <td>3021</td>
      <td>3739.0</td>
      <td>0.97</td>
      <td>6.0</td>
      <td>2016-05-04</td>
      <td>2016-05-08</td>
    </tr>
    <tr>
      <th>1754878</th>
      <td>212662</td>
      <td>2934</td>
      <td>5686.0</td>
      <td>0.83</td>
      <td>2.0</td>
      <td>2016-03-21</td>
      <td>2016-03-22</td>
    </tr>
    <tr>
      <th>1754880</th>
      <td>212662</td>
      <td>3021</td>
      <td>3739.0</td>
      <td>0.97</td>
      <td>6.0</td>
      <td>2016-05-08</td>
      <td>2016-06-02</td>
    </tr>
  </tbody>
</table>
<p>75382 rows × 7 columns</p>
</div>




```python
consume_num_erverday=cpon_consume[['User_id','Date_received']]
consume_num_erverday
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
      <th>Date_received</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>1439408</td>
      <td>2016-05-16</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1113008</td>
      <td>2016-05-15</td>
    </tr>
    <tr>
      <th>38</th>
      <td>2881376</td>
      <td>2016-03-21</td>
    </tr>
    <tr>
      <th>69</th>
      <td>114747</td>
      <td>2016-05-23</td>
    </tr>
    <tr>
      <th>75</th>
      <td>114747</td>
      <td>2016-01-27</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1754833</th>
      <td>1437872</td>
      <td>2016-01-29</td>
    </tr>
    <tr>
      <th>1754873</th>
      <td>212662</td>
      <td>2016-03-21</td>
    </tr>
    <tr>
      <th>1754877</th>
      <td>212662</td>
      <td>2016-05-04</td>
    </tr>
    <tr>
      <th>1754878</th>
      <td>212662</td>
      <td>2016-03-21</td>
    </tr>
    <tr>
      <th>1754880</th>
      <td>212662</td>
      <td>2016-05-08</td>
    </tr>
  </tbody>
</table>
<p>75382 rows × 2 columns</p>
</div>




```python
consume_num_erverday=consume_num_erverday.groupby('Date_received').count()
consume_num_erverday
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
    </tr>
    <tr>
      <th>Date_received</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2016-01-01</th>
      <td>74</td>
    </tr>
    <tr>
      <th>2016-01-02</th>
      <td>67</td>
    </tr>
    <tr>
      <th>2016-01-03</th>
      <td>74</td>
    </tr>
    <tr>
      <th>2016-01-04</th>
      <td>98</td>
    </tr>
    <tr>
      <th>2016-01-05</th>
      <td>107</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>2016-06-11</th>
      <td>351</td>
    </tr>
    <tr>
      <th>2016-06-12</th>
      <td>330</td>
    </tr>
    <tr>
      <th>2016-06-13</th>
      <td>439</td>
    </tr>
    <tr>
      <th>2016-06-14</th>
      <td>394</td>
    </tr>
    <tr>
      <th>2016-06-15</th>
      <td>355</td>
    </tr>
  </tbody>
</table>
<p>167 rows × 1 columns</p>
</div>




```python
consume_num_erverday=consume_num_erverday.rename(columns={'User_id':'count'})
consume_num_erverday
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
    </tr>
    <tr>
      <th>Date_received</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2016-01-01</th>
      <td>74</td>
    </tr>
    <tr>
      <th>2016-01-02</th>
      <td>67</td>
    </tr>
    <tr>
      <th>2016-01-03</th>
      <td>74</td>
    </tr>
    <tr>
      <th>2016-01-04</th>
      <td>98</td>
    </tr>
    <tr>
      <th>2016-01-05</th>
      <td>107</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>2016-06-11</th>
      <td>351</td>
    </tr>
    <tr>
      <th>2016-06-12</th>
      <td>330</td>
    </tr>
    <tr>
      <th>2016-06-13</th>
      <td>439</td>
    </tr>
    <tr>
      <th>2016-06-14</th>
      <td>394</td>
    </tr>
    <tr>
      <th>2016-06-15</th>
      <td>355</td>
    </tr>
  </tbody>
</table>
<p>167 rows × 1 columns</p>
</div>




```python
# 每天发放的优惠券数量(取出所有领券日期不为空的数据，再进行按天分组，计数就可以)
offline
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User_id</th>
      <th>Merchant_id</th>
      <th>Coupon_id</th>
      <th>Discount_rate</th>
      <th>Distance</th>
      <th>Date_received</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1439408</td>
      <td>2632</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaT</td>
      <td>2016-02-17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1439408</td>
      <td>4663</td>
      <td>11002.0</td>
      <td>0.87</td>
      <td>1.0</td>
      <td>2016-05-28</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-02-17</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1439408</td>
      <td>2632</td>
      <td>1078.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-03-19</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1439408</td>
      <td>2632</td>
      <td>8591.0</td>
      <td>0.95</td>
      <td>0.0</td>
      <td>2016-06-13</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1754879</th>
      <td>212662</td>
      <td>3532</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaT</td>
      <td>2016-03-22</td>
    </tr>
    <tr>
      <th>1754880</th>
      <td>212662</td>
      <td>3021</td>
      <td>3739.0</td>
      <td>0.97</td>
      <td>6.0</td>
      <td>2016-05-08</td>
      <td>2016-06-02</td>
    </tr>
    <tr>
      <th>1754881</th>
      <td>212662</td>
      <td>2934</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>NaT</td>
      <td>2016-03-21</td>
    </tr>
    <tr>
      <th>1754882</th>
      <td>752472</td>
      <td>7113</td>
      <td>1633.0</td>
      <td>0.80</td>
      <td>6.0</td>
      <td>2016-06-13</td>
      <td>NaT</td>
    </tr>
    <tr>
      <th>1754883</th>
      <td>752472</td>
      <td>3621</td>
      <td>2705.0</td>
      <td>0.75</td>
      <td>0.0</td>
      <td>2016-05-23</td>
      <td>NaT</td>
    </tr>
  </tbody>
</table>
<p>1754884 rows × 7 columns</p>
</div>




```python
coupon_sendout_everyday=offline[offline['Date_received'].notnull()][['Date_received','User_id']]
coupon_sendout_everyday
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date_received</th>
      <th>User_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2016-05-28</td>
      <td>1439408</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016-02-17</td>
      <td>1439408</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2016-03-19</td>
      <td>1439408</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2016-06-13</td>
      <td>1439408</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2016-05-16</td>
      <td>1439408</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1754877</th>
      <td>2016-05-04</td>
      <td>212662</td>
    </tr>
    <tr>
      <th>1754878</th>
      <td>2016-03-21</td>
      <td>212662</td>
    </tr>
    <tr>
      <th>1754880</th>
      <td>2016-05-08</td>
      <td>212662</td>
    </tr>
    <tr>
      <th>1754882</th>
      <td>2016-06-13</td>
      <td>752472</td>
    </tr>
    <tr>
      <th>1754883</th>
      <td>2016-05-23</td>
      <td>752472</td>
    </tr>
  </tbody>
</table>
<p>1053282 rows × 2 columns</p>
</div>




```python
coupon_sendout_everyday=coupon_sendout_everyday.groupby('Date_received').count()
coupon_sendout_everyday=coupon_sendout_everyday.rename(columns={'User_id':'count'})
coupon_sendout_everyday
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
    </tr>
    <tr>
      <th>Date_received</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2016-01-01</th>
      <td>554</td>
    </tr>
    <tr>
      <th>2016-01-02</th>
      <td>542</td>
    </tr>
    <tr>
      <th>2016-01-03</th>
      <td>536</td>
    </tr>
    <tr>
      <th>2016-01-04</th>
      <td>577</td>
    </tr>
    <tr>
      <th>2016-01-05</th>
      <td>691</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>2016-06-11</th>
      <td>5211</td>
    </tr>
    <tr>
      <th>2016-06-12</th>
      <td>4005</td>
    </tr>
    <tr>
      <th>2016-06-13</th>
      <td>7861</td>
    </tr>
    <tr>
      <th>2016-06-14</th>
      <td>4755</td>
    </tr>
    <tr>
      <th>2016-06-15</th>
      <td>3475</td>
    </tr>
  </tbody>
</table>
<p>167 rows × 1 columns</p>
</div>




```python
# 绘制每天发券量和每天的用券量
plt.figure(figsize=(18,6))
plt.bar(x=date_receive_sort,height=coupon_sendout_everyday['count'],label='每天发券量')
plt.bar(x=date_receive_sort,height=consume_num_erverday['count'],label='每天用券量')
plt.yscale('log') #对Y轴进行对数缩放
plt.legend()
# 16年2月为例，用券量级别在1000，发券量在10万左右，在100倍左右，优惠券的使用率还是非常低的
```




    <matplotlib.legend.Legend at 0x24c9fb75880>




![png](output_48_1.png)



```python
# 计算每天的优惠券与发券量占比
plt.figure(figsize=(18,6))
plt.bar(x=date_receive_sort,height=consume_num_erverday['count']/coupon_sendout_everyday['count'],
       label='百分比')
plt.legend()

```




    <matplotlib.legend.Legend at 0x24c9de38130>




![png](output_49_1.png)



```python
# 由图可知，优惠券使用率最高在16年3月底，达到了30%
# 使用率最低在16年1月底，最低为3%左右
# 整体来看，优惠券使用率波动较大
```
