```python
# 导入库
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
from datetime import datetime
```

#  初识数据


```python
df=pd.read_csv(r'D:\DATA ANALYSIS\kelu.csv')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019/2/28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019/2/28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019/2/28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019/2/28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019/2/28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8752</th>
      <td>Jonathan</td>
      <td>100</td>
      <td>2016/8/6</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8753</th>
      <td>Oliver Stephen Ah Kam</td>
      <td>100</td>
      <td>2016/8/5</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8754</th>
      <td>Halley</td>
      <td>100</td>
      <td>2016/8/5</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8755</th>
      <td>ANDREW WEIQIANG</td>
      <td>100</td>
      <td>2016/8/3</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>WEI CHIEH</td>
      <td>60</td>
      <td>2016/8/2</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>8757 rows × 6 columns</p>
</div>




```python
df.info()
# 基本信息：门票价格110，数据来自16年-19年，8千多数据量
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 8757 entries, 0 to 8756
    Data columns (total 6 columns):
    author       8757 non-null object
    rating       8757 non-null int64
    time         8757 non-null object
    year         8757 non-null int64
    amount       8757 non-null int64
    frequency    8757 non-null int64
    dtypes: int64(4), object(2)
    memory usage: 410.6+ KB
    


```python
df.describe()
# 根据平均分92和1/2分位得知，大多数用户评分在100，效果非常不错
#16-19年门票价格都是110，没有涨价
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rating</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>8757.000000</td>
      <td>8757.000000</td>
      <td>8757.0</td>
      <td>8757.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>92.417495</td>
      <td>2017.760420</td>
      <td>110.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>14.231179</td>
      <td>0.686734</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>20.000000</td>
      <td>2016.000000</td>
      <td>110.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>80.000000</td>
      <td>2017.000000</td>
      <td>110.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>100.000000</td>
      <td>2018.000000</td>
      <td>110.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>100.000000</td>
      <td>2018.000000</td>
      <td>110.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>100.000000</td>
      <td>2019.000000</td>
      <td>110.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>



# 分析数据

## 每天销量分析


```python
# 字符串转化成时间类型格式，用年月日显示，然后取出这列
df['time']=pd.to_datetime(df['time'],format='%Y/%m/%d')
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 8757 entries, 0 to 8756
    Data columns (total 6 columns):
    author       8757 non-null object
    rating       8757 non-null int64
    time         8757 non-null datetime64[ns]
    year         8757 non-null int64
    amount       8757 non-null int64
    frequency    8757 non-null int64
    dtypes: datetime64[ns](1), int64(4), object(1)
    memory usage: 410.6+ KB
    


```python
df.groupby('time')['rating'].count() #用time列分组，随便取一列，然后计数
```




    time
    2016-08-02     1
    2016-08-03     1
    2016-08-05     2
    2016-08-06     1
    2016-08-07     1
                  ..
    2019-02-24    21
    2019-02-25    20
    2019-02-26    17
    2019-02-27    15
    2019-02-28    15
    Name: rating, Length: 895, dtype: int64




```python
df.groupby('time')['rating'].count().plot(figsize=(12,4))
# 整体来看每日销量呈现上升趋势，但是在18年5月前后（2，3，4）出现一次较大的波动，销量急剧下滑，有可能是台风影响，或者运营推广不利
# 16年9月-17年1月，销量非常仰慕，每天平均2-3张门票，猜测：101观景台门票刚刚上线发售，观景台刚刚开放
```




    <matplotlib.axes._subplots.AxesSubplot at 0x208c882e9a0>




![png](output_9_1.png)


## 每月的销量分析


```python
# 取出time列的值，转换成时间格式，精确到月份
df['month']=df['time'].values.astype('datetime64[M]') #保留月份精度的日期
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
  </tbody>
</table>
</div>




```python
 # 按照月份进行计数
df.groupby('month')['rating'].count().plot(figsize=(12,4))
plt.xlabel('月份')
plt.ylabel('销售数量')
plt.title('16-19年每月销量分析')
# 月份整体销量依然呈现上升趋势，但是在18年2，3，4月份销量下滑明显。跟每天销量下降有关。
```




    Text(0.5, 1.0, '16-19年每月销量分析')




![png](output_12_1.png)


## 每个用户的购买量和消费金额分析


```python
# merge用法 ，相当于sql当中join:
df1=pd.DataFrame({
    'name':['zhangsan','lisi'],
    'group':['A','B']
})
df2=pd.DataFrame({
    'name':['zhangsan','lisi'],
    'score':[88,90]
})
pd.merge(left=df1,right=df2,on='name')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>group</th>
      <th>score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>zhangsan</td>
      <td>A</td>
      <td>88</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lisi</td>
      <td>B</td>
      <td>90</td>
    </tr>
  </tbody>
</table>
</div>




```python
# merge用法 ，相当于sql当中join:
df1=pd.DataFrame({
    'name':['zhangsan','lisi'],
    'group':['A','B']
})
df2=pd.DataFrame({
    'name':['wangwu','lisi'],
    'score':[88,90],
    'group':['C','D']
})
pd.merge(left=df1,right=df2,on='name',how='inner',suffixes=['_1','_2'])
# left:左表  right:右表 on:关联字段  how:inner(默认值，交集)|outer(并集)|left(只保留左侧)|right(只保留右侧)
# suffixes:如果两个表中有多个相同列，用这个函数给的值 进行区分(默认值xy)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>group_1</th>
      <th>score</th>
      <th>group_2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>lisi</td>
      <td>B</td>
      <td>90</td>
      <td>D</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 按照游客分组，统计每个游客的购买次数
grouped_count_author=df.groupby('author')['frequency'].count().reset_index()
# 按照游客分组，统计每个游客的消费金额
grouped_sum_amount=df.groupby('author')['amount'].sum().reset_index()
grouped_sum_amount.tail(60)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7662</th>
      <td>yueah cin</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7663</th>
      <td>yuen ha</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7664</th>
      <td>yuen ping michelle</td>
      <td>220</td>
    </tr>
    <tr>
      <th>7665</th>
      <td>yuh-ming</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7666</th>
      <td>yuhao</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7667</th>
      <td>yuhuan</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7668</th>
      <td>yuk wa</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7669</th>
      <td>yuk yin</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7670</th>
      <td>yuki</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7671</th>
      <td>yukshan</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7672</th>
      <td>yun chieh</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7673</th>
      <td>yun han</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7674</th>
      <td>yunching</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7675</th>
      <td>yung min</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7676</th>
      <td>yungi</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7677</th>
      <td>yungyi</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7678</th>
      <td>yunjeong</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7679</th>
      <td>yunjin</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7680</th>
      <td>yunmi</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7681</th>
      <td>yunsuk</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7682</th>
      <td>yunus</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7683</th>
      <td>yvonne</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7684</th>
      <td>zazah jane</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7685</th>
      <td>zheng qiang</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7686</th>
      <td>zheng wei</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7687</th>
      <td>zhi hao</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7688</th>
      <td>zhuang wei</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7689</th>
      <td>ziv</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7690</th>
      <td>ziyi</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7691</th>
      <td>zona</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7692</th>
      <td>zubi</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7693</th>
      <td>中鴻</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7694</th>
      <td>久茵</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7695</th>
      <td>仰立</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7696</th>
      <td>佳鈴</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7697</th>
      <td>千瑞</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7698</th>
      <td>受恩</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7699</th>
      <td>嘉文</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7700</th>
      <td>國俊</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7701</th>
      <td>國隆</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7702</th>
      <td>士齊</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7703</th>
      <td>孟璇</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7704</th>
      <td>宛庭</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7705</th>
      <td>宜暹</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7706</th>
      <td>建翔</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7707</th>
      <td>志坤</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7708</th>
      <td>怡婷</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7709</th>
      <td>懿馨</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7710</th>
      <td>承澎</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7711</th>
      <td>振裕</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7712</th>
      <td>曉君</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7713</th>
      <td>洪</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7714</th>
      <td>淑楨</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7715</th>
      <td>素鳳</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7716</th>
      <td>翔</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7717</th>
      <td>芊羽</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7718</th>
      <td>華山</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7719</th>
      <td>蘇</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7720</th>
      <td>郁君</td>
      <td>110</td>
    </tr>
    <tr>
      <th>7721</th>
      <td>青慧</td>
      <td>110</td>
    </tr>
  </tbody>
</table>
</div>




```python
grouped_count_author.tail(60)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>frequency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7662</th>
      <td>yueah cin</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7663</th>
      <td>yuen ha</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7664</th>
      <td>yuen ping michelle</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7665</th>
      <td>yuh-ming</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7666</th>
      <td>yuhao</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7667</th>
      <td>yuhuan</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7668</th>
      <td>yuk wa</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7669</th>
      <td>yuk yin</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7670</th>
      <td>yuki</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7671</th>
      <td>yukshan</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7672</th>
      <td>yun chieh</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7673</th>
      <td>yun han</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7674</th>
      <td>yunching</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7675</th>
      <td>yung min</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7676</th>
      <td>yungi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7677</th>
      <td>yungyi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7678</th>
      <td>yunjeong</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7679</th>
      <td>yunjin</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7680</th>
      <td>yunmi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7681</th>
      <td>yunsuk</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7682</th>
      <td>yunus</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7683</th>
      <td>yvonne</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7684</th>
      <td>zazah jane</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7685</th>
      <td>zheng qiang</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7686</th>
      <td>zheng wei</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7687</th>
      <td>zhi hao</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7688</th>
      <td>zhuang wei</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7689</th>
      <td>ziv</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7690</th>
      <td>ziyi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7691</th>
      <td>zona</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7692</th>
      <td>zubi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7693</th>
      <td>中鴻</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7694</th>
      <td>久茵</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7695</th>
      <td>仰立</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7696</th>
      <td>佳鈴</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7697</th>
      <td>千瑞</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7698</th>
      <td>受恩</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7699</th>
      <td>嘉文</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7700</th>
      <td>國俊</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7701</th>
      <td>國隆</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7702</th>
      <td>士齊</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7703</th>
      <td>孟璇</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7704</th>
      <td>宛庭</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7705</th>
      <td>宜暹</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7706</th>
      <td>建翔</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7707</th>
      <td>志坤</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7708</th>
      <td>怡婷</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7709</th>
      <td>懿馨</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7710</th>
      <td>承澎</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7711</th>
      <td>振裕</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7712</th>
      <td>曉君</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7713</th>
      <td>洪</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7714</th>
      <td>淑楨</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7715</th>
      <td>素鳳</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7716</th>
      <td>翔</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7717</th>
      <td>芊羽</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7718</th>
      <td>華山</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7719</th>
      <td>蘇</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7720</th>
      <td>郁君</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7721</th>
      <td>青慧</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
user_purchase_retention=pd.merge(left=grouped_count_author,
                                right=grouped_sum_amount,
                                on='author',
                                how='inner')
user_purchase_retention.tail(60)
user_purchase_retention.plot.scatter(x='frequency',y='amount',figsize=(12,4))
plt.title('用户的购买次数和消费金额关系图')
plt.xlabel('购物次数')
plt.ylabel('消费金额')
# 结论，斜率就是门票的价格110，用户的消费金额和消费次数呈现线性关系
```




    Text(0, 0.5, '消费金额')




![png](output_18_1.png)


## 用户购买门票数量分析


```python
df.groupby('author')['frequency'].count().plot.hist(bins=50)# 影响柱子的宽度，宽度=（最大值 -最小值）/bins
plt.xlim(1,17)
plt.xlabel('购买数量')
plt.ylabel('人数')
plt.title('用户购买门票数量直方图')
# 绝大多数用户购买过1张门票，用户在7000人次左右
# 少数人购买过2-4张门票，猜测是台北周边用户
```




    Text(0.5, 1.0, '用户购买门票数量直方图')




![png](output_20_1.png)


## 用户购买门票2次及以上情况分析


```python
df_frequency_2=df.groupby('author').count().reset_index()
df_frequency_2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>wenbiao</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Goh Yu Wen Eunice</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Hui Shan</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Huihui</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>KO-CHENG</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_frequency_2[df_frequency_2['frequency']>=2]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>49</th>
      <td>ANGELINA</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>74</th>
      <td>ARLENE</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Aaron</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Abigail</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>93</th>
      <td>Ace</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7615</th>
      <td>yanyan</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7626</th>
      <td>yewon</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7646</th>
      <td>yinung</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7660</th>
      <td>yu</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7664</th>
      <td>yuen ping michelle</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>603 rows × 7 columns</p>
</div>




```python
df_frequency_2[df_frequency_2['frequency']>=2].groupby('author')['frequency'].sum().plot.hist(bins=50)
plt.xlabel('购买数量')
plt.ylabel('人数')
plt.title('购买门票在2次及以上的用户数量')
# 消费2次的用户在整体上占比比较大，大于2次的用户占小部分，用户购买次数最多为8次
```




    Text(0.5, 1.0, '购买门票在2次及以上的用户数量')




![png](output_24_1.png)


## 查看购买2次及以上的具体人数


```python
df_frequency_2[df_frequency_2['frequency']>=2]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>49</th>
      <td>ANGELINA</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>74</th>
      <td>ARLENE</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Aaron</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Abigail</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>93</th>
      <td>Ace</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7615</th>
      <td>yanyan</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7626</th>
      <td>yewon</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7646</th>
      <td>yinung</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7660</th>
      <td>yu</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7664</th>
      <td>yuen ping michelle</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>603 rows × 7 columns</p>
</div>




```python
df_frequency_2[df_frequency_2['frequency']>=2].groupby('frequency')['author'].count()
# 除去购买1次的顾客，可以看出购买2次的有402人，购买3次的有99人，以此类推得知，大多数人倾向于购买2-5次
```




    frequency
    2     402
    3      99
    4      49
    5      25
    6      13
    7       7
    8       4
    11      1
    13      1
    15      1
    18      1
    Name: author, dtype: int64



## 购买次数在1-5次之间的用户占比分析


```python
# 对用户author进行分组  取出消费频率  进行逻辑判断（1-5） 数据可视化（pie)
df_frequency_gte_1=df.groupby('author')['frequency'].count().reset_index() # gte是>=的意思
df_frequency_gte_1.tail(60)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>frequency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7662</th>
      <td>yueah cin</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7663</th>
      <td>yuen ha</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7664</th>
      <td>yuen ping michelle</td>
      <td>2</td>
    </tr>
    <tr>
      <th>7665</th>
      <td>yuh-ming</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7666</th>
      <td>yuhao</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7667</th>
      <td>yuhuan</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7668</th>
      <td>yuk wa</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7669</th>
      <td>yuk yin</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7670</th>
      <td>yuki</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7671</th>
      <td>yukshan</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7672</th>
      <td>yun chieh</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7673</th>
      <td>yun han</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7674</th>
      <td>yunching</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7675</th>
      <td>yung min</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7676</th>
      <td>yungi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7677</th>
      <td>yungyi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7678</th>
      <td>yunjeong</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7679</th>
      <td>yunjin</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7680</th>
      <td>yunmi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7681</th>
      <td>yunsuk</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7682</th>
      <td>yunus</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7683</th>
      <td>yvonne</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7684</th>
      <td>zazah jane</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7685</th>
      <td>zheng qiang</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7686</th>
      <td>zheng wei</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7687</th>
      <td>zhi hao</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7688</th>
      <td>zhuang wei</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7689</th>
      <td>ziv</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7690</th>
      <td>ziyi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7691</th>
      <td>zona</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7692</th>
      <td>zubi</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7693</th>
      <td>中鴻</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7694</th>
      <td>久茵</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7695</th>
      <td>仰立</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7696</th>
      <td>佳鈴</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7697</th>
      <td>千瑞</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7698</th>
      <td>受恩</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7699</th>
      <td>嘉文</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7700</th>
      <td>國俊</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7701</th>
      <td>國隆</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7702</th>
      <td>士齊</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7703</th>
      <td>孟璇</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7704</th>
      <td>宛庭</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7705</th>
      <td>宜暹</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7706</th>
      <td>建翔</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7707</th>
      <td>志坤</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7708</th>
      <td>怡婷</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7709</th>
      <td>懿馨</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7710</th>
      <td>承澎</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7711</th>
      <td>振裕</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7712</th>
      <td>曉君</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7713</th>
      <td>洪</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7714</th>
      <td>淑楨</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7715</th>
      <td>素鳳</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7716</th>
      <td>翔</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7717</th>
      <td>芊羽</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7718</th>
      <td>華山</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7719</th>
      <td>蘇</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7720</th>
      <td>郁君</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7721</th>
      <td>青慧</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#购买次数>=1
df_frequency_gte_1=df_frequency_gte_1[df_frequency_gte_1['frequency']>=1]
#购买次数<=5,对frequency进行分给，取出frequency这列，然后计数
values=df_frequency_gte_1[df_frequency_gte_1['frequency']<=5].groupby('frequency')['frequency'].count()
values
```




    frequency
    1    7119
    2     402
    3      99
    4      49
    5      25
    Name: frequency, dtype: int64




```python
#把 series转成list类型才能绘制饼图
values=list(df_frequency_gte_1[df_frequency_gte_1['frequency']<=5].groupby('frequency')['frequency'].count())
values
```




    [7119, 402, 99, 49, 25]




```python
# 绘制饼图
labels=['1 time','two times','three times','four times','five times']
plt.pie(values,labels=labels,autopct='%1.1f%%')
plt.title('购买次数在1-5次之间的用户占比')
plt.legend()
```




    <matplotlib.legend.Legend at 0x208ca359a30>




![png](output_32_1.png)



```python
# 因为上面的图很密集，所以我们把1次的顾客砍掉，分析购买2-5次的
```

## 购买次数在2-5次之间的用户占比分析


```python
# 对用户author进行分组  取出消费频率  进行逻辑判断（2-5） 数据可视化（pie)
df_frequency_gte_2=df.groupby('author')['frequency'].count().reset_index() # gte是>=的意思
df_frequency_gte_1.tail(60)
#购买次数>=2
df_frequency_gte_2=df_frequency_gte_2[df_frequency_gte_2['frequency']>=2]
#购买次数<=5,对frequency进行分给，取出frequency这列，然后计数
values=list(df_frequency_gte_2[df_frequency_gte_2['frequency']<=5].groupby('frequency')['frequency'].count())
values
# 绘制饼图
labels=['two times','three times','four times','five times']
plt.pie(values,labels=labels,autopct='%1.1f%%')
plt.title('购买次数在2-5次之间的用户占比')
plt.legend()
# 在购物次数在2-5次的用户中，其中消费2次的占比70%，消费3次占比17%，4次占比8.5%，5次占比4.3%
# 消费2-3次的用户依然很重要
# 消费次数在4-5次比重较少，需要针对性的对2-3次的用户进行引导
# 消费次数在1次的用户，可以尝试转化到消费2-3次
```




    <matplotlib.legend.Legend at 0x208ca3fe3a0>




![png](output_35_1.png)


## 复购率分析


```python
# 复购率：在某一时间窗口内（多指一个月）内消费次数在两次及以上的用户在总消费用户的占比
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
  </tbody>
</table>
</div>




```python
pivot_count=df.pivot_table(index='author',
                           columns='month',
                           values='frequency',
                           aggfunc='count').fillna(0)
pivot_count.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
    <tr>
      <th>author</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>wenbiao</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Goh Yu Wen Eunice</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Hui Shan</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Huihui</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>KO-CHENG</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 31 columns</p>
</div>




```python
# 三种情况：
#消费次数>1，为复购用户，用1表示
#消费次数=1，为非复购用户，用0表示
#消费次数=0，为未消费用户，用na表示

#applymap:df,处理每一个元素
#apply:df，处理每一行（axis=1)或者每一列数据（axis=0)
#map:Serise,处理每一个元素（在一维数组中）

# 处理完变量之后，重新存到pivot_count里
pivot_count=pivot_count.applymap(lambda x:1 if x>1 else np.NAN if x==0 else 0)
pivot_count.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
    <tr>
      <th>author</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>wenbiao</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Goh Yu Wen Eunice</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Hui Shan</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Huihui</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>KO-CHENG</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 31 columns</p>
</div>




```python
pivot_count.sum()#每月有多少人复购
```




    month
    2016-08-01     0.0
    2016-09-01     2.0
    2016-10-01     0.0
    2016-11-01     0.0
    2016-12-01     1.0
    2017-01-01     0.0
    2017-02-01     1.0
    2017-03-01     0.0
    2017-04-01     3.0
    2017-05-01     3.0
    2017-06-01     2.0
    2017-07-01     1.0
    2017-08-01     1.0
    2017-09-01     4.0
    2017-10-01     4.0
    2017-11-01     4.0
    2017-12-01     3.0
    2018-01-01     6.0
    2018-02-01     2.0
    2018-03-01     2.0
    2018-04-01     1.0
    2018-05-01     5.0
    2018-06-01     5.0
    2018-07-01     5.0
    2018-08-01     7.0
    2018-09-01     9.0
    2018-10-01     4.0
    2018-11-01     7.0
    2018-12-01    12.0
    2019-01-01    10.0
    2019-02-01     4.0
    dtype: float64




```python
pivot_count.count() #每月总的用户数（计数）
```




    month
    2016-08-01     15
    2016-09-01     27
    2016-10-01     61
    2016-11-01     64
    2016-12-01    107
    2017-01-01     84
    2017-02-01     89
    2017-03-01    116
    2017-04-01    147
    2017-05-01    162
    2017-06-01    169
    2017-07-01    204
    2017-08-01    233
    2017-09-01    236
    2017-10-01    321
    2017-11-01    361
    2017-12-01    381
    2018-01-01    404
    2018-02-01    254
    2018-03-01    309
    2018-04-01    148
    2018-05-01    314
    2018-06-01    429
    2018-07-01    474
    2018-08-01    479
    2018-09-01    393
    2018-10-01    543
    2018-11-01    550
    2018-12-01    588
    2019-01-01    569
    2019-02-01    406
    dtype: int64




```python
# 计算复购率并画出拆线图
(pivot_count.sum()/pivot_count.count()).plot()
plt.xlabel('时间(月)')
plt.ylabel('百分比（%）')
plt.title('16-19年每月用户复购率')
# 16年9月份复购率最高达到了7.5%，然后开始下降，趋于平稳在1.2%
```




    Text(0.5, 1.0, '16-19年每月用户复购率')




![png](output_42_1.png)


## 复购用户人数


```python
pivot_count.sum()
```




    month
    2016-08-01     0.0
    2016-09-01     2.0
    2016-10-01     0.0
    2016-11-01     0.0
    2016-12-01     1.0
    2017-01-01     0.0
    2017-02-01     1.0
    2017-03-01     0.0
    2017-04-01     3.0
    2017-05-01     3.0
    2017-06-01     2.0
    2017-07-01     1.0
    2017-08-01     1.0
    2017-09-01     4.0
    2017-10-01     4.0
    2017-11-01     4.0
    2017-12-01     3.0
    2018-01-01     6.0
    2018-02-01     2.0
    2018-03-01     2.0
    2018-04-01     1.0
    2018-05-01     5.0
    2018-06-01     5.0
    2018-07-01     5.0
    2018-08-01     7.0
    2018-09-01     9.0
    2018-10-01     4.0
    2018-11-01     7.0
    2018-12-01    12.0
    2019-01-01    10.0
    2019-02-01     4.0
    dtype: float64




```python
pivot_count.sum().plot()
plt.xlabel('时间/月')
plt.ylabel('复购人数')
plt.title('16-19年每月的复购人数拆线图')
# 整体来看，复购人数呈现上升趋势
# 但是在18年2，3，4，10和19年2月，复购人数下降较为明显，出现异常信号，需要和业务部门具体分析
```




    Text(0.5, 1.0, '16-19年每月的复购人数拆线图')




![png](output_45_1.png)


## 回购率分析


```python
# 回购率：在某一个时间窗口内消费过的用户，在下一个时间窗口仍旧消费的占比
# 举个例子：当前月消费用户人数1000人，其中200人在下一个月仍旧进行了消费，回购率200/1000=20%
pivot_purchase=df.pivot_table(index='author',
                           columns='month',
                           values='frequency',
                           aggfunc='count').fillna(0)
pivot_purchase.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
    <tr>
      <th>author</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>wenbiao</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Goh Yu Wen Eunice</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Hui Shan</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Huihui</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>KO-CHENG</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 31 columns</p>
</div>




```python
len(pivot_purchase.columns) #得出一共有31个月份
```




    31




```python
def purchase_return(data):# data:代表的是每一名游客的所有月份消费记录
    status=[]# 存储每一个月回购状态
    for i in range(30): # 遍历每一个月（最后一个月除外）
        ####本月消费
        if data[i]==1:
            if data[i+1]==1:# 下个月有消费，是回购用户，1
                status.append(1)
            else: #na|未消费
                 status.append(0)# 非回购用户，0
        else:####本月未消费
            status.append(np.NAN)
    status.append(np.NAN) # 前面30个月循环，最后一个月统一加nan
    return pd.Series(status,pivot_purchase.columns)# 返回一行数据，对应值 (status,pivot_purchase.columns)
pivot_purchase_return=pivot_purchase.apply(purchase_return,axis=1)   #用户回购状态
```


```python
pivot_purchase_return.sum() #月回购人数
```




    month
    2016-08-01     0.0
    2016-09-01     0.0
    2016-10-01     0.0
    2016-11-01     0.0
    2016-12-01     2.0
    2017-01-01     1.0
    2017-02-01     1.0
    2017-03-01     2.0
    2017-04-01     2.0
    2017-05-01     2.0
    2017-06-01     0.0
    2017-07-01     3.0
    2017-08-01     2.0
    2017-09-01     3.0
    2017-10-01     3.0
    2017-11-01     6.0
    2017-12-01     4.0
    2018-01-01     2.0
    2018-02-01     4.0
    2018-03-01     3.0
    2018-04-01     2.0
    2018-05-01    12.0
    2018-06-01    14.0
    2018-07-01    11.0
    2018-08-01     6.0
    2018-09-01    10.0
    2018-10-01    12.0
    2018-11-01    17.0
    2018-12-01     8.0
    2019-01-01     8.0
    2019-02-01     0.0
    dtype: float64




```python
pivot_purchase_return.count() #月总的用户数
```




    month
    2016-08-01     15
    2016-09-01     25
    2016-10-01     61
    2016-11-01     64
    2016-12-01    106
    2017-01-01     84
    2017-02-01     88
    2017-03-01    116
    2017-04-01    144
    2017-05-01    159
    2017-06-01    167
    2017-07-01    203
    2017-08-01    232
    2017-09-01    232
    2017-10-01    317
    2017-11-01    357
    2017-12-01    378
    2018-01-01    398
    2018-02-01    252
    2018-03-01    307
    2018-04-01    147
    2018-05-01    309
    2018-06-01    424
    2018-07-01    469
    2018-08-01    472
    2018-09-01    384
    2018-10-01    539
    2018-11-01    543
    2018-12-01    576
    2019-01-01    559
    2019-02-01      0
    dtype: int64




```python
# 求回购率，并绘制拆线较
(pivot_purchase_return.sum() /pivot_purchase_return.count()).plot()
plt.title('16年-19年每月的回购率')
plt.xlabel('月份')
plt.ylabel('回购率%')
#回购率最高在18年6月份，达到4%
#整体来看，回购率呈现微弱上升趋势
#出现 了几次较大下滑，分别是17年6月份，18年1月份，18年8月份，19年1月份
```




    Text(0, 0.5, '回购率%')




![png](output_52_1.png)


## 回购人数分析


```python
pivot_purchase_return.sum().plot()
plt.title('16年-19年每月的回购人数')
plt.xlabel('月份')
plt.ylabel('回购人数')
#整体呈现上升趋势，回购人数最多时在18年11月份，人数为17人
#其中有几次回购人数下降较为明显，主要在分别是17年6月，18年1月，18年8月，19年1月
```




    Text(0, 0.5, '回购人数')




![png](output_54_1.png)



```python
# 想看具体人数，可以打印出来
print(pivot_purchase_return.sum())
```

    month
    2016-08-01     0.0
    2016-09-01     0.0
    2016-10-01     0.0
    2016-11-01     0.0
    2016-12-01     2.0
    2017-01-01     1.0
    2017-02-01     1.0
    2017-03-01     2.0
    2017-04-01     2.0
    2017-05-01     2.0
    2017-06-01     0.0
    2017-07-01     3.0
    2017-08-01     2.0
    2017-09-01     3.0
    2017-10-01     3.0
    2017-11-01     6.0
    2017-12-01     4.0
    2018-01-01     2.0
    2018-02-01     4.0
    2018-03-01     3.0
    2018-04-01     2.0
    2018-05-01    12.0
    2018-06-01    14.0
    2018-07-01    11.0
    2018-08-01     6.0
    2018-09-01    10.0
    2018-10-01    12.0
    2018-11-01    17.0
    2018-12-01     8.0
    2019-01-01     8.0
    2019-02-01     0.0
    dtype: float64
    

## 每个月分层用户占比情况


```python
# 活跃用户、不活跃用户，回流用户、新用户
def active_status(data): # data:每一行数据（共31列）
    status=[]# 存储用户31个月的状态（new\active\unactive\return\unreg)
    for i in range(31):
        #判断本月没有消费==0
        if data[i]==0:
            if len(status)==0:#前几个月没有任何记录（也就是97年1月==0）
                status.append('unreg')
            else:# 之前的月份有记录（判断上一个月状态）
                if status[i-1]=='unreg':#一直没有消费过
                    status.append('unreg')
                else:# 上个月的状态可能是：new\active\unative\return
                    status.append('unactive')
        else:# 本月有消费==1
            if len(status)==0:
                status.append('new')# 第一次消费
            else:# 之前的月份有记录（判断上一个月状态）
                if status[i-1]=='unactive':
                    status.append('return')#前几个月不活跃，现在又回来消费了，回流用户
                elif status[i-1]=='unreg':
                    status.append('new')#第一次消费
                    
                else:#new\active
                    status.append('active')#活跃用户
                    
    return pd.Series(status,pivot_purchase.columns) #值：status,列名：31个月份

pivot_purchase_states=pivot_purchase.apply(active_status,axis=1)# 得到用户分层结果
pivot_purchase_states.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
    <tr>
      <th>author</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>wenbiao</th>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>...</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>Goh Yu Wen Eunice</th>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>Hui Shan</th>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>Huihui</th>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>KO-CHENG</th>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>...</td>
      <td>unreg</td>
      <td>unreg</td>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 31 columns</p>
</div>




```python
# unreg不去考虑，替换成NAN
pivot_purchase_states.replace('unreg',np.NaN)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
    <tr>
      <th>author</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>wenbiao</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>Goh Yu Wen Eunice</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>Hui Shan</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>Huihui</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>KO-CHENG</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>new</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>芊羽</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>華山</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>蘇</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>郁君</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
    <tr>
      <th>青慧</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
      <td>unactive</td>
    </tr>
  </tbody>
</table>
<p>7722 rows × 31 columns</p>
</div>




```python
pivot_purchase_states.replace('unreg',np.NaN).apply(pd.value_counts)#apply默认按列操作，也就是axis=0
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>active</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>2</td>
      <td>13</td>
      <td>14</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>14</td>
      <td>20</td>
      <td>11</td>
      <td>9</td>
    </tr>
    <tr>
      <th>new</th>
      <td>15.0</td>
      <td>27.0</td>
      <td>61.0</td>
      <td>63.0</td>
      <td>106.0</td>
      <td>81</td>
      <td>85</td>
      <td>112</td>
      <td>142</td>
      <td>156</td>
      <td>...</td>
      <td>266</td>
      <td>382</td>
      <td>407</td>
      <td>420</td>
      <td>330</td>
      <td>464</td>
      <td>461</td>
      <td>503</td>
      <td>490</td>
      <td>352</td>
    </tr>
    <tr>
      <th>return</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>4</td>
      <td>...</td>
      <td>46</td>
      <td>34</td>
      <td>53</td>
      <td>48</td>
      <td>52</td>
      <td>68</td>
      <td>75</td>
      <td>65</td>
      <td>68</td>
      <td>45</td>
    </tr>
    <tr>
      <th>unactive</th>
      <td>NaN</td>
      <td>15.0</td>
      <td>42.0</td>
      <td>102.0</td>
      <td>165.0</td>
      <td>269</td>
      <td>349</td>
      <td>434</td>
      <td>545</td>
      <td>686</td>
      <td>...</td>
      <td>3599</td>
      <td>3866</td>
      <td>4228</td>
      <td>4643</td>
      <td>5059</td>
      <td>5373</td>
      <td>5827</td>
      <td>6292</td>
      <td>6801</td>
      <td>7316</td>
    </tr>
  </tbody>
</table>
<p>4 rows × 31 columns</p>
</div>




```python
# 把得到的值存储到一个新的变量里面去
pivot_status_count=pivot_purchase_states.replace('unreg',np.NaN).apply(pd.value_counts)
```


```python
pivot_status_count.T.plot.area()
# 可以看出，红色（不活跃用户）占据网站用户的主体
# 橙色（新用户）从17年的1月-19年1月，呈现上升趋势；但是在18年4月份左右，新用户的量突然急剧下降，异常信号
# 以后，新用户又开始慢慢上涨，恢复稳定状态
# 绿色（回流用户），一直维持维持稳定状态，但是在18年2-4月份，出现异常下降情况，异常信号
```




    <matplotlib.axes._subplots.AxesSubplot at 0x208ce6a2c70>




![png](output_61_1.png)


## 每月不同用户的占比


```python
# 4种用户分别占总人数的比例(x.sum是整列用户之和)
pivot_status_count.apply(lambda x:x/x.sum()) #apply默认按列操作
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>active</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.005666</td>
      <td>0.002283</td>
      <td>0.001818</td>
      <td>0.002890</td>
      <td>0.002358</td>
      <td>...</td>
      <td>0.000511</td>
      <td>0.003027</td>
      <td>0.002977</td>
      <td>0.002148</td>
      <td>0.002018</td>
      <td>0.001859</td>
      <td>0.002195</td>
      <td>0.002907</td>
      <td>0.001493</td>
      <td>0.001166</td>
    </tr>
    <tr>
      <th>new</th>
      <td>1.0</td>
      <td>0.642857</td>
      <td>0.592233</td>
      <td>0.379518</td>
      <td>0.389706</td>
      <td>0.229462</td>
      <td>0.194064</td>
      <td>0.203636</td>
      <td>0.205202</td>
      <td>0.183962</td>
      <td>...</td>
      <td>0.067979</td>
      <td>0.088941</td>
      <td>0.086559</td>
      <td>0.081999</td>
      <td>0.060528</td>
      <td>0.078431</td>
      <td>0.072291</td>
      <td>0.073110</td>
      <td>0.066486</td>
      <td>0.045584</td>
    </tr>
    <tr>
      <th>return</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.006024</td>
      <td>0.003676</td>
      <td>0.002833</td>
      <td>0.006849</td>
      <td>0.005455</td>
      <td>0.004335</td>
      <td>0.004717</td>
      <td>...</td>
      <td>0.011756</td>
      <td>0.007916</td>
      <td>0.011272</td>
      <td>0.009371</td>
      <td>0.009538</td>
      <td>0.011494</td>
      <td>0.011761</td>
      <td>0.009448</td>
      <td>0.009227</td>
      <td>0.005828</td>
    </tr>
    <tr>
      <th>unactive</th>
      <td>NaN</td>
      <td>0.357143</td>
      <td>0.407767</td>
      <td>0.614458</td>
      <td>0.606618</td>
      <td>0.762040</td>
      <td>0.796804</td>
      <td>0.789091</td>
      <td>0.787572</td>
      <td>0.808962</td>
      <td>...</td>
      <td>0.919755</td>
      <td>0.900116</td>
      <td>0.899192</td>
      <td>0.906482</td>
      <td>0.927916</td>
      <td>0.908215</td>
      <td>0.913753</td>
      <td>0.914535</td>
      <td>0.922795</td>
      <td>0.947423</td>
    </tr>
  </tbody>
</table>
<p>4 rows × 31 columns</p>
</div>




```python
return_rate=pivot_status_count.apply(lambda x:x/x.sum())
return_rate.T.plot()
# 在17年1月份过后，网站用户主体由不活跃用户组成，新用户占比开始慢慢下降，并且趋于稳定，稳定在10%左右
# 活跃用户和回流用户，一直很稳定，并且占比较小
# 16年9月前后，新用户和不活跃用户，发生较大的变化，猜测是活动或者节假日造成的
```




    <matplotlib.axes._subplots.AxesSubplot at 0x208caeb4400>




![png](output_64_1.png)



```python
# 因为绿色线和蓝色线重合了，所以我们单独把这两个拿出来分析
```

## 每月活跃用户的占比


```python
return_rate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>month</th>
      <th>2016-08-01</th>
      <th>2016-09-01</th>
      <th>2016-10-01</th>
      <th>2016-11-01</th>
      <th>2016-12-01</th>
      <th>2017-01-01</th>
      <th>2017-02-01</th>
      <th>2017-03-01</th>
      <th>2017-04-01</th>
      <th>2017-05-01</th>
      <th>...</th>
      <th>2018-05-01</th>
      <th>2018-06-01</th>
      <th>2018-07-01</th>
      <th>2018-08-01</th>
      <th>2018-09-01</th>
      <th>2018-10-01</th>
      <th>2018-11-01</th>
      <th>2018-12-01</th>
      <th>2019-01-01</th>
      <th>2019-02-01</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>active</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.005666</td>
      <td>0.002283</td>
      <td>0.001818</td>
      <td>0.002890</td>
      <td>0.002358</td>
      <td>...</td>
      <td>0.000511</td>
      <td>0.003027</td>
      <td>0.002977</td>
      <td>0.002148</td>
      <td>0.002018</td>
      <td>0.001859</td>
      <td>0.002195</td>
      <td>0.002907</td>
      <td>0.001493</td>
      <td>0.001166</td>
    </tr>
    <tr>
      <th>new</th>
      <td>1.0</td>
      <td>0.642857</td>
      <td>0.592233</td>
      <td>0.379518</td>
      <td>0.389706</td>
      <td>0.229462</td>
      <td>0.194064</td>
      <td>0.203636</td>
      <td>0.205202</td>
      <td>0.183962</td>
      <td>...</td>
      <td>0.067979</td>
      <td>0.088941</td>
      <td>0.086559</td>
      <td>0.081999</td>
      <td>0.060528</td>
      <td>0.078431</td>
      <td>0.072291</td>
      <td>0.073110</td>
      <td>0.066486</td>
      <td>0.045584</td>
    </tr>
    <tr>
      <th>return</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.006024</td>
      <td>0.003676</td>
      <td>0.002833</td>
      <td>0.006849</td>
      <td>0.005455</td>
      <td>0.004335</td>
      <td>0.004717</td>
      <td>...</td>
      <td>0.011756</td>
      <td>0.007916</td>
      <td>0.011272</td>
      <td>0.009371</td>
      <td>0.009538</td>
      <td>0.011494</td>
      <td>0.011761</td>
      <td>0.009448</td>
      <td>0.009227</td>
      <td>0.005828</td>
    </tr>
    <tr>
      <th>unactive</th>
      <td>NaN</td>
      <td>0.357143</td>
      <td>0.407767</td>
      <td>0.614458</td>
      <td>0.606618</td>
      <td>0.762040</td>
      <td>0.796804</td>
      <td>0.789091</td>
      <td>0.787572</td>
      <td>0.808962</td>
      <td>...</td>
      <td>0.919755</td>
      <td>0.900116</td>
      <td>0.899192</td>
      <td>0.906482</td>
      <td>0.927916</td>
      <td>0.908215</td>
      <td>0.913753</td>
      <td>0.914535</td>
      <td>0.922795</td>
      <td>0.947423</td>
    </tr>
  </tbody>
</table>
<p>4 rows × 31 columns</p>
</div>




```python
return_rate.T['active'].plot(figsize=(12,6))
plt.xlabel('时间（月份）')
plt.ylabel('百分比')
plt.title('每月活跃用户的占比分析')
# 在17年1月份活跃用户占比较高，在0.5%，但是在1-2月份，急剧下降，猜测：春节的影响，或者温度
# 结合历年1-2月份销量来看，都会出现一定比例的下降，再次验证我们的猜测：春节的影响
# 在18年2月和5月出现 异常，门票销量下降，猜测：雨水或者台风影响
```




    Text(0.5, 1.0, '每月活跃用户的占比分析')




![png](output_68_1.png)


## 每月回流用户的占比


```python
return_rate.T['return'].plot(figsize=(12,6))
plt.xlabel('时间（月份）')
plt.ylabel('百分比')
plt.title('每月回流用户的占比分析')
# 整体来看，回流用户比例上升趋势，但是波动较大
# 在17年1月和6月，18年4月，19年2月，回流用户比例都出现了较大幅度下降，表现为异常信号
# 无论是回流用户还是活跃用户，在以上几个月份中都表现出下降趋势。
```




    Text(0.5, 1.0, '每月回流用户的占比分析')




![png](output_70_1.png)



```python
# return_rate.T['return'].mean() #回流用户的平均值 在0.73%左右
np.mean(return_rate.T['return']) #用这种方法速度快些
# 在17年9月份以后，仅有两个异常夸海口在平均值以下
# 在17年9月份之前，所有数据都显示出回流用户比例低于平均值 ，猜测：景点开放不久，很多游客尚未发现本景点
# 本平台刚上线不久
```




    0.00736823576229978



## 用户的生命周期


```python
# 计算方式：每一个用户最后一个购买商品的时间-用户第一次购买商品的时间，转换成天数 ，即为生命周期
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8752</th>
      <td>Jonathan</td>
      <td>100</td>
      <td>2016-08-06</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8753</th>
      <td>Oliver Stephen Ah Kam</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8754</th>
      <td>Halley</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8755</th>
      <td>ANDREW WEIQIANG</td>
      <td>100</td>
      <td>2016-08-03</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>WEI CHIEH</td>
      <td>60</td>
      <td>2016-08-02</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
  </tbody>
</table>
<p>8757 rows × 7 columns</p>
</div>




```python
time_min=df.groupby('author')['time'].min()
time_min
```




    author
          wenbiao        2018-12-31
     Goh Yu Wen Eunice   2017-11-26
     Hui Shan            2016-12-07
     Huihui              2017-09-28
     KO-CHENG            2018-07-16
                            ...    
    芊羽                   2018-03-11
    華山                   2017-08-14
    蘇                    2017-12-10
    郁君                   2017-12-25
    青慧                   2018-02-28
    Name: time, Length: 7722, dtype: datetime64[ns]




```python
time_max=df.groupby('author')['time'].max()
time_max
```




    author
          wenbiao        2018-12-31
     Goh Yu Wen Eunice   2017-11-26
     Hui Shan            2016-12-07
     Huihui              2017-09-28
     KO-CHENG            2018-07-16
                            ...    
    芊羽                   2018-03-11
    華山                   2017-08-14
    蘇                    2017-12-10
    郁君                   2017-12-25
    青慧                   2018-02-28
    Name: time, Length: 7722, dtype: datetime64[ns]




```python
life_time=(time_max-time_min)
life_time
```




    author
          wenbiao        0 days
     Goh Yu Wen Eunice   0 days
     Hui Shan            0 days
     Huihui              0 days
     KO-CHENG            0 days
                          ...  
    芊羽                   0 days
    華山                   0 days
    蘇                    0 days
    郁君                   0 days
    青慧                   0 days
    Name: time, Length: 7722, dtype: timedelta64[ns]




```python
life_time=(time_max-time_min).reset_index() #重新生成索引列
life_time
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>wenbiao</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Goh Yu Wen Eunice</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Hui Shan</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Huihui</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>4</th>
      <td>KO-CHENG</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7717</th>
      <td>芊羽</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7718</th>
      <td>華山</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7719</th>
      <td>蘇</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7720</th>
      <td>郁君</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7721</th>
      <td>青慧</td>
      <td>0 days</td>
    </tr>
  </tbody>
</table>
<p>7722 rows × 2 columns</p>
</div>




```python
life_time.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7722</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>23 days 01:45:32.867132</td>
    </tr>
    <tr>
      <th>std</th>
      <td>98 days 16:47:46.849668</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>0 days 00:00:00</td>
    </tr>
    <tr>
      <th>max</th>
      <td>864 days 00:00:00</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 8757 entries, 0 to 8756
    Data columns (total 7 columns):
    author       8757 non-null object
    rating       8757 non-null int64
    time         8757 non-null datetime64[ns]
    year         8757 non-null int64
    amount       8757 non-null int64
    frequency    8757 non-null int64
    month        8757 non-null datetime64[ns]
    dtypes: datetime64[ns](2), int64(4), object(1)
    memory usage: 479.0+ KB
    


```python
# 通过原样本8757条各count=7722得知，存在一个用户多次消费的情况
# 平均生命周期天数23天，通过25%，50%，75%分位数得知，绝大多用户生命周期为0天
# 最大生命周期为864天
```

## 用户生命周期直方图


```python
life_time
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>wenbiao</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Goh Yu Wen Eunice</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Hui Shan</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Huihui</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>4</th>
      <td>KO-CHENG</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7717</th>
      <td>芊羽</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7718</th>
      <td>華山</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7719</th>
      <td>蘇</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7720</th>
      <td>郁君</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>7721</th>
      <td>青慧</td>
      <td>0 days</td>
    </tr>
  </tbody>
</table>
<p>7722 rows × 2 columns</p>
</div>




```python
life_time.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7722 entries, 0 to 7721
    Data columns (total 2 columns):
    author    7722 non-null object
    time      7722 non-null timedelta64[ns]
    dtypes: object(1), timedelta64[ns](1)
    memory usage: 120.8+ KB
    


```python
# 日期类型转成数值类型，保留1位小数，格式化为天（把日期格式转成精度为天的格式）
life_time['life_time']=life_time['time']/np.timedelta64(1,'D')
life_time['life_time'].plot.hist(bins=100,figsize=(12,6))
plt.xlabel('天数')
plt.ylabel('人数')
plt.title('所有用户的生命周期直方图')
# 生命周期为0的用户（仅仅在一天内有过消费，之后再没消费过），存在7130个用户
# 由于总用户数为7722，其余592人属于优质的忠诚客户
```




    Text(0.5, 1.0, '所有用户的生命周期直方图')




![png](output_84_1.png)



```python
print(life_time[life_time['life_time']==0])
```

                      author   time  life_time
    0                wenbiao 0 days        0.0
    1      Goh Yu Wen Eunice 0 days        0.0
    2               Hui Shan 0 days        0.0
    3                 Huihui 0 days        0.0
    4               KO-CHENG 0 days        0.0
    ...                  ...    ...        ...
    7717                  芊羽 0 days        0.0
    7718                  華山 0 days        0.0
    7719                   蘇 0 days        0.0
    7720                  郁君 0 days        0.0
    7721                  青慧 0 days        0.0
    
    [7130 rows x 3 columns]
    


```python
# 因为后面的客户不直观，我们单独取出来分析（生命周期大于0的客户）
```

## 生命周期大于0天的用户，直方图


```python
life_time[life_time['life_time']>0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>time</th>
      <th>life_time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>49</th>
      <td>ANGELINA</td>
      <td>226 days</td>
      <td>226.0</td>
    </tr>
    <tr>
      <th>74</th>
      <td>ARLENE</td>
      <td>146 days</td>
      <td>146.0</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Aaron</td>
      <td>655 days</td>
      <td>655.0</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Abigail</td>
      <td>430 days</td>
      <td>430.0</td>
    </tr>
    <tr>
      <th>93</th>
      <td>Ace</td>
      <td>152 days</td>
      <td>152.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7615</th>
      <td>yanyan</td>
      <td>113 days</td>
      <td>113.0</td>
    </tr>
    <tr>
      <th>7626</th>
      <td>yewon</td>
      <td>28 days</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>7646</th>
      <td>yinung</td>
      <td>28 days</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>7660</th>
      <td>yu</td>
      <td>2 days</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>7664</th>
      <td>yuen ping michelle</td>
      <td>127 days</td>
      <td>127.0</td>
    </tr>
  </tbody>
</table>
<p>592 rows × 3 columns</p>
</div>




```python
life_time[life_time['life_time']>0]['life_time'] #单独把这一列取出来
```




    49      226.0
    74      146.0
    83      655.0
    90      430.0
    93      152.0
            ...  
    7615    113.0
    7626     28.0
    7646     28.0
    7660      2.0
    7664    127.0
    Name: life_time, Length: 592, dtype: float64




```python
life_time[life_time['life_time']>0]['life_time']

```




    49      226.0
    74      146.0
    83      655.0
    90      430.0
    93      152.0
            ...  
    7615    113.0
    7626     28.0
    7646     28.0
    7660      2.0
    7664    127.0
    Name: life_time, Length: 592, dtype: float64




```python
life_time[life_time['life_time']>0]['life_time'].plot.hist(bins=100,figsize=(12,6))
plt.xlabel('天数')
plt.ylabel('人数')
plt.title('生命周期在0天以上的用户分布直方图')
life_time[life_time['life_time']>0]['life_time'].mean()
# 去掉生命周期为0的用户，可知，用户平均生命周期为300天，生命周期在100天的用户量达到了最大值17人
# 生命周期在100-350天来看，用户量呈现缓慢下降的趋势
# 350-800天左右来看，用户量下降速度明显，存在一定用户流失，而忠诚用户越来越少
```




    300.9662162162162




![png](output_91_1.png)


## 各时间段的用户留存率


```python
# pd.cut()函数
np.random.seed(666) #保证每次运行程序产生的随机数都是相同的
score_list=np.random.randint(25,100,size=3)# #25分-100分之间，产生3个
score_list # 如果没有这句：np.random.seed(666)，每次运行产生的3个数都会不一样
```




    array([27, 70, 55])




```python
bins=[0,59,70,80,100]# 指定多个区间
score_cut=pd.cut(score_list,bins)
score_cut #27,70,55分别在下面三个区间
```




    [(0, 59], (59, 70], (0, 59]]
    Categories (4, interval[int64]): [(0, 59] < (59, 70] < (70, 80] < (80, 100]]




```python
# 留存率：1-90天有多少留存用户。求出用户的留存天数 ，比如 留存天数==89，属于1-90天内的留存用户
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8752</th>
      <td>Jonathan</td>
      <td>100</td>
      <td>2016-08-06</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8753</th>
      <td>Oliver Stephen Ah Kam</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8754</th>
      <td>Halley</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8755</th>
      <td>ANDREW WEIQIANG</td>
      <td>100</td>
      <td>2016-08-03</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>WEI CHIEH</td>
      <td>60</td>
      <td>2016-08-02</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
    </tr>
  </tbody>
</table>
<p>8757 rows × 7 columns</p>
</div>




```python
#留存天数计算方式：用户每一次的消费时间分别减去用户第一次消费时间
time_min #这样只是一维数据series
```




    author
          wenbiao        2018-12-31
     Goh Yu Wen Eunice   2017-11-26
     Hui Shan            2016-12-07
     Huihui              2017-09-28
     KO-CHENG            2018-07-16
                            ...    
    芊羽                   2018-03-11
    華山                   2017-08-14
    蘇                    2017-12-10
    郁君                   2017-12-25
    青慧                   2018-02-28
    Name: time, Length: 7722, dtype: datetime64[ns]




```python
#增加索引就转成了dataframe格式
time_min.reset_index()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>wenbiao</td>
      <td>2018-12-31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Goh Yu Wen Eunice</td>
      <td>2017-11-26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Hui Shan</td>
      <td>2016-12-07</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Huihui</td>
      <td>2017-09-28</td>
    </tr>
    <tr>
      <th>4</th>
      <td>KO-CHENG</td>
      <td>2018-07-16</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7717</th>
      <td>芊羽</td>
      <td>2018-03-11</td>
    </tr>
    <tr>
      <th>7718</th>
      <td>華山</td>
      <td>2017-08-14</td>
    </tr>
    <tr>
      <th>7719</th>
      <td>蘇</td>
      <td>2017-12-10</td>
    </tr>
    <tr>
      <th>7720</th>
      <td>郁君</td>
      <td>2017-12-25</td>
    </tr>
    <tr>
      <th>7721</th>
      <td>青慧</td>
      <td>2018-02-28</td>
    </tr>
  </tbody>
</table>
<p>7722 rows × 2 columns</p>
</div>




```python
#retention留存的意思
#left:左表，right：右表，how:连接方式，on:连接字段，suffixes:针对相同列名，指定不同的后缀
user_purchase_retention=pd.merge(left=df,right=time_min.reset_index(),how='inner',on='author',suffixes=('','_min'))
user_purchase_retention
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
      <th>time_min</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2017-06-27</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8752</th>
      <td>CHI NANG</td>
      <td>100</td>
      <td>2016-08-07</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-07</td>
    </tr>
    <tr>
      <th>8753</th>
      <td>Oliver Stephen Ah Kam</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
    </tr>
    <tr>
      <th>8754</th>
      <td>Halley</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
    </tr>
    <tr>
      <th>8755</th>
      <td>ANDREW WEIQIANG</td>
      <td>100</td>
      <td>2016-08-03</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-03</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>WEI CHIEH</td>
      <td>60</td>
      <td>2016-08-02</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-02</td>
    </tr>
  </tbody>
</table>
<p>8757 rows × 8 columns</p>
</div>




```python
# 计算留存天数
user_purchase_retention['time_diff']=user_purchase_retention['time']-user_purchase_retention['time_min']
user_purchase_retention
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
      <th>time_min</th>
      <th>time_diff</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2017-06-27</td>
      <td>611 days</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8752</th>
      <td>CHI NANG</td>
      <td>100</td>
      <td>2016-08-07</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-07</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>8753</th>
      <td>Oliver Stephen Ah Kam</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>8754</th>
      <td>Halley</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>8755</th>
      <td>ANDREW WEIQIANG</td>
      <td>100</td>
      <td>2016-08-03</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-03</td>
      <td>0 days</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>WEI CHIEH</td>
      <td>60</td>
      <td>2016-08-02</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-02</td>
      <td>0 days</td>
    </tr>
  </tbody>
</table>
<p>8757 rows × 9 columns</p>
</div>




```python
# 将time_diff转成数值
user_purchase_retention['time_diff']=user_purchase_retention['time_diff'].apply(lambda x:x/np.timedelta64(1,'D'))
user_purchase_retention
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
      <th>time_min</th>
      <th>time_diff</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2017-06-27</td>
      <td>611.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8752</th>
      <td>CHI NANG</td>
      <td>100</td>
      <td>2016-08-07</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-07</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>8753</th>
      <td>Oliver Stephen Ah Kam</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>8754</th>
      <td>Halley</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>8755</th>
      <td>ANDREW WEIQIANG</td>
      <td>100</td>
      <td>2016-08-03</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-03</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>WEI CHIEH</td>
      <td>60</td>
      <td>2016-08-02</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-02</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>8757 rows × 9 columns</p>
</div>




```python
# 生成时间跨度（3个月，即90天），判断属于哪个区间
bin=[i*90 for i in range(11)] #从0开始，生成10个数，生命周期最大是900多天，那就是90的位数
bin
```




    [0, 90, 180, 270, 360, 450, 540, 630, 720, 810, 900]




```python
#判断区间
user_purchase_retention['time_diff_bin']=pd.cut(user_purchase_retention['time_diff'],bin)
user_purchase_retention                                                                               
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>author</th>
      <th>rating</th>
      <th>time</th>
      <th>year</th>
      <th>amount</th>
      <th>frequency</th>
      <th>month</th>
      <th>time_min</th>
      <th>time_diff</th>
      <th>time_diff_bin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>YOUNG</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SHING YAN</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Sha</td>
      <td>60</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Mary Mae</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2019-02-28</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Maria Cristina</td>
      <td>100</td>
      <td>2019-02-28</td>
      <td>2019</td>
      <td>110</td>
      <td>1</td>
      <td>2019-02-01</td>
      <td>2017-06-27</td>
      <td>611.0</td>
      <td>(540.0, 630.0]</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8752</th>
      <td>CHI NANG</td>
      <td>100</td>
      <td>2016-08-07</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-07</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8753</th>
      <td>Oliver Stephen Ah Kam</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8754</th>
      <td>Halley</td>
      <td>100</td>
      <td>2016-08-05</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-05</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8755</th>
      <td>ANDREW WEIQIANG</td>
      <td>100</td>
      <td>2016-08-03</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-03</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8756</th>
      <td>WEI CHIEH</td>
      <td>60</td>
      <td>2016-08-02</td>
      <td>2016</td>
      <td>110</td>
      <td>1</td>
      <td>2016-08-01</td>
      <td>2016-08-02</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>8757 rows × 10 columns</p>
</div>




```python
# 统计每个游客，在不同的时间段内的消费频率和值（全球稍后判断 该用户在某个区间内是不是留存用户）
# 每名游客在每个留存时间段的数据，取这名游客对应时间段的频率，求和
pivot_retention=user_purchase_retention.groupby(['author','time_diff_bin'])['frequency'].sum().unstack()
pivot_retention
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>time_diff_bin</th>
      <th>(0, 90]</th>
      <th>(90, 180]</th>
      <th>(180, 270]</th>
      <th>(270, 360]</th>
      <th>(360, 450]</th>
      <th>(450, 540]</th>
      <th>(540, 630]</th>
      <th>(630, 720]</th>
      <th>(720, 810]</th>
      <th>(810, 900]</th>
    </tr>
    <tr>
      <th>author</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>wenbiao</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Goh Yu Wen Eunice</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Hui Shan</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Huihui</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>KO-CHENG</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>芊羽</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>華山</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>蘇</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>郁君</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>青慧</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>7722 rows × 10 columns</p>
</div>




```python
# 判断是否是留存用户（1：留存，0：未留存),trans(变化的意思)
pivot_retention_trans=pivot_retention.fillna(0).applymap(lambda x:1 if x>0 else 0)
pivot_retention_trans.head(60)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>time_diff_bin</th>
      <th>(0, 90]</th>
      <th>(90, 180]</th>
      <th>(180, 270]</th>
      <th>(270, 360]</th>
      <th>(360, 450]</th>
      <th>(450, 540]</th>
      <th>(540, 630]</th>
      <th>(630, 720]</th>
      <th>(720, 810]</th>
      <th>(810, 900]</th>
    </tr>
    <tr>
      <th>author</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>wenbiao</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Goh Yu Wen Eunice</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Hui Shan</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Huihui</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>KO-CHENG</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>TING SHAN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>A</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>A RAM</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ABIGAIL BEATRICE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ADRELIA</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ADRIAN YONG</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ADRIENNE JANNELLE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ADRINA</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AEJIN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AGUS FREDY</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AH YOUNG</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AHMAD DANIAL</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AHMAD KHUZAIMI</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AHMEMAH</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AI-MEI</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AIANE BERNADETTE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AIBO</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AILIN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AIMEE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AIRA ENISY</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALAN LUIGI</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALETHEA K L</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALEXANDER ALLEN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALEXIS ANNE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALFAT</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALFIE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALICE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALLYN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALVIN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ALYSSA JULIA</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AMANDA</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AMIEL JOHN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AN JUI</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>AN NISA</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANACLETO</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANDREA GENALINE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANDREW WEIQIANG</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANDY</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGEL MARIE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGELA KAREN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGELI CHRISTINE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGELICA</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGELICA MAE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGELICA MAY</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGELINA</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGELO GABRIEL</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANGIELYN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANH VU</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANILEN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANLUN</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANN CHERRY</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANN FEBEL</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANNA JULIA</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANNA MARIE</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>ANNABEL</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 留存率
pivot_retention_trans.sum()/pivot_retention_trans.count() #对当前列求和，默认是axis=0
```




    time_diff_bin
    (0, 90]       0.022663
    (90, 180]     0.019814
    (180, 270]    0.016058
    (270, 360]    0.014893
    (360, 450]    0.014375
    (450, 540]    0.009842
    (540, 630]    0.007641
    (630, 720]    0.004921
    (720, 810]    0.002720
    (810, 900]    0.000389
    dtype: float64




```python
(pivot_retention_trans.sum()/pivot_retention_trans.count()).plot.bar()
plt.xlabel('时间跨度（天）')
plt.ylabel('留存率')
plt.title('各时间段内的用户留存率')
```




    Text(0.5, 1.0, '各时间段内的用户留存率')




![png](output_106_1.png)



```python
# 如图：每个周期是3个月，第一个周期的留存率真在2.2%，前三个周期的递减速度在0.3%左右。
# 在第四五个周期的时候趋于平稳，稳定在留存率1.5%左右
# 从第五个周期开始，留存率真明显下降，下降到几乎0%，在第四五周期（1年）的时候，需要采取方法将用户留住进行再次消费
# 如果在跨度为1年的时候，不召回用户，则就会面临大量用户流失的风险 
```

## 用户平均购买周期直言图


```python
#创建函数，返回时间差
def diff(group):
    d= abs(group.time_diff - group.time_diff.shift(-1))
    return d
last_diff = user_purchase_retention.groupby('author').apply(diff)
ax = last_diff.hist(bins = 20)
ax.set_xlabel('时间跨度（天）') 
ax.set_ylabel('人数（人）') 
ax.set_title('用户平均购买周期直方图')
plt.show()

```


![png](output_109_0.png)



```python
print(life_time_gm0.mean())
```
