#### 1.订单表的长度，shape,columns
#### 2.统计菜名的平均价格（amounts)
#### 3.什么菜最受欢迎
#### 4.哪个订单ID点的菜最多
#### ......


```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams['font.sans-serif']='SimHei' #设置中文显示
%matplotlib inline
```


```python
# 1.读取数据
data1=pd.read_excel(r'D:\DATA ANALYSIS\meal_order_detail.xlsx',sheet_name='meal_order_detail1')
data2=pd.read_excel(r'D:\DATA ANALYSIS\meal_order_detail.xlsx',sheet_name='meal_order_detail2')
data3=pd.read_excel(r'D:\DATA ANALYSIS\meal_order_detail.xlsx',sheet_name='meal_order_detail3')
# 2.数据预处理（合并数据，NA等处理），分析数据
data=pd.concat([data1,data2,data3],axis=0) # 按照行进行拼接数据
data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>detail_id</th>
      <th>order_id</th>
      <th>dishes_id</th>
      <th>logicprn_name</th>
      <th>parent_class_name</th>
      <th>dishes_name</th>
      <th>itemis_add</th>
      <th>counts</th>
      <th>amounts</th>
      <th>cost</th>
      <th>place_order_time</th>
      <th>discount_amt</th>
      <th>discount_reason</th>
      <th>kick_back</th>
      <th>add_inprice</th>
      <th>add_info</th>
      <th>bar_code</th>
      <th>picture_file</th>
      <th>emp_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2956</td>
      <td>417</td>
      <td>610062</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>蒜蓉生蚝</td>
      <td>0</td>
      <td>1</td>
      <td>49</td>
      <td>NaN</td>
      <td>2016-08-01 11:05:36</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>caipu/104001.jpg</td>
      <td>1442</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2958</td>
      <td>417</td>
      <td>609957</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>蒙古烤羊腿</td>
      <td>0</td>
      <td>1</td>
      <td>48</td>
      <td>NaN</td>
      <td>2016-08-01 11:07:07</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>caipu/202003.jpg</td>
      <td>1442</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2961</td>
      <td>417</td>
      <td>609950</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>大蒜苋菜</td>
      <td>0</td>
      <td>1</td>
      <td>30</td>
      <td>NaN</td>
      <td>2016-08-01 11:07:40</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>caipu/303001.jpg</td>
      <td>1442</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2966</td>
      <td>417</td>
      <td>610038</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>芝麻烤紫菜</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
      <td>NaN</td>
      <td>2016-08-01 11:11:11</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>caipu/105002.jpg</td>
      <td>1442</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2968</td>
      <td>417</td>
      <td>610003</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>蒜香包</td>
      <td>0</td>
      <td>1</td>
      <td>13</td>
      <td>NaN</td>
      <td>2016-08-01 11:11:30</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>caipu/503002.jpg</td>
      <td>1442</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 10037 entries, 0 to 3610
    Data columns (total 19 columns):
    detail_id            10037 non-null int64
    order_id             10037 non-null int64
    dishes_id            10037 non-null int64
    logicprn_name        0 non-null float64
    parent_class_name    0 non-null float64
    dishes_name          10037 non-null object
    itemis_add           10037 non-null int64
    counts               10037 non-null int64
    amounts              10037 non-null int64
    cost                 0 non-null float64
    place_order_time     10037 non-null datetime64[ns]
    discount_amt         0 non-null float64
    discount_reason      0 non-null float64
    kick_back            0 non-null float64
    add_inprice          10037 non-null int64
    add_info             0 non-null float64
    bar_code             0 non-null float64
    picture_file         10037 non-null object
    emp_id               10037 non-null int64
    dtypes: datetime64[ns](1), float64(8), int64(8), object(2)
    memory usage: 1.5+ MB
    


```python
data.dropna(axis=1,inplace=True) # 按照列删除na列，并且修改源数据
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 10037 entries, 0 to 3610
    Data columns (total 11 columns):
    detail_id           10037 non-null int64
    order_id            10037 non-null int64
    dishes_id           10037 non-null int64
    dishes_name         10037 non-null object
    itemis_add          10037 non-null int64
    counts              10037 non-null int64
    amounts             10037 non-null int64
    place_order_time    10037 non-null datetime64[ns]
    add_inprice         10037 non-null int64
    picture_file        10037 non-null object
    emp_id              10037 non-null int64
    dtypes: datetime64[ns](1), int64(8), object(2)
    memory usage: 1.2+ MB
    


```python
# 统计卖出菜品的平均价格（amount求和/数量）
# round(data['amounts'].mean(),2) #方法一：pandas自带函数
round(np.mean(data['amounts']),2) #方法二：numpy函数处理（这种方法比较快）
```




    44.82




```python
# 频数统计，什么菜最受欢迎（对菜名进行频数统计，取最大前10名）
dishes_count=data['dishes_name'].value_counts()[:10] #对dishes_name这列进行值的数据统计,再取前10名
dishes_count
```




    白饭/大碗        323
    凉拌菠菜         269
    谷稻小庄         239
    麻辣小龙虾        216
    辣炒鱿鱼         189
    芝士烩波士顿龙虾     188
    五色糯米饭(七色)    187
    白饭/小碗        186
    香酥两吃大虾       178
    焖猪手          173
    Name: dishes_name, dtype: int64




```python
dishes_count.shape #这是一个一维数据，可以直接绘图
```




    (10,)




```python
# 3. 数据可视化matplotlib
dishes_count.plot(kind='line',color=['r'])
dishes_count.plot(kind='bar',fontsize=16)
# 对dishes_count进行一个for循环
for x,y in enumerate(dishes_count):
    print(x,y)
    plt.text(x,y+2,y,ha='center',fontsize=12)# 用绘制文本的函数，x代表索引 ，y代表高度，绘制的文字是y值
                   # y+2代表高度上移2个位置，ha='center'表示横轴要居中显示
```

    0 323
    1 269
    2 239
    3 216
    4 189
    5 188
    6 187
    7 186
    8 178
    9 173
    


![png](output_8_1.png)



```python
# 订单点菜的种类最多（1份白饭，1份香菜，1份小龙虾，3个种类；1份白饭，2份香菜，3份小龙虾，也是3个种类）
# 对订单id进行统计数量,然后取前10名
data_group=data['order_id'].value_counts()[:10]
data_group
```




    398     36
    1295    29
    582     27
    465     27
    1078    27
    1311    26
    1033    25
    426     24
    777     24
    769     24
    Name: order_id, dtype: int64




```python
# 绘制可视化图形
data_group.plot(kind='bar',fontsize=16,color=['r','m','b','y','g'])
plt.title('订单点菜的种类TOP10')
plt.xlabel('订单ID',fontsize=16)
plt.ylabel('点菜种类',fontsize=16)
# 8月份餐厅订单点菜种类前10名，平均点菜25个菜品
```




    Text(0, 0.5, '点菜种类')




![png](output_10_1.png)



```python
# 订单ID点菜数量TOP10(对order_id分组，counts求和，然后排序，取前10)
data['total_amounts']=data['counts']*data['amounts']# 统计单道菜消费总额
dataGroup=data[['order_id','counts','amounts','total_amounts']].groupby(by='order_id') #取出这些列，然后按order_id分组
Group_sum=dataGroup.sum() # 按order_id分组后，分别求出其四列总和
sort_counts=Group_sum.sort_values(by='counts',ascending=False)# 对Group_sum里counts降序排序
sort_counts
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>counts</th>
      <th>amounts</th>
      <th>total_amounts</th>
    </tr>
    <tr>
      <th>order_id</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>398</th>
      <td>36</td>
      <td>980</td>
      <td>980</td>
    </tr>
    <tr>
      <th>1033</th>
      <td>33</td>
      <td>1028</td>
      <td>1083</td>
    </tr>
    <tr>
      <th>1051</th>
      <td>33</td>
      <td>730</td>
      <td>835</td>
    </tr>
    <tr>
      <th>1318</th>
      <td>31</td>
      <td>1027</td>
      <td>1076</td>
    </tr>
    <tr>
      <th>557</th>
      <td>30</td>
      <td>957</td>
      <td>1023</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1029</th>
      <td>3</td>
      <td>123</td>
      <td>123</td>
    </tr>
    <tr>
      <th>1035</th>
      <td>2</td>
      <td>95</td>
      <td>95</td>
    </tr>
    <tr>
      <th>703</th>
      <td>2</td>
      <td>127</td>
      <td>127</td>
    </tr>
    <tr>
      <th>1064</th>
      <td>1</td>
      <td>48</td>
      <td>48</td>
    </tr>
    <tr>
      <th>1320</th>
      <td>1</td>
      <td>78</td>
      <td>78</td>
    </tr>
  </tbody>
</table>
<p>942 rows × 3 columns</p>
</div>




```python
# 取出counts这列，取出前10名，然后进行可视化
sort_counts['counts'][:10].plot(kind='bar',fontsize=16)
plt.title('订单ID点菜数量TOP10',fontsize=16)
plt.xlabel('订单ID',fontsize=16)
plt.ylabel('点菜数量',fontsize=16)
# 8月份订单点菜数量前10名
```




    Text(0, 0.5, '点菜数量')




![png](output_12_1.png)



```python
# 哪个订单ID吃的钱最多（排序）
# 对Group_sum里total_amounts降序排序
sort_total_amounts=Group_sum.sort_values(by='total_amounts',ascending=False)
sort_total_amounts
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>counts</th>
      <th>amounts</th>
      <th>total_amounts</th>
    </tr>
    <tr>
      <th>order_id</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1166</th>
      <td>24</td>
      <td>1314</td>
      <td>1314</td>
    </tr>
    <tr>
      <th>1071</th>
      <td>24</td>
      <td>598</td>
      <td>1282</td>
    </tr>
    <tr>
      <th>1028</th>
      <td>20</td>
      <td>1112</td>
      <td>1270</td>
    </tr>
    <tr>
      <th>385</th>
      <td>16</td>
      <td>1125</td>
      <td>1253</td>
    </tr>
    <tr>
      <th>743</th>
      <td>16</td>
      <td>1214</td>
      <td>1214</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1256</th>
      <td>6</td>
      <td>77</td>
      <td>84</td>
    </tr>
    <tr>
      <th>1135</th>
      <td>5</td>
      <td>79</td>
      <td>80</td>
    </tr>
    <tr>
      <th>1320</th>
      <td>1</td>
      <td>78</td>
      <td>78</td>
    </tr>
    <tr>
      <th>874</th>
      <td>6</td>
      <td>70</td>
      <td>76</td>
    </tr>
    <tr>
      <th>1064</th>
      <td>1</td>
      <td>48</td>
      <td>48</td>
    </tr>
  </tbody>
</table>
<p>942 rows × 3 columns</p>
</div>




```python
# 取出total_amounts这列，取出前10名，然后进行可视化
sort_total_amounts['total_amounts'][:10].plot(kind='bar',fontsize=16)
plt.title('消费金额TOP10',fontsize=16)
plt.xlabel('订单ID',fontsize=16)
plt.ylabel('消费金额',fontsize=16)
```




    Text(0, 0.5, '消费金额')




![png](output_14_1.png)



```python
# 哪个订单ID平均消费最贵
Group_sum['average']=Group_sum['total_amounts']/Group_sum['counts']
Group_sum
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>counts</th>
      <th>amounts</th>
      <th>total_amounts</th>
      <th>average</th>
    </tr>
    <tr>
      <th>order_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>137</th>
      <td>9</td>
      <td>194</td>
      <td>197</td>
      <td>21.888889</td>
    </tr>
    <tr>
      <th>162</th>
      <td>18</td>
      <td>1032</td>
      <td>1101</td>
      <td>61.166667</td>
    </tr>
    <tr>
      <th>163</th>
      <td>10</td>
      <td>182</td>
      <td>217</td>
      <td>21.700000</td>
    </tr>
    <tr>
      <th>165</th>
      <td>21</td>
      <td>953</td>
      <td>1147</td>
      <td>54.619048</td>
    </tr>
    <tr>
      <th>166</th>
      <td>7</td>
      <td>241</td>
      <td>260</td>
      <td>37.142857</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1320</th>
      <td>1</td>
      <td>78</td>
      <td>78</td>
      <td>78.000000</td>
    </tr>
    <tr>
      <th>1321</th>
      <td>7</td>
      <td>458</td>
      <td>458</td>
      <td>65.428571</td>
    </tr>
    <tr>
      <th>1322</th>
      <td>13</td>
      <td>547</td>
      <td>635</td>
      <td>48.846154</td>
    </tr>
    <tr>
      <th>1323</th>
      <td>15</td>
      <td>764</td>
      <td>764</td>
      <td>50.933333</td>
    </tr>
    <tr>
      <th>1324</th>
      <td>13</td>
      <td>438</td>
      <td>438</td>
      <td>33.692308</td>
    </tr>
  </tbody>
</table>
<p>942 rows × 4 columns</p>
</div>




```python
# # 对Group_sum里average降序排序
sort_average=Group_sum.sort_values(by='average',ascending=False)
sort_average
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>counts</th>
      <th>amounts</th>
      <th>total_amounts</th>
      <th>average</th>
    </tr>
    <tr>
      <th>order_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>168</th>
      <td>9</td>
      <td>423</td>
      <td>1105</td>
      <td>122.777778</td>
    </tr>
    <tr>
      <th>909</th>
      <td>4</td>
      <td>471</td>
      <td>471</td>
      <td>117.750000</td>
    </tr>
    <tr>
      <th>418</th>
      <td>4</td>
      <td>451</td>
      <td>451</td>
      <td>112.750000</td>
    </tr>
    <tr>
      <th>891</th>
      <td>7</td>
      <td>715</td>
      <td>715</td>
      <td>102.142857</td>
    </tr>
    <tr>
      <th>492</th>
      <td>3</td>
      <td>301</td>
      <td>301</td>
      <td>100.333333</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1174</th>
      <td>8</td>
      <td>110</td>
      <td>121</td>
      <td>15.125000</td>
    </tr>
    <tr>
      <th>632</th>
      <td>10</td>
      <td>126</td>
      <td>140</td>
      <td>14.000000</td>
    </tr>
    <tr>
      <th>1256</th>
      <td>6</td>
      <td>77</td>
      <td>84</td>
      <td>14.000000</td>
    </tr>
    <tr>
      <th>1303</th>
      <td>9</td>
      <td>112</td>
      <td>124</td>
      <td>13.777778</td>
    </tr>
    <tr>
      <th>874</th>
      <td>6</td>
      <td>70</td>
      <td>76</td>
      <td>12.666667</td>
    </tr>
  </tbody>
</table>
<p>942 rows × 4 columns</p>
</div>




```python
# 取出average这列，取出前10名，然后进行可视化
sort_average['average'][:10].plot(kind='bar',fontsize=16)
plt.title('订单消费单价TOP10',fontsize=16)
plt.xlabel('订单ID',fontsize=16)
plt.ylabel('消费单价',fontsize=16)
```




    Text(0, 0.5, '消费单价')




![png](output_17_1.png)



```python
# 一天当中什么时间段，点菜量比较集中（hour)
data['hourcount']=1 # 添加新列，用作计数器
data['time']=pd.to_datetime(data['place_order_time'])# 将时间转换成日期类型存储到新列中
data['hour']=data['time'].map(lambda x:x.hour)
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>detail_id</th>
      <th>order_id</th>
      <th>dishes_id</th>
      <th>dishes_name</th>
      <th>itemis_add</th>
      <th>counts</th>
      <th>amounts</th>
      <th>place_order_time</th>
      <th>add_inprice</th>
      <th>picture_file</th>
      <th>emp_id</th>
      <th>total_amounts</th>
      <th>hourcount</th>
      <th>time</th>
      <th>hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2956</td>
      <td>417</td>
      <td>610062</td>
      <td>蒜蓉生蚝</td>
      <td>0</td>
      <td>1</td>
      <td>49</td>
      <td>2016-08-01 11:05:36</td>
      <td>0</td>
      <td>caipu/104001.jpg</td>
      <td>1442</td>
      <td>49</td>
      <td>1</td>
      <td>2016-08-01 11:05:36</td>
      <td>11</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2958</td>
      <td>417</td>
      <td>609957</td>
      <td>蒙古烤羊腿</td>
      <td>0</td>
      <td>1</td>
      <td>48</td>
      <td>2016-08-01 11:07:07</td>
      <td>0</td>
      <td>caipu/202003.jpg</td>
      <td>1442</td>
      <td>48</td>
      <td>1</td>
      <td>2016-08-01 11:07:07</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2961</td>
      <td>417</td>
      <td>609950</td>
      <td>大蒜苋菜</td>
      <td>0</td>
      <td>1</td>
      <td>30</td>
      <td>2016-08-01 11:07:40</td>
      <td>0</td>
      <td>caipu/303001.jpg</td>
      <td>1442</td>
      <td>30</td>
      <td>1</td>
      <td>2016-08-01 11:07:40</td>
      <td>11</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2966</td>
      <td>417</td>
      <td>610038</td>
      <td>芝麻烤紫菜</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
      <td>2016-08-01 11:11:11</td>
      <td>0</td>
      <td>caipu/105002.jpg</td>
      <td>1442</td>
      <td>25</td>
      <td>1</td>
      <td>2016-08-01 11:11:11</td>
      <td>11</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2968</td>
      <td>417</td>
      <td>610003</td>
      <td>蒜香包</td>
      <td>0</td>
      <td>1</td>
      <td>13</td>
      <td>2016-08-01 11:11:30</td>
      <td>0</td>
      <td>caipu/503002.jpg</td>
      <td>1442</td>
      <td>13</td>
      <td>1</td>
      <td>2016-08-01 11:11:30</td>
      <td>11</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3606</th>
      <td>5683</td>
      <td>672</td>
      <td>610049</td>
      <td>爆炒双丝</td>
      <td>0</td>
      <td>1</td>
      <td>35</td>
      <td>2016-08-31 21:53:30</td>
      <td>0</td>
      <td>caipu/301003.jpg</td>
      <td>1089</td>
      <td>35</td>
      <td>1</td>
      <td>2016-08-31 21:53:30</td>
      <td>21</td>
    </tr>
    <tr>
      <th>3607</th>
      <td>5686</td>
      <td>672</td>
      <td>609959</td>
      <td>小炒羊腰\r\n\r\n\r\n</td>
      <td>0</td>
      <td>1</td>
      <td>36</td>
      <td>2016-08-31 21:54:40</td>
      <td>0</td>
      <td>caipu/202005.jpg</td>
      <td>1089</td>
      <td>36</td>
      <td>1</td>
      <td>2016-08-31 21:54:40</td>
      <td>21</td>
    </tr>
    <tr>
      <th>3608</th>
      <td>5379</td>
      <td>647</td>
      <td>610012</td>
      <td>香菇鹌鹑蛋</td>
      <td>0</td>
      <td>1</td>
      <td>39</td>
      <td>2016-08-31 21:54:44</td>
      <td>0</td>
      <td>caipu/302001.jpg</td>
      <td>1094</td>
      <td>39</td>
      <td>1</td>
      <td>2016-08-31 21:54:44</td>
      <td>21</td>
    </tr>
    <tr>
      <th>3609</th>
      <td>5380</td>
      <td>647</td>
      <td>610054</td>
      <td>不加一滴油的酸奶蛋糕</td>
      <td>0</td>
      <td>1</td>
      <td>7</td>
      <td>2016-08-31 21:55:24</td>
      <td>0</td>
      <td>caipu/501003.jpg</td>
      <td>1094</td>
      <td>7</td>
      <td>1</td>
      <td>2016-08-31 21:55:24</td>
      <td>21</td>
    </tr>
    <tr>
      <th>3610</th>
      <td>5688</td>
      <td>672</td>
      <td>609953</td>
      <td>凉拌菠菜</td>
      <td>0</td>
      <td>1</td>
      <td>27</td>
      <td>2016-08-31 21:56:54</td>
      <td>0</td>
      <td>caipu/303004.jpg</td>
      <td>1089</td>
      <td>27</td>
      <td>1</td>
      <td>2016-08-31 21:56:54</td>
      <td>21</td>
    </tr>
  </tbody>
</table>
<p>10037 rows × 15 columns</p>
</div>




```python
# 对hour这列进行分组，然后统计数量，接着取出hourcount这列
gp_by_hour=data.groupby(by='hour').count()['hourcount']
gp_by_hour
```




    hour
    11     960
    12     842
    13     823
    14     117
    17    1092
    18    1564
    19    1464
    20    1531
    21    1469
    22     175
    Name: hourcount, dtype: int64




```python
gp_by_hour.plot(kind='bar')
plt.title('点菜数量与小时的关系图',fontsize=16)
plt.xlabel('小时',fontsize=16)
plt.ylabel('点菜数量',fontsize=16)
```




    Text(0, 0.5, '点菜数量')




![png](output_20_1.png)



```python
# 哪一天订餐数量最多
data['daycount']=1 # 添加新列，用作计数器
data['day']=data['time'].map(lambda x:x.day) #解析出天
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>detail_id</th>
      <th>order_id</th>
      <th>dishes_id</th>
      <th>dishes_name</th>
      <th>itemis_add</th>
      <th>counts</th>
      <th>amounts</th>
      <th>place_order_time</th>
      <th>add_inprice</th>
      <th>picture_file</th>
      <th>emp_id</th>
      <th>total_amounts</th>
      <th>hourcount</th>
      <th>time</th>
      <th>hour</th>
      <th>daycount</th>
      <th>day</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2956</td>
      <td>417</td>
      <td>610062</td>
      <td>蒜蓉生蚝</td>
      <td>0</td>
      <td>1</td>
      <td>49</td>
      <td>2016-08-01 11:05:36</td>
      <td>0</td>
      <td>caipu/104001.jpg</td>
      <td>1442</td>
      <td>49</td>
      <td>1</td>
      <td>2016-08-01 11:05:36</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2958</td>
      <td>417</td>
      <td>609957</td>
      <td>蒙古烤羊腿</td>
      <td>0</td>
      <td>1</td>
      <td>48</td>
      <td>2016-08-01 11:07:07</td>
      <td>0</td>
      <td>caipu/202003.jpg</td>
      <td>1442</td>
      <td>48</td>
      <td>1</td>
      <td>2016-08-01 11:07:07</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2961</td>
      <td>417</td>
      <td>609950</td>
      <td>大蒜苋菜</td>
      <td>0</td>
      <td>1</td>
      <td>30</td>
      <td>2016-08-01 11:07:40</td>
      <td>0</td>
      <td>caipu/303001.jpg</td>
      <td>1442</td>
      <td>30</td>
      <td>1</td>
      <td>2016-08-01 11:07:40</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2966</td>
      <td>417</td>
      <td>610038</td>
      <td>芝麻烤紫菜</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
      <td>2016-08-01 11:11:11</td>
      <td>0</td>
      <td>caipu/105002.jpg</td>
      <td>1442</td>
      <td>25</td>
      <td>1</td>
      <td>2016-08-01 11:11:11</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2968</td>
      <td>417</td>
      <td>610003</td>
      <td>蒜香包</td>
      <td>0</td>
      <td>1</td>
      <td>13</td>
      <td>2016-08-01 11:11:30</td>
      <td>0</td>
      <td>caipu/503002.jpg</td>
      <td>1442</td>
      <td>13</td>
      <td>1</td>
      <td>2016-08-01 11:11:30</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3606</th>
      <td>5683</td>
      <td>672</td>
      <td>610049</td>
      <td>爆炒双丝</td>
      <td>0</td>
      <td>1</td>
      <td>35</td>
      <td>2016-08-31 21:53:30</td>
      <td>0</td>
      <td>caipu/301003.jpg</td>
      <td>1089</td>
      <td>35</td>
      <td>1</td>
      <td>2016-08-31 21:53:30</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
    </tr>
    <tr>
      <th>3607</th>
      <td>5686</td>
      <td>672</td>
      <td>609959</td>
      <td>小炒羊腰\r\n\r\n\r\n</td>
      <td>0</td>
      <td>1</td>
      <td>36</td>
      <td>2016-08-31 21:54:40</td>
      <td>0</td>
      <td>caipu/202005.jpg</td>
      <td>1089</td>
      <td>36</td>
      <td>1</td>
      <td>2016-08-31 21:54:40</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
    </tr>
    <tr>
      <th>3608</th>
      <td>5379</td>
      <td>647</td>
      <td>610012</td>
      <td>香菇鹌鹑蛋</td>
      <td>0</td>
      <td>1</td>
      <td>39</td>
      <td>2016-08-31 21:54:44</td>
      <td>0</td>
      <td>caipu/302001.jpg</td>
      <td>1094</td>
      <td>39</td>
      <td>1</td>
      <td>2016-08-31 21:54:44</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
    </tr>
    <tr>
      <th>3609</th>
      <td>5380</td>
      <td>647</td>
      <td>610054</td>
      <td>不加一滴油的酸奶蛋糕</td>
      <td>0</td>
      <td>1</td>
      <td>7</td>
      <td>2016-08-31 21:55:24</td>
      <td>0</td>
      <td>caipu/501003.jpg</td>
      <td>1094</td>
      <td>7</td>
      <td>1</td>
      <td>2016-08-31 21:55:24</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
    </tr>
    <tr>
      <th>3610</th>
      <td>5688</td>
      <td>672</td>
      <td>609953</td>
      <td>凉拌菠菜</td>
      <td>0</td>
      <td>1</td>
      <td>27</td>
      <td>2016-08-31 21:56:54</td>
      <td>0</td>
      <td>caipu/303004.jpg</td>
      <td>1089</td>
      <td>27</td>
      <td>1</td>
      <td>2016-08-31 21:56:54</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
    </tr>
  </tbody>
</table>
<p>10037 rows × 17 columns</p>
</div>




```python
# 对day这列进行分组，然后统计数量，接着取出daycount这列
gp_by_day=data.groupby(by='day').count()['daycount']
gp_by_day
```




    day
    1     217
    2     138
    3     157
    4     144
    5     193
    6     706
    7     696
    8     160
    9     146
    10    222
    11    176
    12    177
    13    756
    14    691
    15    211
    16    103
    17    206
    18    214
    19    226
    20    887
    21    778
    22    146
    23    180
    24    145
    25    136
    26    200
    27    725
    28    814
    29    148
    30    154
    31    185
    Name: daycount, dtype: int64




```python
gp_by_day.plot(kind='bar')
plt.title('点菜数量与日期的关系图',fontsize=16)
plt.xlabel('8月份日期',fontsize=16)
plt.ylabel('点菜数量',fontsize=16)
```




    Text(0, 0.5, '点菜数量')




![png](output_23_1.png)



```python
# 我们还可以对点菜量排序，取点菜量最大的前5天
```


```python
# 查看星期几人数最多，订餐数最多，映射数据到星期
data['weekcount']=1
data['weekday']=data['time'].map(lambda x:x.weekday())
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>detail_id</th>
      <th>order_id</th>
      <th>dishes_id</th>
      <th>dishes_name</th>
      <th>itemis_add</th>
      <th>counts</th>
      <th>amounts</th>
      <th>place_order_time</th>
      <th>add_inprice</th>
      <th>picture_file</th>
      <th>emp_id</th>
      <th>total_amounts</th>
      <th>hourcount</th>
      <th>time</th>
      <th>hour</th>
      <th>daycount</th>
      <th>day</th>
      <th>weekcount</th>
      <th>weekday</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2956</td>
      <td>417</td>
      <td>610062</td>
      <td>蒜蓉生蚝</td>
      <td>0</td>
      <td>1</td>
      <td>49</td>
      <td>2016-08-01 11:05:36</td>
      <td>0</td>
      <td>caipu/104001.jpg</td>
      <td>1442</td>
      <td>49</td>
      <td>1</td>
      <td>2016-08-01 11:05:36</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2958</td>
      <td>417</td>
      <td>609957</td>
      <td>蒙古烤羊腿</td>
      <td>0</td>
      <td>1</td>
      <td>48</td>
      <td>2016-08-01 11:07:07</td>
      <td>0</td>
      <td>caipu/202003.jpg</td>
      <td>1442</td>
      <td>48</td>
      <td>1</td>
      <td>2016-08-01 11:07:07</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2961</td>
      <td>417</td>
      <td>609950</td>
      <td>大蒜苋菜</td>
      <td>0</td>
      <td>1</td>
      <td>30</td>
      <td>2016-08-01 11:07:40</td>
      <td>0</td>
      <td>caipu/303001.jpg</td>
      <td>1442</td>
      <td>30</td>
      <td>1</td>
      <td>2016-08-01 11:07:40</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2966</td>
      <td>417</td>
      <td>610038</td>
      <td>芝麻烤紫菜</td>
      <td>0</td>
      <td>1</td>
      <td>25</td>
      <td>2016-08-01 11:11:11</td>
      <td>0</td>
      <td>caipu/105002.jpg</td>
      <td>1442</td>
      <td>25</td>
      <td>1</td>
      <td>2016-08-01 11:11:11</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2968</td>
      <td>417</td>
      <td>610003</td>
      <td>蒜香包</td>
      <td>0</td>
      <td>1</td>
      <td>13</td>
      <td>2016-08-01 11:11:30</td>
      <td>0</td>
      <td>caipu/503002.jpg</td>
      <td>1442</td>
      <td>13</td>
      <td>1</td>
      <td>2016-08-01 11:11:30</td>
      <td>11</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3606</th>
      <td>5683</td>
      <td>672</td>
      <td>610049</td>
      <td>爆炒双丝</td>
      <td>0</td>
      <td>1</td>
      <td>35</td>
      <td>2016-08-31 21:53:30</td>
      <td>0</td>
      <td>caipu/301003.jpg</td>
      <td>1089</td>
      <td>35</td>
      <td>1</td>
      <td>2016-08-31 21:53:30</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3607</th>
      <td>5686</td>
      <td>672</td>
      <td>609959</td>
      <td>小炒羊腰\r\n\r\n\r\n</td>
      <td>0</td>
      <td>1</td>
      <td>36</td>
      <td>2016-08-31 21:54:40</td>
      <td>0</td>
      <td>caipu/202005.jpg</td>
      <td>1089</td>
      <td>36</td>
      <td>1</td>
      <td>2016-08-31 21:54:40</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3608</th>
      <td>5379</td>
      <td>647</td>
      <td>610012</td>
      <td>香菇鹌鹑蛋</td>
      <td>0</td>
      <td>1</td>
      <td>39</td>
      <td>2016-08-31 21:54:44</td>
      <td>0</td>
      <td>caipu/302001.jpg</td>
      <td>1094</td>
      <td>39</td>
      <td>1</td>
      <td>2016-08-31 21:54:44</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3609</th>
      <td>5380</td>
      <td>647</td>
      <td>610054</td>
      <td>不加一滴油的酸奶蛋糕</td>
      <td>0</td>
      <td>1</td>
      <td>7</td>
      <td>2016-08-31 21:55:24</td>
      <td>0</td>
      <td>caipu/501003.jpg</td>
      <td>1094</td>
      <td>7</td>
      <td>1</td>
      <td>2016-08-31 21:55:24</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3610</th>
      <td>5688</td>
      <td>672</td>
      <td>609953</td>
      <td>凉拌菠菜</td>
      <td>0</td>
      <td>1</td>
      <td>27</td>
      <td>2016-08-31 21:56:54</td>
      <td>0</td>
      <td>caipu/303004.jpg</td>
      <td>1089</td>
      <td>27</td>
      <td>1</td>
      <td>2016-08-31 21:56:54</td>
      <td>21</td>
      <td>1</td>
      <td>31</td>
      <td>1</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>10037 rows × 19 columns</p>
</div>




```python
# 对weekday这列进行分组，然后统计数量，接着取出weekcount这列
gp_by_weekday=data.groupby(by='weekday').count()['weekcount']
gp_by_weekday.plot(kind='bar')
plt.title('点菜数量与星期的关系图',fontsize=16)
plt.xlabel('星期',fontsize=16)
plt.ylabel('点菜数量',fontsize=16)
# 0代表星期1，5，6代表周六周日
```




    Text(0, 0.5, '点菜数量')




![png](output_26_1.png)



```python
# shell 工具：git bash(下载)，对比cmd:几乎接近linux命令
# jupyter lab是jupyter notebook升级版
# 不同维度进行数据分析：
# 针对订单order_id:1.什么菜最受欢迎 2.点菜的各类 3.点菜的数量 4.消费金额最大 5.平均消费
# 针对时间日期进行分析：1.点菜量比较集中的时间 2哪一天订餐量最大 3.星期几就餐人数最多
# 技术点：1.拼接数据pd.condcat([列1，...]) 2.分组进行统计（分组求和）-最重要的3.排序 ，切片 TOP10 4.绘制柱状图走势和高度
          
```
