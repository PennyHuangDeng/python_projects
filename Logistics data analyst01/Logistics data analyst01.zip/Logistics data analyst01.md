### 数据来源：某企业销售的6种商品所对应的送货及用户反馈数据
### 解决问题：
##### 1、配送服务是否存在问题
##### 2、是否存在尚有潜力的销售区域
##### 3、商品是否存在质量问题

### 先放结论：
##### 1、货品4→西北，货品2→马来西亚两条线路存在较大问题，急需提升时效
##### 2、货品2在华东地区还有较大市场空间，适合加大投入，同时货品2在西北配送时效长，用户拒收率高，从成本角度考虑，应该减少投入
##### 3、货品1、2、4质量存在问题，建议扩大抽检范围，增大质检力度

### 分析过程如下
#### 一、数据清洗
##### ① 重复值、缺失值、格式调整
##### ② 异常值处理（比如：销售金额存在等于0的，数量和销售金额的标准差都在均值的8倍以上等）
#### 二、数据规整
##### 比如：增加一项辅助列：月份
#### 三、数据分析并可视化


```python
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
plt.rcParams['font.sans-serif'] = 'SimHei' ## 设置中文显示
```

# 数据清洗


```python
data = pd.read_csv(r'D:\data analysis\data_wuliu.csv',encoding='gbk')
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>订单号</th>
      <th>订单行</th>
      <th>销售时间</th>
      <th>交货时间</th>
      <th>货品交货状况</th>
      <th>货品</th>
      <th>货品用户反馈</th>
      <th>销售区域</th>
      <th>数量</th>
      <th>销售金额</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>P096311</td>
      <td>10</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>2.0</td>
      <td>1052,75元</td>
    </tr>
    <tr>
      <th>1</th>
      <td>P096826</td>
      <td>10</td>
      <td>2016-8-30</td>
      <td>2016-10-30</td>
      <td>按时交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>10.0</td>
      <td>11,50万元</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>20</td>
      <td>2016-8-30</td>
      <td>2016-10-30</td>
      <td>按时交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>10.0</td>
      <td>11,50万元</td>
    </tr>
    <tr>
      <th>3</th>
      <td>P097435</td>
      <td>10</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>按时交货</td>
      <td>货品1</td>
      <td>返修</td>
      <td>华南</td>
      <td>2.0</td>
      <td>6858,77元</td>
    </tr>
    <tr>
      <th>4</th>
      <td>P097446</td>
      <td>60</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>15.0</td>
      <td>129,58元</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1161 entries, 0 to 1160
    Data columns (total 10 columns):
    订单号       1159 non-null object
    订单行       1161 non-null int64
    销售时间      1161 non-null object
    交货时间      1161 non-null object
    货品交货状况    1159 non-null object
    货品        1161 non-null object
    货品用户反馈    1161 non-null object
    销售区域      1161 non-null object
    数量        1157 non-null float64
    销售金额      1161 non-null object
    dtypes: float64(1), int64(1), object(8)
    memory usage: 90.8+ KB
    


```python
# 通过info()可以看出，包括10列数据，名字，数据量，格式等，可以得出：
# 1.订单号，货品交货情况，数量：存在缺失值，但是缺失量不大，可以删除
# 2.订单行，对分析无关紧要，可以考虑删除
# 3.销售金额格式不对（万元|元，逗号问题）,数据类型需要转换成int|float
```

## 重复值、缺失值、格式调整


```python
#删除重复记录
data.drop_duplicates(keep='first',inplace=True) #重复值保留第一个，在原数据中修改
#删除缺失值（na,删除带有na的整行数据,axis=0（按行删除）,how='any'（只要有一个NA，就整行删除，默认值）
data.dropna(axis=0,how='any',inplace=True)
#删除订单行(重复运行会报错，因为第一次已经删除了订单行这一列，需要重新加载数据)，axis=1（按列删除）
data.drop(columns=['订单行'],inplace=True,axis=1)
print(data.info())
#更新索引(drop=True:把原来的索引index列删除，重置index)
data.reset_index(drop=True,inplace=True)
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1146 entries, 0 to 1160
    Data columns (total 9 columns):
    订单号       1146 non-null object
    销售时间      1146 non-null object
    交货时间      1146 non-null object
    货品交货状况    1146 non-null object
    货品        1146 non-null object
    货品用户反馈    1146 non-null object
    销售区域      1146 non-null object
    数量        1146 non-null float64
    销售金额      1146 non-null object
    dtypes: float64(1), object(8)
    memory usage: 89.5+ KB
    None
    


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>订单号</th>
      <th>销售时间</th>
      <th>交货时间</th>
      <th>货品交货状况</th>
      <th>货品</th>
      <th>货品用户反馈</th>
      <th>销售区域</th>
      <th>数量</th>
      <th>销售金额</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>P096311</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>2.0</td>
      <td>105275.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>P096826</td>
      <td>2016-8-30</td>
      <td>2016-10-30</td>
      <td>按时交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>10.0</td>
      <td>11500000.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>P097435</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>按时交货</td>
      <td>货品1</td>
      <td>返修</td>
      <td>华南</td>
      <td>2.0</td>
      <td>685877.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>15.0</td>
      <td>12958.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>拒货</td>
      <td>华北</td>
      <td>15.0</td>
      <td>3239.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#取出销售金额列，对每一个数据进行清洗
#编写自定义过滤函数：删除逗号，转成float，如果是万元则*10000，否则，删除元
```


```python
def data_deal(number):
    if number.find('万元')!= -1:#这个字符串的内容，如果找到，就会返回改字符串所在的下标，如果没有找到，就会返回-1
        number_new = float(number[:number.find('万元')].replace(',',''))*10000
        # 先找出带有逗号的数字，切片切出来后，取出数字，找到万元，把逗号替换成空，转成浮点
        # 找到带有万元的，取出数字，去掉逗号，转成float，*10000
        pass
    else: #找到带有元的，把元替换成空值，把逗号替换成空值，转成float
        number_new = float(number.replace('元','').replace(',',''))
        pass
    return number_new
data['销售金额'] = data['销售金额'].map(data_deal)# 把data['销售金额'].map(data_deal)处理完的再存储到这列中
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>订单号</th>
      <th>销售时间</th>
      <th>交货时间</th>
      <th>货品交货状况</th>
      <th>货品</th>
      <th>货品用户反馈</th>
      <th>销售区域</th>
      <th>数量</th>
      <th>销售金额</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>P096311</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>2.0</td>
      <td>105275.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>P096826</td>
      <td>2016-8-30</td>
      <td>2016-10-30</td>
      <td>按时交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>10.0</td>
      <td>11500000.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>P097435</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>按时交货</td>
      <td>货品1</td>
      <td>返修</td>
      <td>华南</td>
      <td>2.0</td>
      <td>685877.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>15.0</td>
      <td>12958.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>拒货</td>
      <td>华北</td>
      <td>15.0</td>
      <td>3239.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1141</th>
      <td>P299901</td>
      <td>2016-12-15</td>
      <td>2017-3-15</td>
      <td>按时交货</td>
      <td>货品6</td>
      <td>质量合格</td>
      <td>马来西亚</td>
      <td>2.0</td>
      <td>20041.0</td>
    </tr>
    <tr>
      <th>1142</th>
      <td>P302956</td>
      <td>2016-12-22</td>
      <td>2017-3-22</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>拒货</td>
      <td>华东</td>
      <td>20.0</td>
      <td>7944.0</td>
    </tr>
    <tr>
      <th>1143</th>
      <td>P303801</td>
      <td>2016-12-15</td>
      <td>2017-3-15</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>质量合格</td>
      <td>华东</td>
      <td>1.0</td>
      <td>19408.0</td>
    </tr>
    <tr>
      <th>1144</th>
      <td>P307276</td>
      <td>2016-12-22</td>
      <td>2017-3-22</td>
      <td>按时交货</td>
      <td>货品6</td>
      <td>质量合格</td>
      <td>马来西亚</td>
      <td>1.0</td>
      <td>3218.0</td>
    </tr>
    <tr>
      <th>1145</th>
      <td>P314165</td>
      <td>2016-12-20</td>
      <td>2017-3-20</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>质量合格</td>
      <td>华东</td>
      <td>1.0</td>
      <td>172092.0</td>
    </tr>
  </tbody>
</table>
<p>1146 rows × 9 columns</p>
</div>



## 异常值处理


```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>数量</th>
      <th>销售金额</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1146.000000</td>
      <td>1.146000e+03</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>76.069372</td>
      <td>1.223488e+05</td>
    </tr>
    <tr>
      <th>std</th>
      <td>589.416486</td>
      <td>1.114599e+06</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.000000</td>
      <td>2.941500e+03</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.000000</td>
      <td>9.476500e+03</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4.000000</td>
      <td>3.576775e+04</td>
    </tr>
    <tr>
      <th>max</th>
      <td>11500.000000</td>
      <td>3.270000e+07</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 销售金额==0,采用删除方法，因为数据量很小
data=data[data['销售金额']!=0]
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>数量</th>
      <th>销售金额</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1145.000000</td>
      <td>1.145000e+03</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>76.134934</td>
      <td>1.224557e+05</td>
    </tr>
    <tr>
      <th>std</th>
      <td>589.669861</td>
      <td>1.115081e+06</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>5.100000e+01</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.000000</td>
      <td>2.946000e+03</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.000000</td>
      <td>9.486000e+03</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4.000000</td>
      <td>3.577300e+04</td>
    </tr>
    <tr>
      <th>max</th>
      <td>11500.000000</td>
      <td>3.270000e+07</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 销售金额和数量存在严重右偏现象，在电商领域2/8很正常，无需处理
```


```python
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>订单号</th>
      <th>销售时间</th>
      <th>交货时间</th>
      <th>货品交货状况</th>
      <th>货品</th>
      <th>货品用户反馈</th>
      <th>销售区域</th>
      <th>数量</th>
      <th>销售金额</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>P096311</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>2.0</td>
      <td>105275.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>P096826</td>
      <td>2016-8-30</td>
      <td>2016-10-30</td>
      <td>按时交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>10.0</td>
      <td>11500000.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>P097435</td>
      <td>2016-7-30</td>
      <td>2016-9-30</td>
      <td>按时交货</td>
      <td>货品1</td>
      <td>返修</td>
      <td>华南</td>
      <td>2.0</td>
      <td>685877.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>15.0</td>
      <td>12958.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>拒货</td>
      <td>华北</td>
      <td>15.0</td>
      <td>3239.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1141</th>
      <td>P299901</td>
      <td>2016-12-15</td>
      <td>2017-3-15</td>
      <td>按时交货</td>
      <td>货品6</td>
      <td>质量合格</td>
      <td>马来西亚</td>
      <td>2.0</td>
      <td>20041.0</td>
    </tr>
    <tr>
      <th>1142</th>
      <td>P302956</td>
      <td>2016-12-22</td>
      <td>2017-3-22</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>拒货</td>
      <td>华东</td>
      <td>20.0</td>
      <td>7944.0</td>
    </tr>
    <tr>
      <th>1143</th>
      <td>P303801</td>
      <td>2016-12-15</td>
      <td>2017-3-15</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>质量合格</td>
      <td>华东</td>
      <td>1.0</td>
      <td>19408.0</td>
    </tr>
    <tr>
      <th>1144</th>
      <td>P307276</td>
      <td>2016-12-22</td>
      <td>2017-3-22</td>
      <td>按时交货</td>
      <td>货品6</td>
      <td>质量合格</td>
      <td>马来西亚</td>
      <td>1.0</td>
      <td>3218.0</td>
    </tr>
    <tr>
      <th>1145</th>
      <td>P314165</td>
      <td>2016-12-20</td>
      <td>2017-3-20</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>质量合格</td>
      <td>华东</td>
      <td>1.0</td>
      <td>172092.0</td>
    </tr>
  </tbody>
</table>
<p>1145 rows × 9 columns</p>
</div>



# 数据规整


```python
data['销售时间'] = pd.to_datetime(data['销售时间'])#先取出'销售时间'这列，对这列数据进行数据转换，再放回到原数据列里面
data['月份'] = data['销售时间'].apply(lambda x:x.month)#取出'销售时间'这列,对这列里的每一条记录分别取出月份，放到新的一列中
data
```

    <ipython-input-14-f329c9f31c36>:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      data['销售时间'] = pd.to_datetime(data['销售时间'])#先取出'销售时间'这列，对这列数据进行数据转换，再放回到原数据列里面
    <ipython-input-14-f329c9f31c36>:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      data['月份'] = data['销售时间'].apply(lambda x:x.month)#取出'销售时间'这列,对这列里的每一条记录分别取出月份，放到新的一列中
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>订单号</th>
      <th>销售时间</th>
      <th>交货时间</th>
      <th>货品交货状况</th>
      <th>货品</th>
      <th>货品用户反馈</th>
      <th>销售区域</th>
      <th>数量</th>
      <th>销售金额</th>
      <th>月份</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>P096311</td>
      <td>2016-07-30</td>
      <td>2016-9-30</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>2.0</td>
      <td>105275.0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1</th>
      <td>P096826</td>
      <td>2016-08-30</td>
      <td>2016-10-30</td>
      <td>按时交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>10.0</td>
      <td>11500000.0</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>P097435</td>
      <td>2016-07-30</td>
      <td>2016-9-30</td>
      <td>按时交货</td>
      <td>货品1</td>
      <td>返修</td>
      <td>华南</td>
      <td>2.0</td>
      <td>685877.0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>质量合格</td>
      <td>华北</td>
      <td>15.0</td>
      <td>12958.0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>4</th>
      <td>P097446</td>
      <td>2016-11-26</td>
      <td>2017-1-26</td>
      <td>晚交货</td>
      <td>货品3</td>
      <td>拒货</td>
      <td>华北</td>
      <td>15.0</td>
      <td>3239.0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1141</th>
      <td>P299901</td>
      <td>2016-12-15</td>
      <td>2017-3-15</td>
      <td>按时交货</td>
      <td>货品6</td>
      <td>质量合格</td>
      <td>马来西亚</td>
      <td>2.0</td>
      <td>20041.0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1142</th>
      <td>P302956</td>
      <td>2016-12-22</td>
      <td>2017-3-22</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>拒货</td>
      <td>华东</td>
      <td>20.0</td>
      <td>7944.0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1143</th>
      <td>P303801</td>
      <td>2016-12-15</td>
      <td>2017-3-15</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>质量合格</td>
      <td>华东</td>
      <td>1.0</td>
      <td>19408.0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1144</th>
      <td>P307276</td>
      <td>2016-12-22</td>
      <td>2017-3-22</td>
      <td>按时交货</td>
      <td>货品6</td>
      <td>质量合格</td>
      <td>马来西亚</td>
      <td>1.0</td>
      <td>3218.0</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1145</th>
      <td>P314165</td>
      <td>2016-12-20</td>
      <td>2017-3-20</td>
      <td>按时交货</td>
      <td>货品2</td>
      <td>质量合格</td>
      <td>华东</td>
      <td>1.0</td>
      <td>172092.0</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
<p>1145 rows × 10 columns</p>
</div>



# 数据分析并可视化
## 配送服务是否存在问题
### 月份维度


```python
data['货品交货状况'] = data['货品交货状况'].str.strip()#取出这一列，转成str,再去除首尾空格，处理完的数据再给它还原回去（再存储到这一列）
data1 = data.groupby(['月份','货品交货状况']).size().unstack()# 对分组的数据进行数量统计，用size(压缩显示状态）,再用unstack转成df行列的形式
data1
```

    <ipython-input-16-aeffcf2ca503>:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      data['货品交货状况'] = data['货品交货状况'].str.strip()#取出这一列，转成str,再去除首尾空格，处理完的数据再给它还原回去（再存储到这一列）
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>货品交货状况</th>
      <th>按时交货</th>
      <th>晚交货</th>
    </tr>
    <tr>
      <th>月份</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7</th>
      <td>189</td>
      <td>13</td>
    </tr>
    <tr>
      <th>8</th>
      <td>218</td>
      <td>35</td>
    </tr>
    <tr>
      <th>9</th>
      <td>122</td>
      <td>9</td>
    </tr>
    <tr>
      <th>10</th>
      <td>238</td>
      <td>31</td>
    </tr>
    <tr>
      <th>11</th>
      <td>101</td>
      <td>25</td>
    </tr>
    <tr>
      <th>12</th>
      <td>146</td>
      <td>18</td>
    </tr>
  </tbody>
</table>
</div>




```python
data1['按时交货率'] = data1['按时交货']/(data1['按时交货']+data1['晚交货'])
data1
#从按时交货率来看，第四季度低于第三季度，猜测可能是气候原因造成
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>货品交货状况</th>
      <th>按时交货</th>
      <th>晚交货</th>
      <th>按时交货率</th>
    </tr>
    <tr>
      <th>月份</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7</th>
      <td>189</td>
      <td>13</td>
      <td>0.935644</td>
    </tr>
    <tr>
      <th>8</th>
      <td>218</td>
      <td>35</td>
      <td>0.861660</td>
    </tr>
    <tr>
      <th>9</th>
      <td>122</td>
      <td>9</td>
      <td>0.931298</td>
    </tr>
    <tr>
      <th>10</th>
      <td>238</td>
      <td>31</td>
      <td>0.884758</td>
    </tr>
    <tr>
      <th>11</th>
      <td>101</td>
      <td>25</td>
      <td>0.801587</td>
    </tr>
    <tr>
      <th>12</th>
      <td>146</td>
      <td>18</td>
      <td>0.890244</td>
    </tr>
  </tbody>
</table>
</div>



### 销售区域维度


```python
data1 = data.groupby(['销售区域','货品交货状况']).size().unstack()
data1['按时交货率'] = data1['按时交货']/(data1['按时交货']+data1['晚交货'])
data1.sort_values(by='按时交货率',ascending=False) #按按时交货率降序排序
# #西北地区存在突出的延时交货问题，急需解決
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>货品交货状况</th>
      <th>按时交货</th>
      <th>晚交货</th>
      <th>按时交货率</th>
    </tr>
    <tr>
      <th>销售区域</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>泰国</th>
      <td>183</td>
      <td>4</td>
      <td>0.978610</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>310</td>
      <td>16</td>
      <td>0.950920</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>10</td>
      <td>1</td>
      <td>0.909091</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>226</td>
      <td>27</td>
      <td>0.893281</td>
    </tr>
    <tr>
      <th>华东</th>
      <td>268</td>
      <td>39</td>
      <td>0.872964</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>17</td>
      <td>44</td>
      <td>0.278689</td>
    </tr>
  </tbody>
</table>
</div>



### 货品维度


```python
data1 = data.groupby(['货品','货品交货状况']).size().unstack()
data1['按时交货率'] = data1['按时交货']/(data1['按时交货']+data1['晚交货'])
data1.sort_values(by='按时交货率',ascending=False)
#货品4晚交货情况非常严重，其余货品相对较好
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>货品交货状况</th>
      <th>按时交货</th>
      <th>晚交货</th>
      <th>按时交货率</th>
    </tr>
    <tr>
      <th>货品</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>货品5</th>
      <td>183</td>
      <td>4</td>
      <td>0.978610</td>
    </tr>
    <tr>
      <th>货品6</th>
      <td>309</td>
      <td>7</td>
      <td>0.977848</td>
    </tr>
    <tr>
      <th>货品1</th>
      <td>27</td>
      <td>2</td>
      <td>0.931034</td>
    </tr>
    <tr>
      <th>货品3</th>
      <td>212</td>
      <td>26</td>
      <td>0.890756</td>
    </tr>
    <tr>
      <th>货品2</th>
      <td>269</td>
      <td>48</td>
      <td>0.848580</td>
    </tr>
    <tr>
      <th>货品4</th>
      <td>14</td>
      <td>44</td>
      <td>0.241379</td>
    </tr>
  </tbody>
</table>
</div>



### 货品和销售区域结合


```python
data1 = data.groupby(['货品','销售区域','货品交货状况']).size().unstack()
data1['按时交货率'] = data1['按时交货']/(data1['按时交货']+data1['晚交货'])
data1.sort_values(by='按时交货率',ascending=False)
#销售区域：最差在西北地区，货品有1和4，主要是货品4送过较晚导致
#货品：最差的货品2，主要送往华东和马来西亚，主要是马来西亚的送货较晚导致。
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>货品交货状况</th>
      <th>按时交货</th>
      <th>晚交货</th>
      <th>按时交货率</th>
    </tr>
    <tr>
      <th>货品</th>
      <th>销售区域</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>货品5</th>
      <th>泰国</th>
      <td>183.0</td>
      <td>4.0</td>
      <td>0.978610</td>
    </tr>
    <tr>
      <th>货品6</th>
      <th>马来西亚</th>
      <td>309.0</td>
      <td>7.0</td>
      <td>0.977848</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">货品1</th>
      <th>华北</th>
      <td>14.0</td>
      <td>1.0</td>
      <td>0.933333</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>10.0</td>
      <td>1.0</td>
      <td>0.909091</td>
    </tr>
    <tr>
      <th>货品3</th>
      <th>华北</th>
      <td>212.0</td>
      <td>26.0</td>
      <td>0.890756</td>
    </tr>
    <tr>
      <th>货品2</th>
      <th>华东</th>
      <td>268.0</td>
      <td>39.0</td>
      <td>0.872964</td>
    </tr>
    <tr>
      <th>货品4</th>
      <th>西北</th>
      <td>14.0</td>
      <td>44.0</td>
      <td>0.241379</td>
    </tr>
    <tr>
      <th>货品2</th>
      <th>马来西亚</th>
      <td>1.0</td>
      <td>9.0</td>
      <td>0.100000</td>
    </tr>
    <tr>
      <th>货品1</th>
      <th>西北</th>
      <td>3.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



## 是否存在尚有潜力的销售区域

### 月份维度


```python
data1 = data.groupby(['月份','货品'])['数量'].sum().unstack()#如1月份的时候运输货品1有多少数量...，再用unstack转成df的行列形式
data1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>货品</th>
      <th>货品1</th>
      <th>货品2</th>
      <th>货品3</th>
      <th>货品4</th>
      <th>货品5</th>
      <th>货品6</th>
    </tr>
    <tr>
      <th>月份</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7</th>
      <td>283.0</td>
      <td>491.0</td>
      <td>2041.5</td>
      <td>414.0</td>
      <td>733.0</td>
      <td>1649.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1413.0</td>
      <td>3143.0</td>
      <td>1045.0</td>
      <td>1188.0</td>
      <td>2381.0</td>
      <td>1181.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1693.0</td>
      <td>3020.0</td>
      <td>2031.0</td>
      <td>NaN</td>
      <td>271.0</td>
      <td>343.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>4.0</td>
      <td>28420.0</td>
      <td>1684.0</td>
      <td>2542.0</td>
      <td>1984.0</td>
      <td>2358.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>20.0</td>
      <td>2042.0</td>
      <td>100.0</td>
      <td>3.0</td>
      <td>14.0</td>
      <td>383.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>4.0</td>
      <td>18205.0</td>
      <td>2172.0</td>
      <td>1082.0</td>
      <td>350.0</td>
      <td>2487.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data1.plot(kind='line')
# 货品2在10月和12月份，销量猛增，原因猜测有二：1.公司加大营销力度  2.开发了新的市场(后续有结论)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x15c7d6eadc0>




![png](output_30_1.png)


### 不同区域


```python
data1 = data.groupby(['销售区域','货品'])['数量'].sum().unstack() #求每组的‘数量’求和，再转成DF行列形式
data1
# 从销售区域看，每种货品销售区域为1~3个，货品1有三个销售区域，货品2有两个销售区域，其余货品均有1个销售区域
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>货品</th>
      <th>货品1</th>
      <th>货品2</th>
      <th>货品3</th>
      <th>货品4</th>
      <th>货品5</th>
      <th>货品6</th>
    </tr>
    <tr>
      <th>销售区域</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>华东</th>
      <td>NaN</td>
      <td>53811.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>2827.0</td>
      <td>NaN</td>
      <td>9073.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>579.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>泰国</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5733.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>11.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5229.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>NaN</td>
      <td>1510.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8401.0</td>
    </tr>
  </tbody>
</table>
</div>



### 月份和区域


```python
data1 = data.groupby(['月份','销售区域','货品'])['数量'].sum().unstack()
data1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>货品</th>
      <th>货品1</th>
      <th>货品2</th>
      <th>货品3</th>
      <th>货品4</th>
      <th>货品5</th>
      <th>货品6</th>
    </tr>
    <tr>
      <th>月份</th>
      <th>销售区域</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="6" valign="top">7</th>
      <th>华东</th>
      <td>NaN</td>
      <td>489.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>1.0</td>
      <td>NaN</td>
      <td>2041.5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>282.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>泰国</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>733.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>414.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>NaN</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1649.0</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">8</th>
      <th>华东</th>
      <td>NaN</td>
      <td>1640.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>1410.0</td>
      <td>NaN</td>
      <td>1045.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>3.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>泰国</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2381.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1188.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>NaN</td>
      <td>1503.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1181.0</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">9</th>
      <th>华东</th>
      <td>NaN</td>
      <td>3019.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>1409.0</td>
      <td>NaN</td>
      <td>2031.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>283.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>泰国</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>271.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>343.0</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">10</th>
      <th>华东</th>
      <td>NaN</td>
      <td>28420.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>3.0</td>
      <td>NaN</td>
      <td>1684.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>泰国</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1984.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2542.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2358.0</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">11</th>
      <th>华东</th>
      <td>NaN</td>
      <td>2041.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>2.0</td>
      <td>NaN</td>
      <td>100.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>9.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>泰国</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>14.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>9.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>NaN</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>383.0</td>
    </tr>
    <tr>
      <th rowspan="6" valign="top">12</th>
      <th>华东</th>
      <td>NaN</td>
      <td>18202.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>2.0</td>
      <td>NaN</td>
      <td>2172.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>2.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>泰国</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>350.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1082.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>NaN</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2487.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data1['货品2']
#货品2在10，12月份销量猛增，原因主要发生在原有销售区域（华东）
#同样，分析出在7，8，9，11月份销售数量还有很大提升空间，可以适当加大营销力度
```




    月份  销售区域
    7   华东        489.0
        华北          NaN
        华南          NaN
        泰国          NaN
        西北          NaN
        马来西亚        2.0
    8   华东       1640.0
        华北          NaN
        华南          NaN
        泰国          NaN
        西北          NaN
        马来西亚     1503.0
    9   华东       3019.0
        华北          NaN
        华南          NaN
        泰国          NaN
        西北          NaN
        马来西亚        1.0
    10  华东      28420.0
        华北          NaN
        泰国          NaN
        西北          NaN
        马来西亚        NaN
    11  华东       2041.0
        华北          NaN
        华南          NaN
        泰国          NaN
        西北          NaN
        马来西亚        1.0
    12  华东      18202.0
        华北          NaN
        华南          NaN
        泰国          NaN
        西北          NaN
        马来西亚        3.0
    Name: 货品2, dtype: float64



## 商品是否存在质量问题


```python
data['货品用户反馈'] = data['货品用户反馈'].str.strip()  #对字符串进行首位空格的去除，再存储到这列中
data1 = data.groupby(['货品','销售区域'])['货品用户反馈'].value_counts().unstack()
# 先对'货品'这列分组，再对'销售区域'这列分组，然后取出'货品用户反馈'这列，因为这列是字符串，所以不能用sum求和，要用值的数量统计-value_counts(),最后转成df行列格式
data1
```

    <ipython-input-33-3a55d9ed49b8>:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      data['货品用户反馈'] = data['货品用户反馈'].str.strip()  #对字符串进行首位空格的去除，再存储到这列中
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>货品用户反馈</th>
      <th>拒货</th>
      <th>质量合格</th>
      <th>返修</th>
    </tr>
    <tr>
      <th>货品</th>
      <th>销售区域</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="3" valign="top">货品1</th>
      <th>华北</th>
      <td>NaN</td>
      <td>3.0</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>华南</th>
      <td>5.0</td>
      <td>4.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>NaN</td>
      <td>1.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th rowspan="2" valign="top">货品2</th>
      <th>华东</th>
      <td>72.0</td>
      <td>184.0</td>
      <td>51.0</td>
    </tr>
    <tr>
      <th>马来西亚</th>
      <td>6.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>货品3</th>
      <th>华北</th>
      <td>31.0</td>
      <td>188.0</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>货品4</th>
      <th>西北</th>
      <td>NaN</td>
      <td>9.0</td>
      <td>49.0</td>
    </tr>
    <tr>
      <th>货品5</th>
      <th>泰国</th>
      <td>14.0</td>
      <td>144.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>货品6</th>
      <th>马来西亚</th>
      <td>56.0</td>
      <td>246.0</td>
      <td>14.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data1['拒货率'] = data1['拒货'] /data1.sum(axis=1)  #按行进行求和汇总（拒货+质量合格+返修）
data1['返修率'] = data1['返修'] /data1.sum(axis=1)
data1['合格率'] = data1['质量合格'] /data1.sum(axis=1)
data1.sort_values(['合格率','返修率','拒货率'],ascending=False)#先对'合格率'降序排序，如果'合格率'相等，再按'返修率'排序,如果'返修率"相等，再按’拒货率'排序
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>货品用户反馈</th>
      <th>拒货</th>
      <th>质量合格</th>
      <th>返修</th>
      <th>拒货率</th>
      <th>返修率</th>
      <th>合格率</th>
    </tr>
    <tr>
      <th>货品</th>
      <th>销售区域</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>货品3</th>
      <th>华北</th>
      <td>31.0</td>
      <td>188.0</td>
      <td>19.0</td>
      <td>0.130252</td>
      <td>0.079788</td>
      <td>0.789219</td>
    </tr>
    <tr>
      <th>货品6</th>
      <th>马来西亚</th>
      <td>56.0</td>
      <td>246.0</td>
      <td>14.0</td>
      <td>0.177215</td>
      <td>0.044279</td>
      <td>0.777936</td>
    </tr>
    <tr>
      <th>货品5</th>
      <th>泰国</th>
      <td>14.0</td>
      <td>144.0</td>
      <td>29.0</td>
      <td>0.074866</td>
      <td>0.155018</td>
      <td>0.769108</td>
    </tr>
    <tr>
      <th>货品2</th>
      <th>华东</th>
      <td>72.0</td>
      <td>184.0</td>
      <td>51.0</td>
      <td>0.234528</td>
      <td>0.165997</td>
      <td>0.598568</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">货品1</th>
      <th>华南</th>
      <td>5.0</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>0.454545</td>
      <td>0.174603</td>
      <td>0.343963</td>
    </tr>
    <tr>
      <th>西北</th>
      <td>NaN</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>0.666667</td>
      <td>0.272727</td>
    </tr>
    <tr>
      <th>华北</th>
      <td>NaN</td>
      <td>3.0</td>
      <td>12.0</td>
      <td>NaN</td>
      <td>0.800000</td>
      <td>0.189873</td>
    </tr>
    <tr>
      <th>货品4</th>
      <th>西北</th>
      <td>NaN</td>
      <td>9.0</td>
      <td>49.0</td>
      <td>NaN</td>
      <td>0.844828</td>
      <td>0.152945</td>
    </tr>
    <tr>
      <th>货品2</th>
      <th>马来西亚</th>
      <td>6.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>0.600000</td>
      <td>0.283019</td>
      <td>0.091886</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 货品3.6.5合格率均较高，返修率比较低，说明质量还可以
# 货品1.2.4合格率较低，返修率较高，质量存在一定的问题，需要改善
# 货品2在马拉西亚的拒货率最高，同时，在货品2在马拉西亚的按时交货率也非常低。猜测：马来西亚人对送货的时效性要求较高，
# 如果达不到，则往往考虑拒货。
# 考虑到货品2主要在华东地区销售量大，可以考虑增大在华东的投资，适当加大马来西亚的投入。
```
