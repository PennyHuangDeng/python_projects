```python
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```

##### Merge 12 months of sales data into a single csv file 


```python
 os.listdir('D:\python project\Sales Data Analysis\Sales_Data')
```




    ['Sales_April_2019.csv',
     'Sales_August_2019.csv',
     'Sales_December_2019.csv',
     'Sales_February_2019.csv',
     'Sales_January_2019.csv',
     'Sales_July_2019.csv',
     'Sales_June_2019.csv',
     'Sales_March_2019.csv',
     'Sales_May_2019.csv',
     'Sales_November_2019.csv',
     'Sales_October_2019.csv',
     'Sales_September_2019.csv']




```python
files =[file for file in os.listdir('D:\python project\Sales Data Analysis\Sales_Data')]
for file in files:
    print(file)
```

    Sales_April_2019.csv
    Sales_August_2019.csv
    Sales_December_2019.csv
    Sales_February_2019.csv
    Sales_January_2019.csv
    Sales_July_2019.csv
    Sales_June_2019.csv
    Sales_March_2019.csv
    Sales_May_2019.csv
    Sales_November_2019.csv
    Sales_October_2019.csv
    Sales_September_2019.csv
    


```python
path = 'D:\python project\Sales Data Analysis\Sales_Data'

#creat a blank dataframe which name all_data
all_data = pd.DataFrame()

for file in files:
    current_df = pd.read_csv(path+"/"+file)# like (d:\....../sales_april_2019)
    all_data = pd.concat([all_data, current_df])# concat this data frame with this blank
all_data.shape
```




    (186850, 6)



##### convert it into dataset


```python
all_data.to_csv('D:\python project\Sales Data Analysis\Sales_Data/all_data.csv',index=False)
```

##### Data cleaning and formatting


```python
all_data.dtypes
```




    Order ID            object
    Product             object
    Quantity Ordered    object
    Price Each          object
    Order Date          object
    Purchase Address    object
    dtype: object




```python
all_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
    </tr>
  </tbody>
</table>
</div>




```python
all_data.isnull().sum()
```




    Order ID            545
    Product             545
    Quantity Ordered    545
    Price Each          545
    Order Date          545
    Purchase Address    545
    dtype: int64




```python
all_data = all_data.dropna(how='all')
all_data.shape
```




    (186305, 6)



##### What is the best month for sale?


```python
'04/19/19 08:46'.split('/')
```




    ['04', '19', '19 08:46']




```python
'04/19/19 08:46'.split('/')[0] #extract month which index is 0
```




    '04'




```python
def month(x):#define a function
    return x.split('/')[0] #i have to apply this logic and then i have to return this basically the exact logic behind this
```

##### add month col


```python
all_data['Month']=all_data['Order Date'].apply(month) # order data这列，都执行上面定义的month 一遍，来提取month
```


```python
all_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>04</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
  </tbody>
</table>
</div>




```python
all_data.dtypes
```




    Order ID            object
    Product             object
    Quantity Ordered    object
    Price Each          object
    Order Date          object
    Purchase Address    object
    Month               object
    dtype: object




```python
# 首先转变month这列的类型
all_data['Month']=all_data['Month'].astype(int) #发现错误看解释
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-19-9c851e9ed7fb> in <module>
          1 # 首先转变month这列的类型
    ----> 2 all_data['Month']=all_data['Month'].astype(int) #发现错误看解释
    

    d:\Users\ME\anaconda3\lib\site-packages\pandas\core\generic.py in astype(self, dtype, copy, errors, **kwargs)
       5879         else:
       5880             # else, only a single dtype is given
    -> 5881             new_data = self._data.astype(
       5882                 dtype=dtype, copy=copy, errors=errors, **kwargs
       5883             )
    

    d:\Users\ME\anaconda3\lib\site-packages\pandas\core\internals\managers.py in astype(self, dtype, **kwargs)
        579 
        580     def astype(self, dtype, **kwargs):
    --> 581         return self.apply("astype", dtype=dtype, **kwargs)
        582 
        583     def convert(self, **kwargs):
    

    d:\Users\ME\anaconda3\lib\site-packages\pandas\core\internals\managers.py in apply(self, f, axes, filter, do_integrity_check, consolidate, **kwargs)
        436                     kwargs[k] = obj.reindex(b_items, axis=axis, copy=align_copy)
        437 
    --> 438             applied = getattr(b, f)(**kwargs)
        439             result_blocks = _extend_blocks(applied, result_blocks)
        440 
    

    d:\Users\ME\anaconda3\lib\site-packages\pandas\core\internals\blocks.py in astype(self, dtype, copy, errors, values, **kwargs)
        557 
        558     def astype(self, dtype, copy=False, errors="raise", values=None, **kwargs):
    --> 559         return self._astype(dtype, copy=copy, errors=errors, values=values, **kwargs)
        560 
        561     def _astype(self, dtype, copy=False, errors="raise", values=None, **kwargs):
    

    d:\Users\ME\anaconda3\lib\site-packages\pandas\core\internals\blocks.py in _astype(self, dtype, copy, errors, values, **kwargs)
        641                     # _astype_nansafe works fine with 1-d only
        642                     vals1d = values.ravel()
    --> 643                     values = astype_nansafe(vals1d, dtype, copy=True, **kwargs)
        644 
        645                 # TODO(extension)
    

    d:\Users\ME\anaconda3\lib\site-packages\pandas\core\dtypes\cast.py in astype_nansafe(arr, dtype, copy, skipna)
        705         # work around NumPy brokenness, #1987
        706         if np.issubdtype(dtype.type, np.integer):
    --> 707             return lib.astype_intsafe(arr.ravel(), dtype).reshape(arr.shape)
        708 
        709         # if we have a datetime/timedelta array of objects
    

    pandas/_libs/lib.pyx in pandas._libs.lib.astype_intsafe()
    

    ValueError: invalid literal for int() with base 10: 'Order Date'



```python
all_data['Month'].unique()#发现一个不在情况内的
```




    array(['04', '05', 'Order Date', '08', '09', '12', '01', '02', '03', '07',
           '06', '11', '10'], dtype=object)




```python
filter=all_data['Month']=='Order Date'#从month这列筛选出order date这个不在情况内的数据
all_data=all_data[~filter]#找出正常的数据月份
all_data.head()#看一下他们的情况
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>04</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
  </tbody>
</table>
</div>




```python
all_data['Month']=all_data['Month'].astype(int)#这时候可以转化month这列的数据类型了
```


```python
all_data.dtypes #month 这列转换类型成功
```




    Order ID            object
    Product             object
    Quantity Ordered    object
    Price Each          object
    Order Date          object
    Purchase Address    object
    Month                int32
    dtype: object




```python
all_data['Price Each']=all_data['Price Each'].astype(float)#把单价类型转换成浮点类型
```


```python
all_data['Quantity Ordered']=all_data['Quantity Ordered'].astype(int)#把数量类型转换成整型
```


```python
all_data['sales']=all_data['Quantity Ordered']*all_data['Price Each']#增加一列：sales,销售额(sales)=数量*单价
all_data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>sales</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>4</td>
      <td>23.90</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>4</td>
      <td>99.99</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
    </tr>
  </tbody>
</table>
</div>




```python
all_data.groupby('Month')['sales'].sum()#按销售总额按月份分组（列出每个月份的销售总额）
```




    Month
    1     1.822257e+06
    2     2.202022e+06
    3     2.807100e+06
    4     3.390670e+06
    5     3.152607e+06
    6     2.577802e+06
    7     2.647776e+06
    8     2.244468e+06
    9     2.097560e+06
    10    3.736727e+06
    11    3.199603e+06
    12    4.613443e+06
    Name: sales, dtype: float64




```python
months=range(1,13)#从1-12（13不包括）
plt.bar(months,all_data.groupby('Month')['sales'].sum())
plt.xticks(months)
plt.ylabel('Sales in USD ($)')
plt.xlabel('Month number')
plt.show()
# 可以看出：12月份销售量最大
```


![png](output_29_0.png)


##### Which city has max order


```python
'917 1st St, Dallas, TX 75001'.split(',')
```




    ['917 1st St', ' Dallas', ' TX 75001']




```python
'917 1st St, Dallas, TX 75001'.split(',')[1] #extract city which index is 1
```




    ' Dallas'




```python
def city(x):#定义地址x为city
    return x.split(',')[1]#从地址中提取索引为1的城市
```


```python
all_data['city']=all_data['Purchase Address'].apply(city)#从purchase address这列里，遍历city这个定义函数
```


```python
all_data.groupby('city')['city'].count()#按city分组并算出每个city的数量
```




    city
     Atlanta          14881
     Austin            9905
     Boston           19934
     Dallas           14820
     Los Angeles      29605
     New York City    24876
     Portland         12465
     San Francisco    44732
     Seattle          14732
    Name: city, dtype: int64




```python
all_data.groupby('city')['city'].count().plot.bar()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x14d1ed12c70>




![png](output_36_1.png)



```python
# 或者这样画，更详细一些，但结果跟上面一样
plt.bar(all_data.groupby('city')['city'].count().index,all_data.groupby('city')['city'].count())
plt.xticks(rotation='vertical')
plt.ylabel('received orders')
plt.xlabel('city names')
plt.show()
```


![png](output_37_0.png)



```python

```

##### What time should we display advertisements to maximise for product purchase?


```python

```


```python
#首先看一下order date的类型（结果是字符串类型）
all_data['Order Date'][0].dtype
```




    dtype('O')




```python
#把order date这列转成时间类型，再提取hour
all_data['Hour'] = pd.to_datetime(all_data['Order Date']).dt.hour
```


```python
all_data.head()#hour把增加进来了
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>sales</th>
      <th>city</th>
      <th>Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>4</td>
      <td>23.90</td>
      <td>Dallas</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>4</td>
      <td>99.99</td>
      <td>Boston</td>
      <td>22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>14</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
      <td>Los Angeles</td>
      <td>14</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
      <td>Los Angeles</td>
      <td>9</td>
    </tr>
  </tbody>
</table>
</div>




```python
keys=[]#define two list，代表一天24个小时
hour=[]#代表每个小时的时间段相加的数量
for key,hour_df in all_data.groupby('Hour'):
    keys.append(key)
    hour.append(len(hour_df))#len(hour_df)看一下每个时间段的个数
```


```python
keys #一共有24个小时
```




    [0,
     1,
     2,
     3,
     4,
     5,
     6,
     7,
     8,
     9,
     10,
     11,
     12,
     13,
     14,
     15,
     16,
     17,
     18,
     19,
     20,
     21,
     22,
     23]




```python
hour#每个时间段相加个数
```




    [3910,
     2350,
     1243,
     831,
     854,
     1321,
     2482,
     4011,
     6256,
     8748,
     10944,
     12411,
     12587,
     12129,
     10984,
     10175,
     10384,
     10899,
     12280,
     12905,
     12228,
     10921,
     8822,
     6275]




```python
hour_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>sales</th>
      <th>city</th>
      <th>Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>23</th>
      <td>176578</td>
      <td>Apple Airpods Headphones</td>
      <td>1</td>
      <td>150.00</td>
      <td>04/09/19 23:35</td>
      <td>513 Church St, Boston, MA 02215</td>
      <td>4</td>
      <td>150.00</td>
      <td>Boston</td>
      <td>23</td>
    </tr>
    <tr>
      <th>41</th>
      <td>176594</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/17/19 23:04</td>
      <td>63 Maple St, San Francisco, CA 94016</td>
      <td>4</td>
      <td>11.99</td>
      <td>San Francisco</td>
      <td>23</td>
    </tr>
    <tr>
      <th>70</th>
      <td>176623</td>
      <td>27in FHD Monitor</td>
      <td>1</td>
      <td>149.99</td>
      <td>04/20/19 23:51</td>
      <td>807 12th St, Atlanta, GA 30301</td>
      <td>4</td>
      <td>149.99</td>
      <td>Atlanta</td>
      <td>23</td>
    </tr>
    <tr>
      <th>150</th>
      <td>176700</td>
      <td>34in Ultrawide Monitor</td>
      <td>1</td>
      <td>379.99</td>
      <td>04/07/19 23:10</td>
      <td>967 Walnut St, Dallas, TX 75001</td>
      <td>4</td>
      <td>379.99</td>
      <td>Dallas</td>
      <td>23</td>
    </tr>
    <tr>
      <th>158</th>
      <td>176708</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/28/19 23:03</td>
      <td>542 Ridge St, New York City, NY 10001</td>
      <td>4</td>
      <td>11.99</td>
      <td>New York City</td>
      <td>23</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11623</th>
      <td>259299</td>
      <td>Macbook Pro Laptop</td>
      <td>1</td>
      <td>1700.00</td>
      <td>09/30/19 23:59</td>
      <td>240 Chestnut St, Los Angeles, CA 90001</td>
      <td>9</td>
      <td>1700.00</td>
      <td>Los Angeles</td>
      <td>23</td>
    </tr>
    <tr>
      <th>11652</th>
      <td>259326</td>
      <td>AAA Batteries (4-pack)</td>
      <td>3</td>
      <td>2.99</td>
      <td>09/15/19 23:01</td>
      <td>163 Church St, New York City, NY 10001</td>
      <td>9</td>
      <td>8.97</td>
      <td>New York City</td>
      <td>23</td>
    </tr>
    <tr>
      <th>11666</th>
      <td>259339</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>09/12/19 23:43</td>
      <td>509 Park St, Austin, TX 73301</td>
      <td>9</td>
      <td>23.90</td>
      <td>Austin</td>
      <td>23</td>
    </tr>
    <tr>
      <th>11671</th>
      <td>259344</td>
      <td>AAA Batteries (4-pack)</td>
      <td>2</td>
      <td>2.99</td>
      <td>09/10/19 23:33</td>
      <td>721 Madison St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>5.98</td>
      <td>San Francisco</td>
      <td>23</td>
    </tr>
    <tr>
      <th>11672</th>
      <td>259345</td>
      <td>ThinkPad Laptop</td>
      <td>1</td>
      <td>999.99</td>
      <td>09/21/19 23:12</td>
      <td>406 Dogwood St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>999.99</td>
      <td>San Francisco</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
<p>6275 rows × 10 columns</p>
</div>




```python
plt.grid()#绘制网格线
plt.plot(keys,hour)
```




    [<matplotlib.lines.Line2D at 0x14d1f8d5130>]




![png](output_48_1.png)


##### between 12pm and 7pm is probably the best time to advertise to maximise product purchase


```python

```

#### What product sold the most? &  Why?


```python
all_data.groupby('Product')['Quantity Ordered'].sum()
```




    Product
    20in Monitor                   4129
    27in 4K Gaming Monitor         6244
    27in FHD Monitor               7550
    34in Ultrawide Monitor         6199
    AA Batteries (4-pack)         27635
    AAA Batteries (4-pack)        31017
    Apple Airpods Headphones      15661
    Bose SoundSport Headphones    13457
    Flatscreen TV                  4819
    Google Phone                   5532
    LG Dryer                        646
    LG Washing Machine              666
    Lightning Charging Cable      23217
    Macbook Pro Laptop             4728
    ThinkPad Laptop                4130
    USB-C Charging Cable          23975
    Vareebadd Phone                2068
    Wired Headphones              20557
    iPhone                         6849
    Name: Quantity Ordered, dtype: int32




```python
all_data.groupby('Product')['Quantity Ordered'].sum().plot(kind='bar')#按产品进行分组并计算每个产品的总数量
```




    <matplotlib.axes._subplots.AxesSubplot at 0x14d1f9e6400>




![png](output_53_1.png)



```python
all_data.groupby('Product')['Price Each'].mean()#按产品进行分组,计算每个产品的平均价格（what is the mean for each price and every product)
```




    Product
    20in Monitor                   109.99
    27in 4K Gaming Monitor         389.99
    27in FHD Monitor               149.99
    34in Ultrawide Monitor         379.99
    AA Batteries (4-pack)            3.84
    AAA Batteries (4-pack)           2.99
    Apple Airpods Headphones       150.00
    Bose SoundSport Headphones      99.99
    Flatscreen TV                  300.00
    Google Phone                   600.00
    LG Dryer                       600.00
    LG Washing Machine             600.00
    Lightning Charging Cable        14.95
    Macbook Pro Laptop            1700.00
    ThinkPad Laptop                999.99
    USB-C Charging Cable            11.95
    Vareebadd Phone                400.00
    Wired Headphones                11.99
    iPhone                         700.00
    Name: Price Each, dtype: float64




```python
products=all_data.groupby('Product')['Quantity Ordered'].sum().index
quantity=all_data.groupby('Product')['Quantity Ordered'].sum()
prices=all_data.groupby('Product')['Price Each'].mean()
```


```python
products
```




    Index(['20in Monitor', '27in 4K Gaming Monitor', '27in FHD Monitor',
           '34in Ultrawide Monitor', 'AA Batteries (4-pack)',
           'AAA Batteries (4-pack)', 'Apple Airpods Headphones',
           'Bose SoundSport Headphones', 'Flatscreen TV', 'Google Phone',
           'LG Dryer', 'LG Washing Machine', 'Lightning Charging Cable',
           'Macbook Pro Laptop', 'ThinkPad Laptop', 'USB-C Charging Cable',
           'Vareebadd Phone', 'Wired Headphones', 'iPhone'],
          dtype='object', name='Product')




```python
quantity
```




    Product
    20in Monitor                   4129
    27in 4K Gaming Monitor         6244
    27in FHD Monitor               7550
    34in Ultrawide Monitor         6199
    AA Batteries (4-pack)         27635
    AAA Batteries (4-pack)        31017
    Apple Airpods Headphones      15661
    Bose SoundSport Headphones    13457
    Flatscreen TV                  4819
    Google Phone                   5532
    LG Dryer                        646
    LG Washing Machine              666
    Lightning Charging Cable      23217
    Macbook Pro Laptop             4728
    ThinkPad Laptop                4130
    USB-C Charging Cable          23975
    Vareebadd Phone                2068
    Wired Headphones              20557
    iPhone                         6849
    Name: Quantity Ordered, dtype: int32




```python
prices
```




    Product
    20in Monitor                   109.99
    27in 4K Gaming Monitor         389.99
    27in FHD Monitor               149.99
    34in Ultrawide Monitor         379.99
    AA Batteries (4-pack)            3.84
    AAA Batteries (4-pack)           2.99
    Apple Airpods Headphones       150.00
    Bose SoundSport Headphones      99.99
    Flatscreen TV                  300.00
    Google Phone                   600.00
    LG Dryer                       600.00
    LG Washing Machine             600.00
    Lightning Charging Cable        14.95
    Macbook Pro Laptop            1700.00
    ThinkPad Laptop                999.99
    USB-C Charging Cable            11.95
    Vareebadd Phone                400.00
    Wired Headphones                11.99
    iPhone                         700.00
    Name: Price Each, dtype: float64




```python
plt.figure(figsize=(40,24))
fig,ax1 = plt.subplots()
ax2=ax1.twinx()
ax1.bar(products, quantity, color='g')
ax2.plot(products, prices, 'b-')
ax1.set_xticklabels(products, rotation='vertical', size=8)
```




    [Text(0, 0, '20in Monitor'),
     Text(0, 0, '27in 4K Gaming Monitor'),
     Text(0, 0, '27in FHD Monitor'),
     Text(0, 0, '34in Ultrawide Monitor'),
     Text(0, 0, 'AA Batteries (4-pack)'),
     Text(0, 0, 'AAA Batteries (4-pack)'),
     Text(0, 0, 'Apple Airpods Headphones'),
     Text(0, 0, 'Bose SoundSport Headphones'),
     Text(0, 0, 'Flatscreen TV'),
     Text(0, 0, 'Google Phone'),
     Text(0, 0, 'LG Dryer'),
     Text(0, 0, 'LG Washing Machine'),
     Text(0, 0, 'Lightning Charging Cable'),
     Text(0, 0, 'Macbook Pro Laptop'),
     Text(0, 0, 'ThinkPad Laptop'),
     Text(0, 0, 'USB-C Charging Cable'),
     Text(0, 0, 'Vareebadd Phone'),
     Text(0, 0, 'Wired Headphones'),
     Text(0, 0, 'iPhone')]




    <Figure size 2880x1728 with 0 Axes>



![png](output_59_2.png)


##### The top selling product is 'AAA Batteries'. The top selling products seem to have a correlation with the price of the product. The cheaper the product higher the quantity ordered and vice versa.


```python
all_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>sales</th>
      <th>city</th>
      <th>Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>4</td>
      <td>23.90</td>
      <td>Dallas</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>4</td>
      <td>99.99</td>
      <td>Boston</td>
      <td>22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>14</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
      <td>Los Angeles</td>
      <td>14</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
      <td>Los Angeles</td>
      <td>9</td>
    </tr>
  </tbody>
</table>
</div>



##### What products are most often sold together?

#### note: keep orders that have same order Id,are sold mostly together


```python
df=all_data[all_data['Order ID'].duplicated(keep=False)]#去重，保留同一个ID购买的顾客（keep all duplicated entries)
df.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>sales</th>
      <th>city</th>
      <th>Hour</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>14</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
      <td>Los Angeles</td>
      <td>14</td>
    </tr>
    <tr>
      <th>18</th>
      <td>176574</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/03/19 19:42</td>
      <td>20 Hill St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>19</td>
    </tr>
    <tr>
      <th>19</th>
      <td>176574</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>04/03/19 19:42</td>
      <td>20 Hill St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.95</td>
      <td>Los Angeles</td>
      <td>19</td>
    </tr>
    <tr>
      <th>30</th>
      <td>176585</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 11:31</td>
      <td>823 Highland St, Boston, MA 02215</td>
      <td>4</td>
      <td>99.99</td>
      <td>Boston</td>
      <td>11</td>
    </tr>
    <tr>
      <th>31</th>
      <td>176585</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 11:31</td>
      <td>823 Highland St, Boston, MA 02215</td>
      <td>4</td>
      <td>99.99</td>
      <td>Boston</td>
      <td>11</td>
    </tr>
    <tr>
      <th>32</th>
      <td>176586</td>
      <td>AAA Batteries (4-pack)</td>
      <td>2</td>
      <td>2.99</td>
      <td>04/10/19 17:00</td>
      <td>365 Center St, San Francisco, CA 94016</td>
      <td>4</td>
      <td>5.98</td>
      <td>San Francisco</td>
      <td>17</td>
    </tr>
    <tr>
      <th>33</th>
      <td>176586</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/10/19 17:00</td>
      <td>365 Center St, San Francisco, CA 94016</td>
      <td>4</td>
      <td>600.00</td>
      <td>San Francisco</td>
      <td>17</td>
    </tr>
    <tr>
      <th>119</th>
      <td>176672</td>
      <td>Lightning Charging Cable</td>
      <td>1</td>
      <td>14.95</td>
      <td>04/12/19 11:07</td>
      <td>778 Maple St, New York City, NY 10001</td>
      <td>4</td>
      <td>14.95</td>
      <td>New York City</td>
      <td>11</td>
    </tr>
    <tr>
      <th>120</th>
      <td>176672</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>04/12/19 11:07</td>
      <td>778 Maple St, New York City, NY 10001</td>
      <td>4</td>
      <td>11.95</td>
      <td>New York City</td>
      <td>11</td>
    </tr>
    <tr>
      <th>129</th>
      <td>176681</td>
      <td>Apple Airpods Headphones</td>
      <td>1</td>
      <td>150.00</td>
      <td>04/20/19 10:39</td>
      <td>331 Cherry St, Seattle, WA 98101</td>
      <td>4</td>
      <td>150.00</td>
      <td>Seattle</td>
      <td>10</td>
    </tr>
    <tr>
      <th>130</th>
      <td>176681</td>
      <td>ThinkPad Laptop</td>
      <td>1</td>
      <td>999.99</td>
      <td>04/20/19 10:39</td>
      <td>331 Cherry St, Seattle, WA 98101</td>
      <td>4</td>
      <td>999.99</td>
      <td>Seattle</td>
      <td>10</td>
    </tr>
    <tr>
      <th>138</th>
      <td>176689</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/24/19 17:15</td>
      <td>659 Lincoln St, New York City, NY 10001</td>
      <td>4</td>
      <td>99.99</td>
      <td>New York City</td>
      <td>17</td>
    </tr>
    <tr>
      <th>139</th>
      <td>176689</td>
      <td>AAA Batteries (4-pack)</td>
      <td>2</td>
      <td>2.99</td>
      <td>04/24/19 17:15</td>
      <td>659 Lincoln St, New York City, NY 10001</td>
      <td>4</td>
      <td>5.98</td>
      <td>New York City</td>
      <td>17</td>
    </tr>
    <tr>
      <th>189</th>
      <td>176739</td>
      <td>34in Ultrawide Monitor</td>
      <td>1</td>
      <td>379.99</td>
      <td>04/05/19 17:38</td>
      <td>730 6th St, Austin, TX 73301</td>
      <td>4</td>
      <td>379.99</td>
      <td>Austin</td>
      <td>17</td>
    </tr>
    <tr>
      <th>190</th>
      <td>176739</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/05/19 17:38</td>
      <td>730 6th St, Austin, TX 73301</td>
      <td>4</td>
      <td>600.00</td>
      <td>Austin</td>
      <td>17</td>
    </tr>
    <tr>
      <th>225</th>
      <td>176774</td>
      <td>Lightning Charging Cable</td>
      <td>1</td>
      <td>14.95</td>
      <td>04/25/19 15:06</td>
      <td>372 Church St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>14.95</td>
      <td>Los Angeles</td>
      <td>15</td>
    </tr>
    <tr>
      <th>226</th>
      <td>176774</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>04/25/19 15:06</td>
      <td>372 Church St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.95</td>
      <td>Los Angeles</td>
      <td>15</td>
    </tr>
    <tr>
      <th>233</th>
      <td>176781</td>
      <td>iPhone</td>
      <td>1</td>
      <td>700.00</td>
      <td>04/03/19 07:37</td>
      <td>976 Hickory St, Dallas, TX 75001</td>
      <td>4</td>
      <td>700.00</td>
      <td>Dallas</td>
      <td>7</td>
    </tr>
    <tr>
      <th>234</th>
      <td>176781</td>
      <td>Lightning Charging Cable</td>
      <td>1</td>
      <td>14.95</td>
      <td>04/03/19 07:37</td>
      <td>976 Hickory St, Dallas, TX 75001</td>
      <td>4</td>
      <td>14.95</td>
      <td>Dallas</td>
      <td>7</td>
    </tr>
  </tbody>
</table>
</div>




```python
#create grouped col 
#join both of the product for each order already
df['Grouped'] = df.groupby('Order ID')['Product'].transform(lambda x: ','.join(x))
```

    <ipython-input-116-4a28b12fa2cd>:3: SettingWithCopyWarning:
    
    
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>sales</th>
      <th>city</th>
      <th>Hour</th>
      <th>Grouped</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>14</td>
      <td>Google Phone,Wired Headphones</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.99</td>
      <td>Los Angeles</td>
      <td>14</td>
      <td>Google Phone,Wired Headphones</td>
    </tr>
    <tr>
      <th>18</th>
      <td>176574</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/03/19 19:42</td>
      <td>20 Hill St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>19</td>
      <td>Google Phone,USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>19</th>
      <td>176574</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>04/03/19 19:42</td>
      <td>20 Hill St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>11.95</td>
      <td>Los Angeles</td>
      <td>19</td>
      <td>Google Phone,USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>30</th>
      <td>176585</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 11:31</td>
      <td>823 Highland St, Boston, MA 02215</td>
      <td>4</td>
      <td>99.99</td>
      <td>Boston</td>
      <td>11</td>
      <td>Bose SoundSport Headphones,Bose SoundSport Hea...</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (14649, 11)




```python
#lets drop out all duplicate Order ID 这个时候可以删除上面重复的了
df2 = df.drop_duplicates(subset=['Order ID'])# basis of order ID
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>sales</th>
      <th>city</th>
      <th>Hour</th>
      <th>Grouped</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>14</td>
      <td>Google Phone,Wired Headphones</td>
    </tr>
    <tr>
      <th>18</th>
      <td>176574</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600.00</td>
      <td>04/03/19 19:42</td>
      <td>20 Hill St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>600.00</td>
      <td>Los Angeles</td>
      <td>19</td>
      <td>Google Phone,USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>30</th>
      <td>176585</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 11:31</td>
      <td>823 Highland St, Boston, MA 02215</td>
      <td>4</td>
      <td>99.99</td>
      <td>Boston</td>
      <td>11</td>
      <td>Bose SoundSport Headphones,Bose SoundSport Hea...</td>
    </tr>
    <tr>
      <th>32</th>
      <td>176586</td>
      <td>AAA Batteries (4-pack)</td>
      <td>2</td>
      <td>2.99</td>
      <td>04/10/19 17:00</td>
      <td>365 Center St, San Francisco, CA 94016</td>
      <td>4</td>
      <td>5.98</td>
      <td>San Francisco</td>
      <td>17</td>
      <td>AAA Batteries (4-pack),Google Phone</td>
    </tr>
    <tr>
      <th>119</th>
      <td>176672</td>
      <td>Lightning Charging Cable</td>
      <td>1</td>
      <td>14.95</td>
      <td>04/12/19 11:07</td>
      <td>778 Maple St, New York City, NY 10001</td>
      <td>4</td>
      <td>14.95</td>
      <td>New York City</td>
      <td>11</td>
      <td>Lightning Charging Cable,USB-C Charging Cable</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2['Grouped'].value_counts()#按grouped进行分组计算每组的数量
```




    iPhone,Lightning Charging Cable                                          882
    Google Phone,USB-C Charging Cable                                        856
    iPhone,Wired Headphones                                                  361
    Vareebadd Phone,USB-C Charging Cable                                     312
    Google Phone,Wired Headphones                                            303
                                                                            ... 
    iPhone,Lightning Charging Cable,Wired Headphones,USB-C Charging Cable      1
    34in Ultrawide Monitor,LG Washing Machine                                  1
    Google Phone,USB-C Charging Cable,Wired Headphones,iPhone                  1
    20in Monitor,LG Washing Machine                                            1
    AAA Batteries (4-pack),LG Dryer                                            1
    Name: Grouped, Length: 366, dtype: int64




```python
# plot the first five grouped product ,the hightest the top five grouped product
df2['Grouped'].value_counts()[0:5].plot.pie()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x14d20677cd0>




![png](output_70_1.png)



```python
# whever a customer is going to buy iphone on some e-commerce website,that particular wesite can pop up like the charging cable as a recommendation 
# for that particular customer.
```


```python
# 在Jupyter Notebook里面渲染pyecharts无法显示，这个问题的原因，一般是静态资源没法加载，解决方案如下：

from pyecharts.globals import CurrentConfig

CurrentConfig.ONLINE_HOST="https://cdn.kesci.com/lib/pyecharts_assets/"
```


```python
#另一个交互式的画法
import plotly.graph_objs as go
from plotly.offline import iplot
```


```python
values=df2['Grouped'].value_counts()[0:5]
labels=df['Grouped'].value_counts()[0:5].index
```


```python
trace=go.Pie(labels=labels, values=values,
               hoverinfo='label+percent', textinfo='value', 
               textfont=dict(size=25),
              pull=[0, 0, 0,0.2, 0]
               )
```


```python
iplot([trace])
```


<div>                            <div id="8cd2a8b3-95f8-4d85-9656-7c0795e4e5ea" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("8cd2a8b3-95f8-4d85-9656-7c0795e4e5ea")) {                    Plotly.newPlot(                        "8cd2a8b3-95f8-4d85-9656-7c0795e4e5ea",                        [{"hoverinfo": "label+percent", "labels": ["iPhone,Lightning Charging Cable", "Google Phone,USB-C Charging Cable", "iPhone,Wired Headphones", "Vareebadd Phone,USB-C Charging Cable", "Google Phone,Wired Headphones"], "pull": [0, 0, 0, 0.2, 0], "textfont": {"size": 25}, "textinfo": "value", "type": "pie", "values": [882, 856, 361, 312, 303]}],                        {"template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "autotypenumbers": "strict", "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('8cd2a8b3-95f8-4d85-9656-7c0795e4e5ea');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python

```
